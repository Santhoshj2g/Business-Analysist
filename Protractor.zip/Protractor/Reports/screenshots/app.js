var app = angular.module('reportingApp', []);

//<editor-fold desc="global helpers">

var isValueAnArray = function (val) {
    return Array.isArray(val);
};

var getSpec = function (str) {
    var describes = str.split('|');
    return describes[describes.length - 1];
};
var checkIfShouldDisplaySpecName = function (prevItem, item) {
    if (!prevItem) {
        item.displaySpecName = true;
    } else if (getSpec(item.description) !== getSpec(prevItem.description)) {
        item.displaySpecName = true;
    }
};

var getParent = function (str) {
    var arr = str.split('|');
    str = "";
    for (var i = arr.length - 2; i > 0; i--) {
        str += arr[i] + " > ";
    }
    return str.slice(0, -3);
};

var getShortDescription = function (str) {
    return str.split('|')[0];
};

var countLogMessages = function (item) {
    if ((!item.logWarnings || !item.logErrors) && item.browserLogs && item.browserLogs.length > 0) {
        item.logWarnings = 0;
        item.logErrors = 0;
        for (var logNumber = 0; logNumber < item.browserLogs.length; logNumber++) {
            var logEntry = item.browserLogs[logNumber];
            if (logEntry.level === 'SEVERE') {
                item.logErrors++;
            }
            if (logEntry.level === 'WARNING') {
                item.logWarnings++;
            }
        }
    }
};

var convertTimestamp = function (timestamp) {
    var d = new Date(timestamp),
        yyyy = d.getFullYear(),
        mm = ('0' + (d.getMonth() + 1)).slice(-2),
        dd = ('0' + d.getDate()).slice(-2),
        hh = d.getHours(),
        h = hh,
        min = ('0' + d.getMinutes()).slice(-2),
        ampm = 'AM',
        time;

    if (hh > 12) {
        h = hh - 12;
        ampm = 'PM';
    } else if (hh === 12) {
        h = 12;
        ampm = 'PM';
    } else if (hh === 0) {
        h = 12;
    }

    // ie: 2013-02-18, 8:35 AM
    time = yyyy + '-' + mm + '-' + dd + ', ' + h + ':' + min + ' ' + ampm;

    return time;
};

var defaultSortFunction = function sortFunction(a, b) {
    if (a.sessionId < b.sessionId) {
        return -1;
    } else if (a.sessionId > b.sessionId) {
        return 1;
    }

    if (a.timestamp < b.timestamp) {
        return -1;
    } else if (a.timestamp > b.timestamp) {
        return 1;
    }

    return 0;
};

//</editor-fold>

app.controller('ScreenshotReportController', ['$scope', '$http', 'TitleService', function ($scope, $http, titleService) {
    var that = this;
    var clientDefaults = {
    "displayTime": true,
    "displayBrowser": true,
    "displaySessionId": true,
    "displayOS": true,
    "inlineScreenshots": false,
    "showTotalDurationIn": "header",
    "totalDurationFormat": "hms"
};

    $scope.searchSettings = Object.assign({
        description: '',
        allselected: true,
        passed: true,
        failed: true,
        pending: true,
        withLog: true
    }, clientDefaults.searchSettings || {}); // enable customisation of search settings on first page hit

    this.warningTime = 1400;
    this.dangerTime = 1900;
    this.totalDurationFormat = clientDefaults.totalDurationFormat;
    this.showTotalDurationIn = clientDefaults.showTotalDurationIn;

    var initialColumnSettings = clientDefaults.columnSettings; // enable customisation of visible columns on first page hit
    if (initialColumnSettings) {
        if (initialColumnSettings.displayTime !== undefined) {
            // initial settings have be inverted because the html bindings are inverted (e.g. !ctrl.displayTime)
            this.displayTime = !initialColumnSettings.displayTime;
        }
        if (initialColumnSettings.displayBrowser !== undefined) {
            this.displayBrowser = !initialColumnSettings.displayBrowser; // same as above
        }
        if (initialColumnSettings.displaySessionId !== undefined) {
            this.displaySessionId = !initialColumnSettings.displaySessionId; // same as above
        }
        if (initialColumnSettings.displayOS !== undefined) {
            this.displayOS = !initialColumnSettings.displayOS; // same as above
        }
        if (initialColumnSettings.inlineScreenshots !== undefined) {
            this.inlineScreenshots = initialColumnSettings.inlineScreenshots; // this setting does not have to be inverted
        } else {
            this.inlineScreenshots = false;
        }
        if (initialColumnSettings.warningTime) {
            this.warningTime = initialColumnSettings.warningTime;
        }
        if (initialColumnSettings.dangerTime) {
            this.dangerTime = initialColumnSettings.dangerTime;
        }
    }


    this.chooseAllTypes = function () {
        var value = true;
        $scope.searchSettings.allselected = !$scope.searchSettings.allselected;
        if (!$scope.searchSettings.allselected) {
            value = false;
        }

        $scope.searchSettings.passed = value;
        $scope.searchSettings.failed = value;
        $scope.searchSettings.pending = value;
        $scope.searchSettings.withLog = value;
    };

    this.isValueAnArray = function (val) {
        return isValueAnArray(val);
    };

    this.getParent = function (str) {
        return getParent(str);
    };

    this.getSpec = function (str) {
        return getSpec(str);
    };

    this.getShortDescription = function (str) {
        return getShortDescription(str);
    };
    this.hasNextScreenshot = function (index) {
        var old = index;
        return old !== this.getNextScreenshotIdx(index);
    };

    this.hasPreviousScreenshot = function (index) {
        var old = index;
        return old !== this.getPreviousScreenshotIdx(index);
    };
    this.getNextScreenshotIdx = function (index) {
        var next = index;
        var hit = false;
        while (next + 2 < this.results.length) {
            next++;
            if (this.results[next].screenShotFile && !this.results[next].pending) {
                hit = true;
                break;
            }
        }
        return hit ? next : index;
    };

    this.getPreviousScreenshotIdx = function (index) {
        var prev = index;
        var hit = false;
        while (prev > 0) {
            prev--;
            if (this.results[prev].screenShotFile && !this.results[prev].pending) {
                hit = true;
                break;
            }
        }
        return hit ? prev : index;
    };

    this.convertTimestamp = convertTimestamp;


    this.round = function (number, roundVal) {
        return (parseFloat(number) / 1000).toFixed(roundVal);
    };


    this.passCount = function () {
        var passCount = 0;
        for (var i in this.results) {
            var result = this.results[i];
            if (result.passed) {
                passCount++;
            }
        }
        return passCount;
    };


    this.pendingCount = function () {
        var pendingCount = 0;
        for (var i in this.results) {
            var result = this.results[i];
            if (result.pending) {
                pendingCount++;
            }
        }
        return pendingCount;
    };

    this.failCount = function () {
        var failCount = 0;
        for (var i in this.results) {
            var result = this.results[i];
            if (!result.passed && !result.pending) {
                failCount++;
            }
        }
        return failCount;
    };

    this.totalDuration = function () {
        var sum = 0;
        for (var i in this.results) {
            var result = this.results[i];
            if (result.duration) {
                sum += result.duration;
            }
        }
        return sum;
    };

    this.passPerc = function () {
        return (this.passCount() / this.totalCount()) * 100;
    };
    this.pendingPerc = function () {
        return (this.pendingCount() / this.totalCount()) * 100;
    };
    this.failPerc = function () {
        return (this.failCount() / this.totalCount()) * 100;
    };
    this.totalCount = function () {
        return this.passCount() + this.failCount() + this.pendingCount();
    };


    var results = [
    {
        "description": "Should Open Pinkerton site and Login|Login",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "SEVERE",
                "message": "https://login.microsoftonline.com/favicon.ico - Failed to load resource: the server responded with a status of 404 (Not Found)",
                "timestamp": 1619767262410,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://autologon.microsoftazuread-sso.com/pinkerton.com/winauth/ssoprobe?client-request-id=c1d9eded-291d-432b-afb4-c89dea12a295&_=1619767263907 - Failed to load resource: the server responded with a status of 401 (Unauthorized)",
                "timestamp": 1619767264270,
                "type": ""
            }
        ],
        "timestamp": 1619767255401,
        "duration": 34212
    },
    {
        "description": "Should Display Management Action Center and assert elements|Pinkerton Modules Dashboard",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619767289886,
        "duration": 12991
    },
    {
        "description": "Should Display BV Admin Dashboard and assert elements|Pinkerton Dashboard - BV",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619767302907,
        "duration": 14472
    },
    {
        "description": "Should create a new Service|BV - Create New Service",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767319718,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767319719,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767323062,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767323067,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767323071,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767323076,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767323097,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767323105,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767323110,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767336694,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767336695,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767339914,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767339918,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767339921,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767339923,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767339928,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767339931,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767339936,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767339940,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767340080,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767340083,
                "type": ""
            }
        ],
        "timestamp": 1619767317413,
        "duration": 65469
    },
    {
        "description": "Should navigate to Dashboard Page|BV - Create New Service",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619767382917,
        "duration": 564
    },
    {
        "description": "Should create a new Service|BV - Create New Service",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767385684,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767385686,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767388782,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767388787,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767388791,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767388796,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767388804,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767388811,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767388815,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://func-clientadmin-lab-01.azurewebsites.net/api/CreateServiceDetails?code=Pinkerton$ecureKeyU@T001 - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1619767401316,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767437752,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767437753,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767439999,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767440004,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767440087,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767440093,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767440097,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767440100,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767440105,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767440112,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767440119,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767440124,
                "type": ""
            }
        ],
        "timestamp": 1619767383514,
        "duration": 99096
    },
    {
        "description": "Should navigate to Dashboard Page|BV - Create New Service",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619767482648,
        "duration": 411
    },
    {
        "description": "Should create a new Service|BV - Create New Service",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767485137,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767485138,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767487053,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767487057,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767487063,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767487068,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767487075,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767487082,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767487086,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767500674,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767500675,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767502675,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767502678,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767502804,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767502809,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767502812,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767502817,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767502822,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767502828,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767502832,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767502838,
                "type": ""
            }
        ],
        "timestamp": 1619767483091,
        "duration": 60668
    },
    {
        "description": "Should navigate to Dashboard Page|BV - Create New Service",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619767543795,
        "duration": 376
    },
    {
        "description": "Should create a new Service|BV - Create New Service",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767546326,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767546327,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767548964,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767548969,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767548973,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767548979,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767548987,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767548994,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767548998,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767561472,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767561473,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767563062,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767563065,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767563151,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767563155,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767563158,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767563163,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767563170,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767563175,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767563178,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767563184,
                "type": ""
            }
        ],
        "timestamp": 1619767544225,
        "duration": 51041
    },
    {
        "description": "Should navigate to Dashboard Page|BV - Create New Service",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619767595305,
        "duration": 369
    },
    {
        "description": "Should navigate to Create-Package Page|BV - Create New Package",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619767595706,
        "duration": 515
    },
    {
        "description": "Should create a new Package|BV - Create New Package",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767597706,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767597707,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767609380,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767609381,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767623209,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767623214,
                "type": ""
            }
        ],
        "timestamp": 1619767596263,
        "duration": 39878
    },
    {
        "description": "Should navigate to Dashboard Page|BV - Create New Package",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619767636177,
        "duration": 377
    },
    {
        "description": "Should navigate to Create-Package Page|BV - Create New Package",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619767636586,
        "duration": 1384
    },
    {
        "description": "Should create a new Package|BV - Create New Package",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767638472,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767638473,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767650510,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767650511,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767663908,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767663913,
                "type": ""
            }
        ],
        "timestamp": 1619767638009,
        "duration": 39772
    },
    {
        "description": "Should navigate to Dashboard Page|BV - Create New Package",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619767677817,
        "duration": 385
    },
    {
        "description": "Should navigate to Create-Package Page|BV - Create New Package",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619767678227,
        "duration": 1414
    },
    {
        "description": "Should create a new Package|BV - Create New Package",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767680138,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767680139,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767691864,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767691865,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767709516,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767709521,
                "type": ""
            }
        ],
        "timestamp": 1619767679673,
        "duration": 42628
    },
    {
        "description": "Should navigate to Dashboard Page|BV - Create New Package",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619767722325,
        "duration": 395
    },
    {
        "description": "Should create a New Supplier|BV - Create New Supplier",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767724578,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767724594,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767724595,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767724596,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767724596,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767724597,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767724599,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767741603,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767741606,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767741610,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767741622,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767741634,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767741640,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767741647,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767741652,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767741656,
                "type": ""
            }
        ],
        "timestamp": 1619767722752,
        "duration": 39906
    },
    {
        "description": "Should add the Service Types to enable Routing|BV - Create New Supplier",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767763064,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767763068,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767763071,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767763074,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767763077,
                "type": ""
            }
        ],
        "timestamp": 1619767762700,
        "duration": 15177
    },
    {
        "description": "Should add the Service Types to enable Routing|BV - Create New Supplier",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767778313,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767778316,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767778321,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767778324,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767778327,
                "type": ""
            }
        ],
        "timestamp": 1619767777912,
        "duration": 14890
    },
    {
        "description": "Should add the Service Types to enable Routing|BV - Create New Supplier",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767793220,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767793224,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767793227,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767793230,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767793233,
                "type": ""
            }
        ],
        "timestamp": 1619767792827,
        "duration": 14711
    },
    {
        "description": "Should add the Service Types to enable Routing|BV - Create New Supplier",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767807911,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767807915,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767807917,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767807920,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767807922,
                "type": ""
            }
        ],
        "timestamp": 1619767807565,
        "duration": 15081
    },
    {
        "description": "Should navigate to Dashboard Page|BV - Create New Supplier",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619767822686,
        "duration": 392
    },
    {
        "description": "Should create a New Supplier|BV - Create New Supplier",
        "passed": false,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": [
            "Failed: element click intercepted: Element <button _ngcontent-rrh-c156=\"\" type=\"button\" class=\"pinkerton-btn pinkerton-btn-primary float-md-right mr-0 ng-star-inserted\">...</button> is not clickable at point (1483, 566). Other element would receive the click: <div class=\"ng-tns-c46-13 ui-dialog-mask ui-widget-overlay ui-dialog-visible ui-dialog-mask-scrollblocker ng-star-inserted\" style=\"z-index: 1003;\">...</div>\n  (Session info: chrome=90.0.4430.93)\nBuild info: version: '3.141.59', revision: 'e82be7d358', time: '2018-11-14T08:25:53'\nSystem info: host: 'KARUNAKARAN', ip: '192.168.0.105', os.name: 'Windows 10', os.arch: 'amd64', os.version: '10.0', java.version: '1.8.0_241'\nDriver info: driver.version: unknown"
        ],
        "trace": [
            "WebDriverError: element click intercepted: Element <button _ngcontent-rrh-c156=\"\" type=\"button\" class=\"pinkerton-btn pinkerton-btn-primary float-md-right mr-0 ng-star-inserted\">...</button> is not clickable at point (1483, 566). Other element would receive the click: <div class=\"ng-tns-c46-13 ui-dialog-mask ui-widget-overlay ui-dialog-visible ui-dialog-mask-scrollblocker ng-star-inserted\" style=\"z-index: 1003;\">...</div>\n  (Session info: chrome=90.0.4430.93)\nBuild info: version: '3.141.59', revision: 'e82be7d358', time: '2018-11-14T08:25:53'\nSystem info: host: 'KARUNAKARAN', ip: '192.168.0.105', os.name: 'Windows 10', os.arch: 'amd64', os.version: '10.0', java.version: '1.8.0_241'\nDriver info: driver.version: unknown\n    at Object.checkLegacyResponse (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\selenium-webdriver\\lib\\error.js:546:15)\n    at parseHttpResponse (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\selenium-webdriver\\lib\\http.js:509:13)\n    at C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\selenium-webdriver\\lib\\http.js:441:30\n    at runMicrotasks (<anonymous>)\n    at processTicksAndRejections (internal/process/task_queues.js:93:5)\nFrom: Task: WebElement.click()\n    at thenableWebDriverProxy.schedule (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\selenium-webdriver\\lib\\webdriver.js:807:17)\n    at WebElement.schedule_ (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\selenium-webdriver\\lib\\webdriver.js:2010:25)\n    at WebElement.click (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\selenium-webdriver\\lib\\webdriver.js:2092:17)\n    at actionFn (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\protractor\\built\\element.js:89:44)\n    at Array.map (<anonymous>)\n    at C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\protractor\\built\\element.js:461:65\n    at ManagedPromise.invokeCallback_ (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\selenium-webdriver\\lib\\promise.js:1376:14)\n    at TaskQueue.execute_ (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\selenium-webdriver\\lib\\promise.js:3084:14)\n    at TaskQueue.executeNext_ (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\selenium-webdriver\\lib\\promise.js:3067:27)\n    at C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\selenium-webdriver\\lib\\promise.js:2927:27Error\n    at ElementArrayFinder.applyAction_ (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\protractor\\built\\element.js:459:27)\n    at ElementArrayFinder.<computed> [as click] (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\protractor\\built\\element.js:91:29)\n    at ElementFinder.<computed> [as click] (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\protractor\\built\\element.js:831:22)\n    at SuppliersPage.BasePage.clickElement (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\PageObjects\\BasePage.ts:61:14)\n    at SuppliersPage.fillSupplierDetailsTab (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\PageObjects\\BV-PageObjects\\SuppliersPage.ts:103:14)\n    at UserContext.<anonymous> (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\TestCases\\BV-TestCases\\TC_CreateNewSupplier.ts:17:27)\n    at C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\jasminewd2\\index.js:112:25\n    at new ManagedPromise (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\selenium-webdriver\\lib\\promise.js:1077:7)\n    at ControlFlow.promise (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\selenium-webdriver\\lib\\promise.js:2505:12)\n    at schedulerExecute (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\jasminewd2\\index.js:95:18)\nFrom: Task: Run it(\"Should create a New Supplier\") in control flow\n    at UserContext.<anonymous> (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\jasminewd2\\index.js:94:19)\n    at attempt (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4297:26)\n    at QueueRunner.run (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4217:20)\n    at runNext (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4257:20)\n    at C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4264:13\n    at C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4172:9\n    at C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\jasminewd2\\index.js:64:48\n    at ControlFlow.emit (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\selenium-webdriver\\lib\\events.js:62:21)\n    at ControlFlow.shutdown_ (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\selenium-webdriver\\lib\\promise.js:2674:10)\n    at C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\selenium-webdriver\\lib\\promise.js:2599:53\nFrom asynchronous test: \nError\n    at C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\TestCases\\BV-TestCases\\TC_CreateNewSupplier.ts:15:9\n    at C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\jasmine-data-provider\\src\\index.js:25:22\n    at Array.forEach (<anonymous>)\n    at C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\jasmine-data-provider\\src\\index.js:20:20\n    at Suite.<anonymous> (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\TestCases\\BV-TestCases\\TC_CreateNewSupplier.ts:14:5)\n    at addSpecsToSuite (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:1107:25)\n    at Env.describe (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:1074:7)\n    at describe (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4399:18)\n    at Object.<anonymous> (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\TestCases\\BV-TestCases\\TC_CreateNewSupplier.ts:9:1)"
        ],
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767825078,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767825098,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767825099,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767825100,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767825101,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767825102,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767825103,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767839000,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767839001,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767839001,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767839002,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767839002,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767839002,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767839002,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767839003,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767839003,
                "type": ""
            }
        ],
        "screenShotFile": "008200f4-00ae-00b6-00eb-00a8004b00ca.png",
        "timestamp": 1619767823120,
        "duration": 17601
    },
    {
        "description": "Should add the Service Types to enable Routing|BV - Create New Supplier",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767846004,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767846010,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767846016,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767846021,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767846025,
                "type": ""
            }
        ],
        "timestamp": 1619767841353,
        "duration": 19173
    },
    {
        "description": "Should add the Service Types to enable Routing|BV - Create New Supplier",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767860929,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767860934,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767860937,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767860940,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767860944,
                "type": ""
            }
        ],
        "timestamp": 1619767860555,
        "duration": 14696
    },
    {
        "description": "Should add the Service Types to enable Routing|BV - Create New Supplier",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767875679,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767875683,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767875686,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767875689,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767875691,
                "type": ""
            }
        ],
        "timestamp": 1619767875287,
        "duration": 14541
    },
    {
        "description": "Should add the Service Types to enable Routing|BV - Create New Supplier",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767890257,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767890261,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767890267,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767890270,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767890273,
                "type": ""
            }
        ],
        "timestamp": 1619767889873,
        "duration": 14529
    },
    {
        "description": "Should navigate to Dashboard Page|BV - Create New Supplier",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619767904433,
        "duration": 363
    },
    {
        "description": "Should create a New Supplier|BV - Create New Supplier",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767906755,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767906773,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767906773,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767906774,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767906775,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767906776,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767906777,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767921496,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767921499,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767921502,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767921514,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767921526,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767921532,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767921538,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767921544,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767921548,
                "type": ""
            }
        ],
        "timestamp": 1619767904839,
        "duration": 37903
    },
    {
        "description": "Should add the Service Types to enable Routing|BV - Create New Supplier",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767943123,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767943127,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767943130,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767943134,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767943137,
                "type": ""
            }
        ],
        "timestamp": 1619767942775,
        "duration": 15008
    },
    {
        "description": "Should add the Service Types to enable Routing|BV - Create New Supplier",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767958216,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767958220,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767958225,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767958230,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767958233,
                "type": ""
            }
        ],
        "timestamp": 1619767957817,
        "duration": 14840
    },
    {
        "description": "Should add the Service Types to enable Routing|BV - Create New Supplier",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767973100,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767973103,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767973105,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767973107,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767973110,
                "type": ""
            }
        ],
        "timestamp": 1619767972698,
        "duration": 15195
    },
    {
        "description": "Should add the Service Types to enable Routing|BV - Create New Supplier",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767988310,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767988313,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767988316,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767988318,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619767988321,
                "type": ""
            }
        ],
        "timestamp": 1619767987925,
        "duration": 14740
    },
    {
        "description": "Should navigate to Dashboard Page|BV - Create New Supplier",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619768002694,
        "duration": 373
    },
    {
        "description": "Should Route the Service to its Supplier|BV - Service Routing",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768006371,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768006372,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768009032,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768009037,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768009042,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768009045,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768009050,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768009068,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768009077,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768009081,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768016792,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768016798,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768016805,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768016812,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768016818,
                "type": ""
            }
        ],
        "timestamp": 1619768003105,
        "duration": 25528
    },
    {
        "description": "Should Add Rule for Routing Supplier|BV - Service Routing",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768029129,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768029130,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768029131,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768029132,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768029132,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768034655,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768034656,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768034656,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768034657,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768034657,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768037204,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768037205,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768037206,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768037206,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768037207,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768037208,
                "type": ""
            }
        ],
        "timestamp": 1619768028667,
        "duration": 21161
    },
    {
        "description": "Should Add Rule for Routing Supplier|BV - Service Routing",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768050312,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768050313,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768050314,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768050314,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768050315,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768055805,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768055806,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768055806,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768055806,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768055807,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768058198,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768058199,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768058199,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768058200,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768058201,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768058201,
                "type": ""
            }
        ],
        "timestamp": 1619768049880,
        "duration": 20046
    },
    {
        "description": "Should navigate to Dashboard Page|BV - Service Routing",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619768069969,
        "duration": 385
    },
    {
        "description": "Should Route the Service to its Supplier|BV - Service Routing",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768073713,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768073715,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768075684,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768075694,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768075699,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768075702,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768075708,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768075719,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768075730,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768075734,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768077887,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768077891,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768077895,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768077901,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768077905,
                "type": ""
            }
        ],
        "timestamp": 1619768070390,
        "duration": 19326
    },
    {
        "description": "Should Add Rule for Routing Supplier|BV - Service Routing",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768090150,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768090152,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768090152,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768090153,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768090154,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768095666,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768095667,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768095667,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768095668,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768095668,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768098038,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768098038,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768098039,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768098039,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768098040,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768098040,
                "type": ""
            }
        ],
        "timestamp": 1619768089747,
        "duration": 19756
    },
    {
        "description": "Should Add Rule for Routing Supplier|BV - Service Routing",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768109953,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768109954,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768109955,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768109956,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768109956,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768115442,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768115442,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768115443,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768115443,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768115444,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768117936,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768117937,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768117937,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768117938,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768117938,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768117939,
                "type": ""
            }
        ],
        "timestamp": 1619768109548,
        "duration": 19690
    },
    {
        "description": "Should navigate to Dashboard Page|BV - Service Routing",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619768129281,
        "duration": 366
    },
    {
        "description": "Should Route the Service to its Supplier|BV - Service Routing",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768132977,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768132978,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768135070,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768135075,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768135079,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768135082,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768135092,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768135108,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768135117,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768135121,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768137115,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768137119,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768137124,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768137129,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768137134,
                "type": ""
            }
        ],
        "timestamp": 1619768129688,
        "duration": 19228
    },
    {
        "description": "Should Add Rule for Routing Supplier|BV - Service Routing",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768149359,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768149361,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768149361,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768149362,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768149362,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768154883,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768154884,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768154884,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768154885,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768154885,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768157161,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768157161,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768157162,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768157162,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768157163,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768157163,
                "type": ""
            }
        ],
        "timestamp": 1619768148963,
        "duration": 19980
    },
    {
        "description": "Should Add Rule for Routing Supplier|BV - Service Routing",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768169391,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768169392,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768169393,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768169393,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768169394,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768174908,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768174909,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768174909,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768174910,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768174910,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768177231,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768177231,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768177231,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768177232,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768177233,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768177233,
                "type": ""
            }
        ],
        "timestamp": 1619768168985,
        "duration": 19969
    },
    {
        "description": "Should navigate to Dashboard Page|BV - Service Routing",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619768188996,
        "duration": 366
    },
    {
        "description": "Should Route the Service to its Supplier|BV - Service Routing",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768192589,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768192590,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768194993,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768194998,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768195003,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768195006,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768195013,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768195032,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768195040,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768195043,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768197163,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768197168,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768197173,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768197179,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768197183,
                "type": ""
            }
        ],
        "timestamp": 1619768189404,
        "duration": 19804
    },
    {
        "description": "Should Add Rule for Routing Supplier|BV - Service Routing",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768209730,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768209731,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768209731,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768209732,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768209732,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768215173,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768215174,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768215174,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768215175,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768215175,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768217498,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768217499,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768217499,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768217500,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768217501,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768217501,
                "type": ""
            }
        ],
        "timestamp": 1619768209255,
        "duration": 19419
    },
    {
        "description": "Should Add Rule for Routing Supplier|BV - Service Routing",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768229122,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768229122,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768229123,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768229124,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768229124,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768234771,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768234771,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768234771,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768234772,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768234772,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768238166,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768238167,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768238168,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768238168,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768238169,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768238169,
                "type": ""
            }
        ],
        "timestamp": 1619768228721,
        "duration": 20986
    },
    {
        "description": "Should navigate to Dashboard Page|BV - Service Routing",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619768249748,
        "duration": 363
    },
    {
        "description": "Should navigate to Clients Page|Configure New Client",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768253777,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768253787,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768253787,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768253788,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768253789,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768253790,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768253790,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768254991,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768254992,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768287353,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768287353,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768287354,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768287355,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768287356,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768287356,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768292703,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768292705,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768292708,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768292718,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768292730,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768292735,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768292743,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768292748,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768292751,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768309807,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768309811,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768317837,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:1914016 \"\\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\\n      you. We recommend using this approach to avoid 'changed after checked' errors.\\n       \\n      Example: \\n      form = new FormGroup({\\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\\n        last: new FormControl('Drew', Validators.required)\\n      });\\n    \"",
                "timestamp": 1619768317840,
                "type": ""
            }
        ],
        "timestamp": 1619768250155,
        "duration": 106154
    },
    {
        "description": "Should configure Business Type|Configure New Client",
        "passed": false,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": [
            "Error: Timeout - Async callback was not invoked within timeout specified by jasmine.DEFAULT_TIMEOUT_INTERVAL.",
            "Error: Timeout - Async callback was not invoked within timeout specified by jasmine.DEFAULT_TIMEOUT_INTERVAL."
        ],
        "trace": [
            "Error: Timeout - Async callback was not invoked within timeout specified by jasmine.DEFAULT_TIMEOUT_INTERVAL.\n    at Timeout._onTimeout (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4281:23)\n    at listOnTimeout (internal/timers.js:554:17)\n    at processTimers (internal/timers.js:497:7)",
            "Error: Timeout - Async callback was not invoked within timeout specified by jasmine.DEFAULT_TIMEOUT_INTERVAL.\n    at Timeout._onTimeout (C:\\Users\\Karunakaran\\Desktop\\Pinkerton\\Pinkerton\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4281:23)\n    at listOnTimeout (internal/timers.js:554:17)\n    at processTimers (internal/timers.js:497:7)"
        ],
        "browserLogs": [
            {
                "level": "SEVERE",
                "message": "https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js 0:259475 \"ERROR\" TypeError: Cannot read property 'valueChanges' of null\n    at e.ngAfterViewInit (https://nexus2-pp.pinkerton.com/PBV/20-es2015.a72171406613b89b8db5.js:1:66560)\n    at _t (https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js:1:253728)\n    at Ct (https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js:1:253569)\n    at yt (https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js:1:253295)\n    at Vi (https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js:1:274134)\n    at https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js:1:273455\n    at Vi (https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js:1:273509)\n    at fr (https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js:1:280414)\n    at https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js:1:273987\n    at Vi (https://nexus2-pp.pinkerton.com/PBV/main-es2015.50b4d0256c6575161297.js:1:273998)",
                "timestamp": 1619768386194,
                "type": ""
            }
        ],
        "screenShotFile": "00a600df-00ec-0060-00b8-00ae00800076.png",
        "timestamp": 1619768356375,
        "duration": 361493
    },
    {
        "description": "Should navigate to Dashboard Page|Configure New Client",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3de613d6b5ac3a3c5734a68eb5977d92",
        "instanceId": 1004,
        "browser": {
            "name": "chrome",
            "version": "90.0.4430.93"
        },
        "message": "Passed",
        "browserLogs": [],
        "timestamp": 1619768718456,
        "duration": 412
    }
];

    this.sortSpecs = function () {
        this.results = results.sort(function sortFunction(a, b) {
    if (a.sessionId < b.sessionId) return -1;else if (a.sessionId > b.sessionId) return 1;

    if (a.timestamp < b.timestamp) return -1;else if (a.timestamp > b.timestamp) return 1;

    return 0;
});

    };

    this.setTitle = function () {
        var title = $('.report-title').text();
        titleService.setTitle(title);
    };

    // is run after all test data has been prepared/loaded
    this.afterLoadingJobs = function () {
        this.sortSpecs();
        this.setTitle();
    };

    this.loadResultsViaAjax = function () {

        $http({
            url: './combined.json',
            method: 'GET'
        }).then(function (response) {
                var data = null;
                if (response && response.data) {
                    if (typeof response.data === 'object') {
                        data = response.data;
                    } else if (response.data[0] === '"') { //detect super escaped file (from circular json)
                        data = CircularJSON.parse(response.data); //the file is escaped in a weird way (with circular json)
                    } else {
                        data = JSON.parse(response.data);
                    }
                }
                if (data) {
                    results = data;
                    that.afterLoadingJobs();
                }
            },
            function (error) {
                console.error(error);
            });
    };


    if (clientDefaults.useAjax) {
        this.loadResultsViaAjax();
    } else {
        this.afterLoadingJobs();
    }

}]);

app.filter('bySearchSettings', function () {
    return function (items, searchSettings) {
        var filtered = [];
        if (!items) {
            return filtered; // to avoid crashing in where results might be empty
        }
        var prevItem = null;

        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            item.displaySpecName = false;

            var isHit = false; //is set to true if any of the search criteria matched
            countLogMessages(item); // modifies item contents

            var hasLog = searchSettings.withLog && item.browserLogs && item.browserLogs.length > 0;
            if (searchSettings.description === '' ||
                (item.description && item.description.toLowerCase().indexOf(searchSettings.description.toLowerCase()) > -1)) {

                if (searchSettings.passed && item.passed || hasLog) {
                    isHit = true;
                } else if (searchSettings.failed && !item.passed && !item.pending || hasLog) {
                    isHit = true;
                } else if (searchSettings.pending && item.pending || hasLog) {
                    isHit = true;
                }
            }
            if (isHit) {
                checkIfShouldDisplaySpecName(prevItem, item);

                filtered.push(item);
                prevItem = item;
            }
        }

        return filtered;
    };
});

//formats millseconds to h m s
app.filter('timeFormat', function () {
    return function (tr, fmt) {
        if(tr == null){
            return "NaN";
        }

        switch (fmt) {
            case 'h':
                var h = tr / 1000 / 60 / 60;
                return "".concat(h.toFixed(2)).concat("h");
            case 'm':
                var m = tr / 1000 / 60;
                return "".concat(m.toFixed(2)).concat("min");
            case 's' :
                var s = tr / 1000;
                return "".concat(s.toFixed(2)).concat("s");
            case 'hm':
            case 'h:m':
                var hmMt = tr / 1000 / 60;
                var hmHr = Math.trunc(hmMt / 60);
                var hmMr = hmMt - (hmHr * 60);
                if (fmt === 'h:m') {
                    return "".concat(hmHr).concat(":").concat(hmMr < 10 ? "0" : "").concat(Math.round(hmMr));
                }
                return "".concat(hmHr).concat("h ").concat(hmMr.toFixed(2)).concat("min");
            case 'hms':
            case 'h:m:s':
                var hmsS = tr / 1000;
                var hmsHr = Math.trunc(hmsS / 60 / 60);
                var hmsM = hmsS / 60;
                var hmsMr = Math.trunc(hmsM - hmsHr * 60);
                var hmsSo = hmsS - (hmsHr * 60 * 60) - (hmsMr*60);
                if (fmt === 'h:m:s') {
                    return "".concat(hmsHr).concat(":").concat(hmsMr < 10 ? "0" : "").concat(hmsMr).concat(":").concat(hmsSo < 10 ? "0" : "").concat(Math.round(hmsSo));
                }
                return "".concat(hmsHr).concat("h ").concat(hmsMr).concat("min ").concat(hmsSo.toFixed(2)).concat("s");
            case 'ms':
                var msS = tr / 1000;
                var msMr = Math.trunc(msS / 60);
                var msMs = msS - (msMr * 60);
                return "".concat(msMr).concat("min ").concat(msMs.toFixed(2)).concat("s");
        }

        return tr;
    };
});


function PbrStackModalController($scope, $rootScope) {
    var ctrl = this;
    ctrl.rootScope = $rootScope;
    ctrl.getParent = getParent;
    ctrl.getShortDescription = getShortDescription;
    ctrl.convertTimestamp = convertTimestamp;
    ctrl.isValueAnArray = isValueAnArray;
    ctrl.toggleSmartStackTraceHighlight = function () {
        var inv = !ctrl.rootScope.showSmartStackTraceHighlight;
        ctrl.rootScope.showSmartStackTraceHighlight = inv;
    };
    ctrl.applySmartHighlight = function (line) {
        if ($rootScope.showSmartStackTraceHighlight) {
            if (line.indexOf('node_modules') > -1) {
                return 'greyout';
            }
            if (line.indexOf('  at ') === -1) {
                return '';
            }

            return 'highlight';
        }
        return '';
    };
}


app.component('pbrStackModal', {
    templateUrl: "pbr-stack-modal.html",
    bindings: {
        index: '=',
        data: '='
    },
    controller: PbrStackModalController
});

function PbrScreenshotModalController($scope, $rootScope) {
    var ctrl = this;
    ctrl.rootScope = $rootScope;
    ctrl.getParent = getParent;
    ctrl.getShortDescription = getShortDescription;

    /**
     * Updates which modal is selected.
     */
    this.updateSelectedModal = function (event, index) {
        var key = event.key; //try to use non-deprecated key first https://developer.mozilla.org/de/docs/Web/API/KeyboardEvent/keyCode
        if (key == null) {
            var keyMap = {
                37: 'ArrowLeft',
                39: 'ArrowRight'
            };
            key = keyMap[event.keyCode]; //fallback to keycode
        }
        if (key === "ArrowLeft" && this.hasPrevious) {
            this.showHideModal(index, this.previous);
        } else if (key === "ArrowRight" && this.hasNext) {
            this.showHideModal(index, this.next);
        }
    };

    /**
     * Hides the modal with the #oldIndex and shows the modal with the #newIndex.
     */
    this.showHideModal = function (oldIndex, newIndex) {
        const modalName = '#imageModal';
        $(modalName + oldIndex).modal("hide");
        $(modalName + newIndex).modal("show");
    };

}

app.component('pbrScreenshotModal', {
    templateUrl: "pbr-screenshot-modal.html",
    bindings: {
        index: '=',
        data: '=',
        next: '=',
        previous: '=',
        hasNext: '=',
        hasPrevious: '='
    },
    controller: PbrScreenshotModalController
});

app.factory('TitleService', ['$document', function ($document) {
    return {
        setTitle: function (title) {
            $document[0].title = title;
        }
    };
}]);


app.run(
    function ($rootScope, $templateCache) {
        //make sure this option is on by default
        $rootScope.showSmartStackTraceHighlight = true;
        
  $templateCache.put('pbr-screenshot-modal.html',
    '<div class="modal" id="imageModal{{$ctrl.index}}" tabindex="-1" role="dialog"\n' +
    '     aria-labelledby="imageModalLabel{{$ctrl.index}}" ng-keydown="$ctrl.updateSelectedModal($event,$ctrl.index)">\n' +
    '    <div class="modal-dialog modal-lg m-screenhot-modal" role="document">\n' +
    '        <div class="modal-content">\n' +
    '            <div class="modal-header">\n' +
    '                <button type="button" class="close" data-dismiss="modal" aria-label="Close">\n' +
    '                    <span aria-hidden="true">&times;</span>\n' +
    '                </button>\n' +
    '                <h6 class="modal-title" id="imageModalLabelP{{$ctrl.index}}">\n' +
    '                    {{$ctrl.getParent($ctrl.data.description)}}</h6>\n' +
    '                <h5 class="modal-title" id="imageModalLabel{{$ctrl.index}}">\n' +
    '                    {{$ctrl.getShortDescription($ctrl.data.description)}}</h5>\n' +
    '            </div>\n' +
    '            <div class="modal-body">\n' +
    '                <img class="screenshotImage" ng-src="{{$ctrl.data.screenShotFile}}">\n' +
    '            </div>\n' +
    '            <div class="modal-footer">\n' +
    '                <div class="pull-left">\n' +
    '                    <button ng-disabled="!$ctrl.hasPrevious" class="btn btn-default btn-previous" data-dismiss="modal"\n' +
    '                            data-toggle="modal" data-target="#imageModal{{$ctrl.previous}}">\n' +
    '                        Prev\n' +
    '                    </button>\n' +
    '                    <button ng-disabled="!$ctrl.hasNext" class="btn btn-default btn-next"\n' +
    '                            data-dismiss="modal" data-toggle="modal"\n' +
    '                            data-target="#imageModal{{$ctrl.next}}">\n' +
    '                        Next\n' +
    '                    </button>\n' +
    '                </div>\n' +
    '                <a class="btn btn-primary" href="{{$ctrl.data.screenShotFile}}" target="_blank">\n' +
    '                    Open Image in New Tab\n' +
    '                    <span class="glyphicon glyphicon-new-window" aria-hidden="true"></span>\n' +
    '                </a>\n' +
    '                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>\n' +
    '            </div>\n' +
    '        </div>\n' +
    '    </div>\n' +
    '</div>\n' +
     ''
  );

  $templateCache.put('pbr-stack-modal.html',
    '<div class="modal" id="modal{{$ctrl.index}}" tabindex="-1" role="dialog"\n' +
    '     aria-labelledby="stackModalLabel{{$ctrl.index}}">\n' +
    '    <div class="modal-dialog modal-lg m-stack-modal" role="document">\n' +
    '        <div class="modal-content">\n' +
    '            <div class="modal-header">\n' +
    '                <button type="button" class="close" data-dismiss="modal" aria-label="Close">\n' +
    '                    <span aria-hidden="true">&times;</span>\n' +
    '                </button>\n' +
    '                <h6 class="modal-title" id="stackModalLabelP{{$ctrl.index}}">\n' +
    '                    {{$ctrl.getParent($ctrl.data.description)}}</h6>\n' +
    '                <h5 class="modal-title" id="stackModalLabel{{$ctrl.index}}">\n' +
    '                    {{$ctrl.getShortDescription($ctrl.data.description)}}</h5>\n' +
    '            </div>\n' +
    '            <div class="modal-body">\n' +
    '                <div ng-if="$ctrl.data.trace.length > 0">\n' +
    '                    <div ng-if="$ctrl.isValueAnArray($ctrl.data.trace)">\n' +
    '                        <pre class="logContainer" ng-repeat="trace in $ctrl.data.trace track by $index"><div ng-class="$ctrl.applySmartHighlight(line)" ng-repeat="line in trace.split(\'\\n\') track by $index">{{line}}</div></pre>\n' +
    '                    </div>\n' +
    '                    <div ng-if="!$ctrl.isValueAnArray($ctrl.data.trace)">\n' +
    '                        <pre class="logContainer"><div ng-class="$ctrl.applySmartHighlight(line)" ng-repeat="line in $ctrl.data.trace.split(\'\\n\') track by $index">{{line}}</div></pre>\n' +
    '                    </div>\n' +
    '                </div>\n' +
    '                <div ng-if="$ctrl.data.browserLogs.length > 0">\n' +
    '                    <h5 class="modal-title">\n' +
    '                        Browser logs:\n' +
    '                    </h5>\n' +
    '                    <pre class="logContainer"><div class="browserLogItem"\n' +
    '                                                   ng-repeat="logError in $ctrl.data.browserLogs track by $index"><div><span class="label browserLogLabel label-default"\n' +
    '                                                                                                                             ng-class="{\'label-danger\': logError.level===\'SEVERE\', \'label-warning\': logError.level===\'WARNING\'}">{{logError.level}}</span><span class="label label-default">{{$ctrl.convertTimestamp(logError.timestamp)}}</span><div ng-repeat="messageLine in logError.message.split(\'\\\\n\') track by $index">{{ messageLine }}</div></div></div></pre>\n' +
    '                </div>\n' +
    '            </div>\n' +
    '            <div class="modal-footer">\n' +
    '                <button class="btn btn-default"\n' +
    '                        ng-class="{active: $ctrl.rootScope.showSmartStackTraceHighlight}"\n' +
    '                        ng-click="$ctrl.toggleSmartStackTraceHighlight()">\n' +
    '                    <span class="glyphicon glyphicon-education black"></span> Smart Stack Trace\n' +
    '                </button>\n' +
    '                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>\n' +
    '            </div>\n' +
    '        </div>\n' +
    '    </div>\n' +
    '</div>\n' +
     ''
  );

    });
