import { browser } from "protractor";
import { DashboardPage_BV_Admin } from "../../PageObjects/BV-PageObjects/DashboardPage_BV_Admin";
import { ServicesPage } from "../../PageObjects/BV-PageObjects/ServicesPage";
import { expect } from "chai";
import { BV } from "../../Utilities/ExcelToJson";
var DataProvider = require('jasmine-data-provider');
var data = require("../../../testdata-json.json");

describe('BV - Service Routing', () => {
    // browser.waitForAngularEnabled(false);
    let dashboardPage = new DashboardPage_BV_Admin();
    let servicesPage = new ServicesPage();
    DataProvider(BV['Routing'], (testdata) => {
        it('Should Route the Service to its Supplier', async () => {
            dashboardPage.clickServices();
            servicesPage.selectService(testdata);
            servicesPage.fillRoutingTab(testdata);
        });

        DataProvider(BV['Rule'], (testdata) => {
            it('Should Add Rule for Routing Supplier', async () => {
                servicesPage.addRule(testdata);
            });
        });

        it('Should navigate to Dashboard Page', async () => {
            dashboardPage.navigateToDashboard(data.Url.DashboardUrl_BV);
        });
    });
});