import { browser } from "protractor";
import { DashboardPage_BV_Admin } from "../../PageObjects/BV-PageObjects/DashboardPage_BV_Admin";
import { ClientsPage } from "../../PageObjects/BV-PageObjects/ClientsPage";
import { expect } from "chai";
import { BV } from "../../Utilities/ExcelToJson";
var DataProvider = require('jasmine-data-provider');
var data = require("../../../testdata-json.json");

describe('Configure New Client', () => {
    // browser.waitForAngularEnabled(false);
    let dashboardPage = new DashboardPage_BV_Admin();
    let clientsPage = new ClientsPage();

    DataProvider(BV['ClientConfig'], (testdata) => {
        it('Should navigate to Clients Page', async () => {
            dashboardPage.clickClients();
            clientsPage.selectClient(testdata);
            clientsPage.fillLocationDetailsTab(testdata);
            dashboardPage.updateStatus();
            clientsPage.fillPackagesTab(testdata);
        });
    });

    DataProvider(BV['BusinessTypeConfig'], (testdata) => {
        it('Should configure Business Type', async () => {
            clientsPage.fillBusinessTypeConfig(testdata);
        });
    });

    it('Should navigate to Dashboard Page', async () => {
        dashboardPage.navigateToDashboard(data.Url.DashboardUrl_BV);
    });
});