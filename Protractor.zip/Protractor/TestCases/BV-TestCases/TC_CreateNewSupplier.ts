import { browser } from "protractor";
import { DashboardPage_BV_Admin } from "../../PageObjects/BV-PageObjects/DashboardPage_BV_Admin";
import { SuppliersPage } from "../../PageObjects/BV-PageObjects/SuppliersPage";
import { expect } from "chai";
import { BV } from "../../Utilities/ExcelToJson";
var DataProvider = require('jasmine-data-provider');
var data = require("../../../testdata-json.json");

describe('BV - Create New Supplier', () => {
    // browser.waitForAngularEnabled(false);
    let dashboardPage = new DashboardPage_BV_Admin();
    let suppliersPage = new SuppliersPage();

    DataProvider(BV['CreateSupplier'], (testdata) => {
        it('Should create a New Supplier', async () => {
            dashboardPage.clickSupplier();
            suppliersPage.fillSupplierDetailsTab(testdata);
            suppliersPage.fillOperationalDetailsTab();
        });

        DataProvider(BV['AddService_Supplier'], (testdata) => {
            it('Should add the Service Types to enable Routing', async () => {
                suppliersPage.addServiceType(testdata);
            });
        });

        it('Should navigate to Dashboard Page', async () => {
            dashboardPage.navigateToDashboard(data.Url.DashboardUrl_BV);
        });
    });
});