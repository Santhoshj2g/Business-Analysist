import { browser, ExpectedConditions as EC} from "protractor";
import { DashboardPage_BV_Admin } from "../../PageObjects/BV-PageObjects/DashboardPage_BV_Admin";
import { PackagesPage } from "../../PageObjects/BV-PageObjects/PackagesPage";
import { expect } from "chai";
import { BV } from "../../Utilities/ExcelToJson";
var DataProvider = require('jasmine-data-provider');
var data = require("../../../testdata-json.json");

describe('BV - Create New Package', () => {
    // browser.waitForAngularEnabled(false);
    let dashboardPage = new DashboardPage_BV_Admin();
    let packagesPage = new PackagesPage();
    
    DataProvider(BV['CreatePackage'], (testdata) => {
        it('Should navigate to Create-Package Page', async () => {
            dashboardPage.clickPackages();                  
        });

        it('Should create a new Package', async () => {
            packagesPage.clickCreatePackage();
            packagesPage.fillPackageDetails(testdata);
            packagesPage.addExistingServices(testdata);
            packagesPage.addVerificationSource(testdata);
            dashboardPage.updateStatus();
            await browser.wait(EC.textToBePresentInElement(dashboardPage.Status, 'ACTIVE'), 60000);
        });

        it('Should navigate to Dashboard Page', async () => {
            dashboardPage.navigateToDashboard(data.Url.DashboardUrl_BV);
        });
    });
});