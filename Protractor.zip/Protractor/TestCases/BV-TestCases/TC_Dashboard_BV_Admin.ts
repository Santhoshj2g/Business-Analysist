import { browser, ExpectedConditions as EC } from "protractor";
import { DashboardPage } from "../../PageObjects/DashboardPage";
import { DashboardPage_BV_Admin } from "../../PageObjects/BV-PageObjects/DashboardPage_BV_Admin";
import { expect } from "chai";
var data = require("../../../testdata-json.json");

describe('Pinkerton Dashboard - BV', () => {
    // browser.waitForAngularEnabled(false);
    let dashboard = new DashboardPage();
    let dashboardBV = new DashboardPage_BV_Admin();

    it('Should Display BV Admin Dashboard and assert elements', async () => {
        dashboard.clickBV();
        await browser.wait(EC.urlContains("dashboard"), 60000);
        expect(await browser.getCurrentUrl()).equals(data.Url.DashboardUrl_BV);
        dashboardBV.waitForElementVisibility(dashboardBV.Clients);
        expect((await dashboardBV.Clients.isPresent()).valueOf()).to.be.true;
        dashboardBV.waitForElementVisibility(dashboardBV.Services);
        expect((await dashboardBV.Services.isPresent()).valueOf()).to.be.true;
        dashboardBV.waitForElementVisibility(dashboardBV.Packages);
        expect((await dashboardBV.Packages.isPresent()).valueOf()).to.be.true;
        dashboardBV.waitForElementVisibility(dashboardBV.Supplier);
        expect((await dashboardBV.Supplier.isPresent()).valueOf()).to.be.true;
        dashboardBV.waitForElementVisibility(dashboardBV.Users);
        expect((await dashboardBV.Users.isPresent()).valueOf()).to.be.true;
    });
});