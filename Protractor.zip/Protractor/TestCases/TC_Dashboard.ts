import { browser, ExpectedConditions as EC } from "protractor";
import { DashboardPage } from "../PageObjects/DashboardPage";
import { expect } from "chai";
var data = require("../../testdata-json.json");

describe('Pinkerton Modules Dashboard', () => {
    browser.waitForAngularEnabled(false);
    let dashboardPage = new DashboardPage();

    it('Should Display Management Action Center and assert elements', async () => {
        await browser.wait(EC.urlContains("Dashboard"), 60000);
        expect(await browser.getCurrentUrl()).equals(data.Url.DashboardUrl);
        dashboardPage.waitForElementVisibility(dashboardPage.PID);
        expect((await dashboardPage.PID.isPresent()).valueOf()).to.be.true;
        dashboardPage.waitForElementVisibility(dashboardPage.PES);
        expect((await dashboardPage.PES.isPresent()).valueOf()).to.be.true;
        dashboardPage.waitForElementVisibility(dashboardPage.DD);
        expect((await dashboardPage.DD.isPresent()).valueOf()).to.be.true;
    });
});