import { browser, ExpectedConditions as EC } from "protractor";
import { LogoutPage } from "../PageObjects/LogoutPage";
import { expect } from "chai";
var data = require("../../testdata-json.json");

describe('Pinkerton Logout', () => {
    browser.waitForAngularEnabled(false);
    let logout = new LogoutPage();

    it('Should Logout of the application', async () => {
        logout.logOut();
        await browser.wait(EC.titleIs('Sign out'), 60000);
        expect(await browser.getTitle()).equals('Sign out');
        expect((await logout.SignOutPageElement.isPresent()).valueOf()).to.be.true;
        logout.logoutAccount(data.LoginCredentials.Username);
        await browser.wait(EC.titleIs('PinkertonApp'), 60000);
        expect(await browser.getCurrentUrl()).equals(data.Url.PinkertonUrl);
        expect(await browser.getTitle()).equals('PinkertonApp');
        console.log("Logged out succesfully");
        browser.driver.sleep(5000);
    });
});