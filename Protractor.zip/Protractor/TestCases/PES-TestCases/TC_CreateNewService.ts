import { browser } from "protractor";
import { DashboardPage_PES } from "../../PageObjects/PES-PageObjects/DashboardPage_PES";
import { ServicesPage } from "../../PageObjects/PES-PageObjects/ServicesPage";
import { expect } from "chai";
import { PES } from "../../Utilities/ExcelToJson";
var DataProvider = require('jasmine-data-provider');
var data = require("../../../testdata-json.json");

describe('Create New Service', () => {
    browser.waitForAngularEnabled(false);
    let dashboardPage = new DashboardPage_PES();
    let servicesPage = new ServicesPage();
    
    DataProvider(PES['CreateService'], (testdata) => {
        it('Should navigate to Create-Service Page', async () => {
            dashboardPage.clickServices();
            servicesPage.clickCreateService();
            servicesPage.fillServiceDetailsTab(testdata);
            servicesPage.fillConfigureDataFieldsTab();
            // servicesPage.fillConfigureQuestionsTab(testdata);
            //servicesPage.fillRoutingTab(testdata);
            // servicesPage.fillQCParameterTab(testdata);
        });

        it('Should navigate to Dashboard Page', async () => {
            dashboardPage.navigateToDashboard(data.Url.DashboardUrl_PES);
            browser.driver.sleep(5000);
        });
    });
});