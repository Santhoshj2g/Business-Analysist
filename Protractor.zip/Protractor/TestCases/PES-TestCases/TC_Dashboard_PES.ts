import { browser, ExpectedConditions as EC } from "protractor";
import { DashboardPage } from "../../PageObjects/DashboardPage";
import { DashboardPage_PES } from "../../PageObjects/PES-PageObjects/DashboardPage_PES";
import { expect } from "chai";
var data = require("../../../testdata-json.json");

describe('Pinkerton Dashboard - PES', () => {
    browser.waitForAngularEnabled(false);
    let dashboard = new DashboardPage();
    let dashboardPES = new DashboardPage_PES();

    it('Should Display Management Action Center and assert elements', async () => {
        dashboard.clickPES();
        await browser.wait(EC.urlContains("dashboard"), 60000);
        expect(await browser.getCurrentUrl()).equals(data.Url.DashboardUrl_PES);
        dashboardPES.waitForElementVisibility(dashboardPES.Mac);
        expect((await dashboardPES.Mac.isPresent()).valueOf()).to.be.true;
        dashboardPES.waitForElementVisibility(dashboardPES.Clients);
        expect((await dashboardPES.Clients.isPresent()).valueOf()).to.be.true;
        dashboardPES.waitForElementVisibility(dashboardPES.Services);
        expect((await dashboardPES.Services.isPresent()).valueOf()).to.be.true;
        dashboardPES.waitForElementVisibility(dashboardPES.Packages);
        expect((await dashboardPES.Packages.isPresent()).valueOf()).to.be.true;
        dashboardPES.waitForElementVisibility(dashboardPES.SupplierConfiguration);
        expect((await dashboardPES.SupplierConfiguration.isPresent()).valueOf()).to.be.true;
        dashboardPES.waitForElementVisibility(dashboardPES.Users);
        expect((await dashboardPES.Users.isPresent()).valueOf()).to.be.true;
        dashboardPES.waitForElementVisibility(dashboardPES.Administration);
        expect((await dashboardPES.Administration.isPresent()).valueOf()).to.be.true;
    });
});