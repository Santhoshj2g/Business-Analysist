import { browser } from "protractor";
import { DashboardPage_PES } from "../../PageObjects/PES-PageObjects/DashboardPage_PES";
import { AdministrationPage } from "../../PageObjects/PES-PageObjects/AdministrationPage";
import { expect } from "chai";
import { PES } from "../../Utilities/ExcelToJson";
var DataProvider = require('jasmine-data-provider');
var data = require("../../../testdata-json.json");

describe('Add Employer', () => {
    browser.waitForAngularEnabled(false);
    let dashboardPage = new DashboardPage_PES();
    let administration = new AdministrationPage();

    DataProvider(PES['Administration'], (testdata) => {
        it('Should navigate to Administration Page and Add Employer', async () => {
            dashboardPage.clickAdministration();
            administration.clickAddEmployer();
            administration.fillEmployerDetails(testdata);
           
        });

        it('Should navigate to Dashboard Page', async () => {
            dashboardPage.navigateToDashboard(data.Url.DashboardUrl_PES);
            browser.driver.sleep(5000);
        });
    });
});