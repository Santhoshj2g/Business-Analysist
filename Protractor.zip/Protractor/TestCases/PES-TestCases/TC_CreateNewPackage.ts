import { browser } from "protractor";
import { DashboardPage_PES } from "../../PageObjects/PES-PageObjects/DashboardPage_PES";
import { PackagesPage } from "../../PageObjects/PES-PageObjects/PackagesPage";
import { expect } from "chai";
import { PES } from "../../Utilities/ExcelToJson";
var DataProvider = require('jasmine-data-provider');
var data = require("../../../testdata-json.json");

describe('Create New Package', () => {
    browser.waitForAngularEnabled(false);
    let dashboardPage = new DashboardPage_PES();
    let packagesPage = new PackagesPage();
    
    DataProvider(PES['CreatePackage'], (testdata) => {
        it('Should navigate to Create-Package Page', async () => {
            dashboardPage.clickPackages();
            packagesPage.clickCreatePackage();
            packagesPage.fillPackageDetails(testdata);
            packagesPage.addExistingServices(testdata);
        });

        it('Should navigate to Dashboard Page', async () => {
            dashboardPage.navigateToDashboard(data.Url.DashboardUrl_PES);
            browser.driver.sleep(5000);
        });
    });
});