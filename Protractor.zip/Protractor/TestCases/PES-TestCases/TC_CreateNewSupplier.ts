import { browser } from "protractor";
import { DashboardPage_PES } from "../../PageObjects/PES-PageObjects/DashboardPage_PES";
import { SuppliersPage } from "../../PageObjects/PES-PageObjects/SuppliersPage";
import { expect } from "chai";
import { PES } from "../../Utilities/ExcelToJson";
var DataProvider = require('jasmine-data-provider');
var data = require("../../../testdata-json.json");

describe('Create New Supplier', () => {
    browser.waitForAngularEnabled(false);
    let dashboardPage = new DashboardPage_PES();
    let suppliersPage = new SuppliersPage();
    
    DataProvider(PES['CreateSupplier'], (testdata) => {
        it('Should navigate to Clients Page', async () => {
            dashboardPage.clickSupplier();
            suppliersPage.fillSupplierDetailsTab(testdata);
            suppliersPage.fillOperationalDetailsTab(testdata);
        });

        it('Should navigate to Dashboard Page', async () => {
            dashboardPage.navigateToDashboard(data.Url.DashboardUrl_PES);
            browser.driver.sleep(5000);
        });
    });
});