import { browser } from "protractor";
import { DashboardPage_PES } from "../../PageObjects/PES-PageObjects/DashboardPage_PES";
import { ClientsPage } from "../../PageObjects/PES-PageObjects/ClientsPage";
import { expect } from "chai";
import { PES } from "../../Utilities/ExcelToJson";
var DataProvider = require('jasmine-data-provider');
var data = require("../../../testdata-json.json");

describe('Configure New Client', () => {
    browser.waitForAngularEnabled(false);
    let dashboardPage = new DashboardPage_PES();
    let clientsPage = new ClientsPage();
    
    DataProvider(PES['ConfigureClient'], (testdata) => {
        it('Should navigate to Clients Page', async () => {
            dashboardPage.clickClients();
            clientsPage.configureNewClient(testdata);
            clientsPage.fillClientDetailsTab(testdata);
            clientsPage.fillLocationDetailsTab(testdata);
            clientsPage.fillPackagesAndServicesTab(testdata);
        });

        it('Should navigate to Dashboard Page', async () => {
            dashboardPage.navigateToDashboard(data.Url.DashboardUrl_PES);
            browser.driver.sleep(5000);
        });
    });
});