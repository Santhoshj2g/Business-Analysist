import { browser, ExpectedConditions as EC } from "protractor";
import { DashboardPage } from "../../PageObjects/DashboardPage";
import { DashboardPage_DD } from "../../PageObjects/DD-PageObjects/DashboardPage_DD";
import { expect } from "chai";
var data = require("../../../testdata-json.json");

describe('Pinkerton Dashboard - DD', () => {
    browser.waitForAngularEnabled(false);
    let dashboardPage = new DashboardPage();
    let dashboardDD = new DashboardPage_DD();

    it('Should Display Management Action Center and assert elements', async () => {
        dashboardPage.clickDueDiligence();
        await browser.wait(EC.urlContains("dashboard"), 60000);
        expect(await browser.getCurrentUrl()).equals(data.Url.DashboardUrl_DD);
        dashboardDD.waitForElementVisibility(dashboardDD.Services);
        expect((await dashboardDD.Services.isPresent()).valueOf()).to.be.true;
        dashboardDD.waitForElementVisibility(dashboardDD.Packages);
        expect((await dashboardDD.Packages.isPresent()).valueOf()).to.be.true;
        dashboardDD.waitForElementVisibility(dashboardDD.DDRequest);
        expect((await dashboardDD.DDRequest.isPresent()).valueOf()).to.be.true;
        dashboardDD.waitForElementVisibility(dashboardDD.ReportTemplate);
        expect((await dashboardDD.ReportTemplate.isPresent()).valueOf()).to.be.true;
        dashboardDD.waitForElementVisibility(dashboardDD.USR);
        expect((await dashboardDD.USR.isPresent()).valueOf()).to.be.true;
    });
});