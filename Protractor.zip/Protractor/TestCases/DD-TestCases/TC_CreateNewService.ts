import { browser } from "protractor";
import { DashboardPage_DD } from "../../PageObjects/DD-PageObjects/DashboardPage_DD";
import { ServicesPage } from "../../PageObjects/DD-PageObjects/ServicesPage";
import { expect } from "chai";
import { DD } from "../../Utilities/ExcelToJson";
var DataProvider = require('jasmine-data-provider');
var data = require("../../../testdata-json.json");

describe('Due Diligence - Create New Service', () => {
    browser.waitForAngularEnabled(false);
    let dashboardPage = new DashboardPage_DD();
    let servicesPage = new ServicesPage();
    
    DataProvider(DD['CreateService'], (testdata) => {
        it('Should navigate to Create-Service Page', async () => {
            dashboardPage.clickServices();
        });

        it('Should create a new Service', async () => {
            servicesPage.clickCreateService();
            servicesPage.fillServiceDetailsTab(testdata);
        });

        it('Should navigate to Dashboard Page', async () => {
            dashboardPage.navigateToDashboard(data.Url.DashboardUrl_DD);
            browser.driver.sleep(2000);
        });
    });
});