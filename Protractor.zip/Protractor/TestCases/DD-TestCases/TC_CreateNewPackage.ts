import { browser } from "protractor";
import { DashboardPage_DD } from "../../PageObjects/DD-PageObjects/DashboardPage_DD";
import { PackagesPage } from "../../PageObjects/DD-PageObjects/PackagesPage";
import { expect } from "chai";
import { DD } from "../../Utilities/ExcelToJson";
var DataProvider = require('jasmine-data-provider');
var data = require("../../../testdata-json.json");

describe('Due Diligence - Create New Package', () => {
    browser.waitForAngularEnabled(false);
    let dashboardPage = new DashboardPage_DD();
    let packagesPage = new PackagesPage();
    
    DataProvider(DD['CreatePackage'], (testdata) => {
        it('Should navigate to Create-Package Page', async () => {
            dashboardPage.clickPackages();                  
        });

        it('Should create a new Package', async () => {
            packagesPage.clickCreateNewPackage();
            packagesPage.fillPackageDetails(testdata);
        });

        it('Should navigate to Dashboard Page', async () => {
            dashboardPage.navigateToDashboard(data.Url.DashboardUrl_DD);
            browser.driver.sleep(2000);
        });
    });
});