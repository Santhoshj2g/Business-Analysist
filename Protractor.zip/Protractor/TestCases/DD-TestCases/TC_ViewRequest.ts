import { browser } from "protractor";
import { DashboardPage_DD } from "../../PageObjects/DD-PageObjects/DashboardPage_DD";
import { USRPage } from "../../PageObjects/DD-PageObjects/USRPage";
import { expect } from "chai";
import { DD } from "../../Utilities/ExcelToJson";
var DataProvider = require('jasmine-data-provider');
var data = require("../../../testdata-json.json");

describe('Due Diligence - View Request', () => {
    browser.waitForAngularEnabled(false);
    let dashboardPage = new DashboardPage_DD();
    let usrPage = new USRPage();
    
    DataProvider(DD['ViewRequest'], (testdata) => {
        it('Should view and select a created USR', async () => {
            dashboardPage.clickUSR();
            usrPage.selectUSR(testdata.USRNumber);
        });

        it('Should view and select a created Request', async () => {
            usrPage.clickDeliveryDetailsTab();
            usrPage.selectSubject(testdata.SubjectName);
            browser.driver.sleep(2000);
        });
    });
});