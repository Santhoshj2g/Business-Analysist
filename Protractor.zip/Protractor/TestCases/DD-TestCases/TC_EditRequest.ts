import { browser } from "protractor";
import { DashboardPage_DD } from "../../PageObjects/DD-PageObjects/DashboardPage_DD";
import { SubjectInfoPage } from "../../PageObjects/DD-PageObjects/SubjectInfoPage";
import { expect } from "chai";
import { DD } from "../../Utilities/ExcelToJson";
var DataProvider = require('jasmine-data-provider');
var data = require("../../../testdata-json.json");

describe('Due Diligence - Edit Request', () => {
    browser.waitForAngularEnabled(false);
    let dashboardPage = new DashboardPage_DD();
    let subjectInfo = new SubjectInfoPage();

    DataProvider(DD['EditRequest'], (testdata) => {
        it('Should edit the subject information page', async () => {
            subjectInfo.fillSubjectInfoPage(testdata);
        });
    });

    DataProvider(DD['EditWorkOrder'], (testdata) => {
        it('Should edit the work order page', async () => {
            subjectInfo.fillWorkOrderPage(testdata);
            browser.driver.sleep(5000);
        });
    });

    it('Should navigate to Dashboard Page', async () => {
        dashboardPage.navigateToDashboard(data.Url.DashboardUrl_DD);
        browser.driver.sleep(2000);
    });

});