import { browser } from "protractor";
import { DashboardPage_DD } from "../../PageObjects/DD-PageObjects/DashboardPage_DD";
import { USRPage } from "../../PageObjects/DD-PageObjects/USRPage";
import { expect } from "chai";
import { DD } from "../../Utilities/ExcelToJson";
var DataProvider = require('jasmine-data-provider');
var data = require("../../../testdata-json.json");

describe('Due Diligence - Create USR', () => {
    browser.waitForAngularEnabled(false);
    let dashboardPage = new DashboardPage_DD();
    let usrPage = new USRPage();

    DataProvider(DD['CreateUSR'], (testdata) => {
        it('Should navigate to Create-USR Page', async () => {
            dashboardPage.clickUSR();
            usrPage.clickCreateUSR();
        });

        it('Create USR - Request Details tab', async () => {
            usrPage.fillRequestDetailsTab(testdata);
        });

        it('Create USR - Engagement Details tab', async () => {
            usrPage.fillEngagementDetailsTab(testdata);
        });

        it('Create USR - Delivery Details tab', async () => {
            usrPage.fillDeliveryDetailsTab(testdata);
        });

        xit('Should navigate to Dashboard Page', async () => {
            dashboardPage.navigateToDashboard(data.Url.DashboardUrl_DD);
            browser.driver.sleep(2000);
        });
    });
});