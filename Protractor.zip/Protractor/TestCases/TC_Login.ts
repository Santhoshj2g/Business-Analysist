import { browser } from "protractor";
import { LoginPage } from "../PageObjects/LoginPage";
import { expect } from "chai";
var data = require("../../testdata-json.json");

describe('Login', () => {
    browser.manage().window().maximize();
    browser.waitForAngularEnabled(false);
    let loginPage = new LoginPage();

    it('Should Open Pinkerton site and Login', async () => {
        await browser.get(data.Url.PinkertonUrl);
        expect(await browser.getCurrentUrl()).equals(data.Url.PinkertonUrl);
        loginPage.loginUser(data);
    });
});