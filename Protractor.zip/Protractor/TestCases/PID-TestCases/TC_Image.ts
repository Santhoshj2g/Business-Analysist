import { browser, by, element } from "protractor";
import { ImageWidgetPage } from "../../PageObjects/PID-PageObjects/ImageWidgetPage";
import { TMConfigurationPage } from "../../PageObjects/PID-PageObjects/TMConfigurationPage";
import { PID } from "../../Utilities/ExcelToJson"
import { expect } from "chai";
var DataProvider = require('jasmine-data-provider');

describe('Image Widget', () => {
    browser.waitForAngularEnabled(false);
    let image = new ImageWidgetPage();
    let tmConfigPage = new TMConfigurationPage();

    DataProvider(PID['ImageWidget'], (testdata) => {
        it('Should drag the Image widget', async () => {
            tmConfigPage.addGeneralTab();
            tmConfigPage.editGeneralTab("Image-URL");
            tmConfigPage.dragAndDrop(image.ImageWidget);
        });

        it('Should Add Image via URL', async () => {
            image.addImageViaURL(testdata);
            browser.driver.sleep(2000);
        });

        it('Threat Monitor Save', async () => {
            tmConfigPage.clickTMSave();
            browser.driver.sleep(2000);
        });

        // it("Upload file", async () => {
        //     browser.sleep(5000);
        //     image.ConfigureImage.click();
        //     image.Title.sendKeys('GifImage');
        //     let path = require("path");
        //     let filePath = "C:/Users/Karunakaran/Pictures/POI.JPG";
        //     let fpath = path.resolve(__dirname, filePath);
        //     browser.sleep(5000);
        //     var file = element(by.xpath("//label[contains(text(),'Choose File')]"));
        //     browser.executeScript("arguments[0].scrollIntoView(true);", file);
        //     file.sendKeys(fpath);
        //     browser.sleep(5000);
        //     image.AddImage.click();
        //     browser.sleep(10000);
        // });
    });
});