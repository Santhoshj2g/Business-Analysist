import { browser } from "protractor";
import { TMConfigurationPage } from "../../PageObjects/PID-PageObjects/TMConfigurationPage";
import { expect } from "chai";
var data = require("../../../testdata-json.json");

describe('Submit to QA', () => {
    browser.waitForAngularEnabled(false);
    let tmConfigPage = new TMConfigurationPage();

    it('Should complete the checklist - Author Review', async () => {
        tmConfigPage.checklistAuthor();
        browser.driver.sleep(2000);
    });

    it('Submit To QA and Check if status is - IN QA', async () => {
        tmConfigPage.clickSubmitToQA();
        tmConfigPage.waitForTMStatus(data.TMStatus.SubmitToQA);
        expect(await tmConfigPage.TMInfo.getText()).contains(data.TMStatus.SubmitToQA);
        var result = await tmConfigPage.TMInfo.getText();
        console.log(result);
    });

    it('Should complete the checklist - QA Review', async () => {
        tmConfigPage.clickTMEdit();
        tmConfigPage.checklistQAReviewer();
        browser.driver.sleep(2000);
    });


    it('Select QA Reviewed and Check if status is - QA REVIEWED', async () => {
        tmConfigPage.clickQAReviewed();
        tmConfigPage.waitForTMStatus(data.TMStatus.QAReviewed);
        expect(await tmConfigPage.TMInfo.getText()).contains(data.TMStatus.QAReviewed);
        var result = await tmConfigPage.TMInfo.getText();
        console.log(result);
    });

    it('Select Publish and Check if status is - Active', async () => {
        tmConfigPage.clickPublish();
        tmConfigPage.waitForTMStatus(data.TMStatus.Publish);
        expect(await tmConfigPage.TMInfo.getText()).contains(data.TMStatus.Publish);
        var result = await tmConfigPage.TMInfo.getText();
        console.log(result);
        browser.driver.sleep(5000);
    });

    // it('Select Inactive and Check if status is - INACTIVE', async () => {
    //     tmConfigPage.clickInactive();
    //     tmConfigPage.waitForTMStatus(data.TMStatus.InActive);
    //     expect(await tmConfigPage.TMInfo.getText()).contains(data.TMStatus.InActive);
    //     var result = await tmConfigPage.TMInfo.getText();
    //     console.log(result);
    // });
});

