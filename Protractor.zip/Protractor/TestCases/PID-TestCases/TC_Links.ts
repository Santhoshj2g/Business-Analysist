import { browser } from "protractor";
import { LinksWidgetPage } from "../../PageObjects/PID-PageObjects/LinksWidgetPage";
import { TMConfigurationPage } from "../../PageObjects/PID-PageObjects/TMConfigurationPage";
import { expect } from "chai";
import { PID } from "../../Utilities/ExcelToJson"
var DataProvider = require('jasmine-data-provider');

describe('Links Widget', () => {
    browser.waitForAngularEnabled(false);
    let linksWidgetPage = new LinksWidgetPage();
    let tmConfigPage = new TMConfigurationPage();

    DataProvider(PID['LinksWidget'], (testdata) => {
        it('Should drag the Links widget', async () => {
            tmConfigPage.addGeneralTab();
            tmConfigPage.editGeneralTab("Links");
            tmConfigPage.dragAndDrop(linksWidgetPage.LinksWidget);
        });

        it('Add Link Widget', async () => {
            linksWidgetPage.addNewLink(testdata);
            browser.driver.sleep(2000);
        });

        it('Threat Monitor Save', async () => {
            tmConfigPage.clickTMSave();
            browser.driver.sleep(2000);
        });
    });
});