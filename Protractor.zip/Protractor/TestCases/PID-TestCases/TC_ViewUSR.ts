import { browser } from "protractor";
import { DashboardPage_PID } from "../../PageObjects/PID-PageObjects/DashboardPage_PID";
import { ServiceRequestPage } from "../../PageObjects/PID-PageObjects/ServiceRequestPage";
import { CreateUSRPage } from "../../PageObjects/PID-PageObjects/CreateUSRPage";
import { DeliveryDetailsPage } from "../../PageObjects/PID-PageObjects/DeliveryDetailsPage";
import { expect } from "chai";
import { PID } from "../../Utilities/ExcelToJson"
var DataProvider = require('jasmine-data-provider');

describe('View USR', () => {
    browser.waitForAngularEnabled(false);
    let dashboardPage = new DashboardPage_PID();
    let serviceRequestPage = new ServiceRequestPage();
    let createUSRPage = new CreateUSRPage();
    let deliveryDetailsPage = new DeliveryDetailsPage();

    DataProvider(PID['ViewUSR'], (testdata) => {
        it('Should go to Service Request Page', async () => {
            dashboardPage.clickViewUSR();
            serviceRequestPage.selectUSR(testdata);
        });

        it('Should navigate to Create TM Page', async () => {
            createUSRPage.clickElement(createUSRPage.Edit);
            deliveryDetailsPage.clickDeliveryDetailsTab();
        });

        it('Should navigate the selected Threat Monitor Page', async () => {
            deliveryDetailsPage.selectTM(testdata);
        });
    });
});