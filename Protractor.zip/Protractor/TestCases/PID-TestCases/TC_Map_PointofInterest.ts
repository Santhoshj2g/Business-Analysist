import { browser } from "protractor";
import { MapWidgetPage } from "../../PageObjects/PID-PageObjects/MapWidgetPage";
import { Map_PointofInterestPage } from "../../PageObjects/PID-PageObjects/Map_PointofInterestPage";
import { TMConfigurationPage } from "../../PageObjects/PID-PageObjects/TMConfigurationPage";
import { PID } from "../../Utilities/ExcelToJson"
var DataProvider = require('jasmine-data-provider');

describe('Map Widget Point of Interest', () => {
    browser.waitForAngularEnabled(false);
    let mapWidgetPage = new MapWidgetPage();
    let mapPOI = new Map_PointofInterestPage();
    let tmConfigPage = new TMConfigurationPage();

    DataProvider(PID['MapWidget_POI'], (testData) => {
        it('Should drag the Map widget', async () => {
            tmConfigPage.editGeneralTab("Map-POI");
            tmConfigPage.dragAndDrop(mapWidgetPage.MapWidget);
        });

        it('Create a new Point Of Interest', async () => {
            mapPOI.createPOI(testData);
            browser.driver.sleep(10000);
        });

        it('Threat Monitor Save', async () => {
            tmConfigPage.clickTMSave();
            browser.driver.sleep(5000);
        });
    });
}); 