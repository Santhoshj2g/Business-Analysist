import { browser, ExpectedConditions as EC } from "protractor";
import { CreateUSRPage } from "../../PageObjects/PID-PageObjects/CreateUSRPage";
import { DeliveryDetailsPage } from "../../PageObjects/PID-PageObjects/DeliveryDetailsPage";
import { expect } from "chai";
import { PID } from "../../Utilities/ExcelToJson"
var DataProvider = require('jasmine-data-provider');
var data = require("../../../testdata-json.json");

describe('Create Threat Monitor', () => {
    browser.waitForAngularEnabled(false);
    let createUSRPage =  new CreateUSRPage();
    let deliveryDetailsPage = new DeliveryDetailsPage();

    DataProvider(PID['CreateThreatMonitor'], (testdata) => {
        it('Should create a Threat Monitor', async () => {
            deliveryDetailsPage.clickDeliveryDetailsTab();
            deliveryDetailsPage.createTM(testdata);
            var result = (await deliveryDetailsPage.isSpanElementDispayed(testdata.TMName)).valueOf();
            console.log(result);
        });

        it('Check if status is - In Progress', async () => {
            createUSRPage.waitForUSRStatus(data.USRStatus.ThreatMonitorStatus);
            expect(await createUSRPage.CreatedUSRNumber.getText()).contains(data.USRStatus.ThreatMonitorStatus);
            var usrId = await createUSRPage.CreatedUSRNumber.getText();
            console.log(usrId);
        });

        it('Select Threat Monitor', async () => {
            deliveryDetailsPage.selectTM(testdata);
            expect((await deliveryDetailsPage.isSpanElementDispayed(testdata.TMName)).valueOf()).to.be.true;
            browser.driver.sleep(3000);
        });
    });
});