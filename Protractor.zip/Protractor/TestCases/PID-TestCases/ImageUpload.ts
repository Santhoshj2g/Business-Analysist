import { browser, element, by, WebElement, ElementFinder } from "protractor";

describe('AD B2C Implementation', () => {
    browser.waitForAngularEnabled(false);
    it("Upload file", function () {
        let path = require("path");
        let filePath = "C:/Users/Karunakaran/Pictures/gifImage.gif";
        let fpath = path.resolve(__dirname, filePath);
        // browser.get("http://qavalidation.com/demo/");
        // browser.manage().window().maximize();
        browser.sleep(5000);
        var file = element(by.xpath("//input[@name='datafile']"));
        browser.executeScript("arguments[0].scrollIntoView(true);", file);
        file.sendKeys(fpath);
        browser.sleep(10000);
    });
});


 // // set file detector
        // var remote = require('../../node_modules/protractor/node_modules/selenium-webdriver/remote');
        // browser.setFileDetector(new remote.FileDetector());
        // var fileToUpload = '../sample.txt';
        // var absolutePath = path.resolve(__dirname, fileToUpload);
        // var fileElem = element(by.css('input[type="file"]'));
        // // Unhide file input
        // browser.executeScript("arguments[0].style.visibility = 'visible'; arguments[0].style.height = '1px'; arguments[0].style.width = '1px';  arguments[0].style.opacity = 1", fileElem.getWebElement());
        // fileElem.sendKeys(absolutePath);
        // // take a breath 
        // browser.driver.sleep(100);
        // // click upload button
        // element(by.css('button[data-ng-click="uploadFile(file)"]')).click(); // does post request

         //var data = require("../testdata.json"); 
        //Select the files from windows not donw
        //   let path = require("path");
        //  var filetoUpload = testdata.UploadFilepathWithName;
        //  var absolutePath = path.resolve(filetoUpload);
        // await element(by.css('input[type="file"]')).sendKeys(absolutePath);
