import { browser } from "protractor";
import { MapWidgetPage } from "../../PageObjects/PID-PageObjects/MapWidgetPage";
import { Map_AlertsPage } from "../../PageObjects/PID-PageObjects/Map_AlertsPage";
import { TMConfigurationPage } from "../../PageObjects/PID-PageObjects/TMConfigurationPage";
import { expect } from "chai";
import { PID } from "../../Utilities/exceltojson";
var DataProvider = require('jasmine-data-provider');

describe('Map Widget - Alerts', () => {
    browser.waitForAngularEnabled(false);
    let mapWidgetPage = new MapWidgetPage();
    let mapAlerts = new Map_AlertsPage();
    let tmConfigPage = new TMConfigurationPage();

    DataProvider(PID['MapWidget_Alerts'], (testdata) => {
        it('Should drag the Map widget', async () => {
            tmConfigPage.dragAndDrop(mapWidgetPage.MapWidget);
            browser.driver.sleep(2000);
        });

        it('Should view added Alerts in Map', async () => {
            tmConfigPage.clickTMSave();
            browser.driver.sleep(2000);
            mapAlerts.viewAlerts(testdata)
            browser.driver.sleep(2000);
        });

        it('Threat Monitor Save', async () => {
            tmConfigPage.clickTMSave();
            browser.driver.sleep(2000);
        });
    });
});