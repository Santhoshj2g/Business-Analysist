import { browser, element, by, ExpectedConditions as EC, Key, WebDriver } from "protractor";
import { RssWidgetPage } from "../../PageObjects/PID-PageObjects/RssWidgetPage";
import { TMConfigurationPage } from "../../PageObjects/PID-PageObjects/TMConfigurationPage";
import { expect } from "chai";
import { PID } from "../../Utilities/ExcelToJson";
var DataProvider = require('jasmine-data-provider');

describe('RSS Widget', () => {
    browser.waitForAngularEnabled(false);
    let rssWidgetPage = new RssWidgetPage();
    let tmConfigPage = new TMConfigurationPage();

    DataProvider(PID['RssWidget'], (testData) => {
        it('Should drag the RSS widget', async () => {
            tmConfigPage.addGeneralTab();
            tmConfigPage.editGeneralTab("RSS");
            tmConfigPage.dragAndDrop(rssWidgetPage.RSSWidget);
        });

        it('Should Configure RSS widget', async () => {
            rssWidgetPage.addNewRSSFeed(testData);
            browser.driver.sleep(2000);
        });

        it('Threat Monitor Save', async () => {
            tmConfigPage.clickTMSave();
            browser.driver.sleep(2000);
        });
    });
}); 