import { browser, ExpectedConditions as EC } from "protractor";
import { CreateUSRPage } from "../../PageObjects/PID-PageObjects/CreateUSRPage";
import { DashboardPage_PID } from "../../PageObjects/PID-PageObjects/DashboardPage_PID";
import { RequestDetailsPage } from "../../PageObjects/PID-PageObjects/RequestDetailsPage";
import { EngagementDetailsPage } from "../../PageObjects/PID-PageObjects/EngagementDetailsPage";
import { expect } from "chai";
import { PID } from "../../Utilities/ExcelToJson"
var DataProvider = require('jasmine-data-provider');
var data = require("../../../testdata-json.json");

describe('Create USR', () => {
    browser.waitForAngularEnabled(false);
    let dashboardPage = new DashboardPage_PID();
    let createUSRPage = new CreateUSRPage();
    let requestDetailsPage = new RequestDetailsPage();
    let engagementDetailsPage = new EngagementDetailsPage();

    DataProvider(PID['CreateUSR'], (testdata) => {
        it('Should navigate to Create-USR Page and assert it', async () => {
            dashboardPage.clickCreateUSR();
            await browser.wait(EC.urlContains("create"), 60000);
            expect(await browser.getCurrentUrl()).equals(data.Url.CreateUSRUrl);
            createUSRPage.waitForElementVisibility(createUSRPage.CreateUSR);
            expect((await createUSRPage.CreateUSR.isPresent()).valueOf()).to.be.true;
        });

        it('Should fill the Request Details Tab', async () => {
            requestDetailsPage.fillRequestDetailsTab(testdata);
            createUSRPage.saveDetails();
        });

        it('Check if status is - Draft', async () => {
            createUSRPage.waitForUSRStatus(data.USRStatus.RequestDetailStatus);
            expect(await createUSRPage.CreatedUSRNumber.getText()).contains(data.USRStatus.RequestDetailStatus);
            var usrId = await createUSRPage.CreatedUSRNumber.getText();
            console.log(usrId);
        });


        it('Should fill the Engagement Details Tab', async () => {
            createUSRPage.clickEdit();
            engagementDetailsPage.fillEngagementDetailsTab(testdata);
            createUSRPage.clickElement(createUSRPage.Save);
        });

        it('Submit and check if status is - Submitted', async () => {
            createUSRPage.submitDetails();
            createUSRPage.waitForUSRStatus(data.USRStatus.SubmitStatus);
            expect(await createUSRPage.CreatedUSRNumber.getText()).contains(data.USRStatus.SubmitStatus);
            var usrId = await createUSRPage.CreatedUSRNumber.getText();
            console.log(usrId);
        });

        it('Assign and check if status is - Assigned', async () => {
            createUSRPage.assignUSR();
            createUSRPage.waitForUSRStatus(data.USRStatus.AssignStatus)
            expect(await createUSRPage.CreatedUSRNumber.getText()).contains(data.USRStatus.AssignStatus);
            var usrId = await createUSRPage.CreatedUSRNumber.getText();
            console.log(usrId);
        });
    });
});