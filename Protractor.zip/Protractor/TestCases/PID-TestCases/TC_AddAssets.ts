import { browser } from "protractor";
import { CreateUSRPage } from "../../PageObjects/PID-PageObjects/CreateUSRPage";
import { GPSMonitoringDetailsPage } from "../../PageObjects/PID-PageObjects/GPSMonitoringDetailsPage";
import { expect } from "chai";
import { PID } from "../../Utilities/ExcelToJson"
var DataProvider = require('jasmine-data-provider');

describe('GPS Monitoring Details', () => {
    browser.waitForAngularEnabled(false);
    let createUSRPage = new CreateUSRPage();
    let gpsMonitoring = new GPSMonitoringDetailsPage();

    DataProvider(PID['GPSMonitoring'], (testdata) => {
        it('Should add Asset - Mobile User', async () => {
            gpsMonitoring.clickGPSMonitoringTab();
            gpsMonitoring.addAsset_MobileUser(testdata);
        });

        it('Should add Asset - Position Logic Device', async () => {
            gpsMonitoring.addAsset_PositionLogicDevice(testdata);
        });

        it('Should add Asset - Warne User', async () => {
            gpsMonitoring.addAsset_WarneUser(testdata);
            gpsMonitoring.clickElement(createUSRPage.Save);
        });
    });
});