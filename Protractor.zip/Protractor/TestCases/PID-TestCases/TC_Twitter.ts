import { browser } from "protractor";
import { TwitterWidgetPage } from "../../PageObjects/PID-PageObjects/TwitterWidgetPage";
import { TMConfigurationPage } from "../../PageObjects/PID-PageObjects/TMConfigurationPage";
import { expect } from "chai";
import { PID } from "../../Utilities/ExcelToJson"
var DataProvider = require('jasmine-data-provider');

describe('Twitter Widget', () => {
    browser.waitForAngularEnabled(false);
    let twitterWidgetPage = new TwitterWidgetPage();
    let tmConfigPage = new TMConfigurationPage();

    DataProvider(PID['TwitterWidget'], (testdata) => {
        it('Add Twitter Widget - Keyword Search', async () => {
            tmConfigPage.addGeneralTab();
            tmConfigPage.editGeneralTab("Twitter-Keywords");
            tmConfigPage.dragAndDrop(twitterWidgetPage.TwitterWidget);
            twitterWidgetPage.searchByKeyword(testdata);
            tmConfigPage.clickTMSave();
            browser.driver.sleep(2000);
        });

        it('Add Twitter Widget - Follow Search', async () => {
            tmConfigPage.addGeneralTab();
            tmConfigPage.editGeneralTab("Twitter-Follow");
            tmConfigPage.dragAndDrop(twitterWidgetPage.TwitterWidget);
            twitterWidgetPage.searchByFollowUser(testdata);
        });

        it('Threat Monitor Save', async () => {
            tmConfigPage.clickTMSave();
            browser.driver.sleep(2000);
        });
    });
});