import { browser } from "protractor";
import { CameraWidgetPage } from "../../PageObjects/PID-PageObjects/CameraWidgetPage";
import { TMConfigurationPage } from "../../PageObjects/PID-PageObjects/TMConfigurationPage";
import { expect } from "chai";
import { PID } from "../../Utilities/ExcelToJson"
var DataProvider = require('jasmine-data-provider');

describe('Camera Widget', () => {
    browser.waitForAngularEnabled(false);
    let cameraWidgetPage = new CameraWidgetPage();
    let tmConfigPage = new TMConfigurationPage();

    DataProvider(PID['CameraWidget'], (testdata) => {
        it('Add IP Camera RTSP Format', async () => {
            tmConfigPage.addGeneralTab();
            tmConfigPage.editGeneralTab("Camera-RTSP");
            tmConfigPage.dragAndDrop(cameraWidgetPage.CameraWidget);
            cameraWidgetPage.addIPCameraRTSP(testdata);
            browser.driver.sleep(2000);
            tmConfigPage.clickTMSave();
            browser.driver.sleep(2000);
        });

        // it('Delete IP Camera RTSP format', async () => {
        //     cameraWidgetPage.DeleteIPCameraRTSP(testdata);
        //     browser.driver.sleep(5000);
        // });

        it('Add IP Camera M3U8 Format', async () => {
            tmConfigPage.addGeneralTab();
            tmConfigPage.editGeneralTab("Camera-M3U8");
            tmConfigPage.dragAndDrop(cameraWidgetPage.CameraWidget);
            cameraWidgetPage.addIPCameraM3U8(testdata);
            browser.driver.sleep(2000);
            tmConfigPage.clickTMSave();
            browser.driver.sleep(2000);
        });

        // it('Delete IP Camera RTSP format', async () => {
        //     cameraWidgetPage.DeleteIPCameraMUEight(testdata);
        //     browser.driver.sleep(5000);
        // });

        it('Add Camera - MJPEG Format', async () => {
            tmConfigPage.addGeneralTab();
            tmConfigPage.editGeneralTab("Camera-MJPEG");
            tmConfigPage.dragAndDrop(cameraWidgetPage.CameraWidget);
            cameraWidgetPage.addMJPEGCamera(testdata);
            browser.driver.sleep(2000);
            tmConfigPage.clickTMSave();
            browser.driver.sleep(2000);
        });

        // it('Delete Camera - MJPEG Format', async () => {
        //     cameraWidgetPage.DeleteMJPEGCamera(testdata);
        //     browser.driver.sleep(5000);
        // });

        it('Add Camera - JPEG Format', async () => {
            tmConfigPage.addGeneralTab();
            tmConfigPage.editGeneralTab("Camera-JPEG");
            tmConfigPage.dragAndDrop(cameraWidgetPage.CameraWidget);
            cameraWidgetPage.addJPEGCamera(testdata);
            browser.driver.sleep(2000);
        });

        // it('Delete Camera - JPEG Format', async () => {
        //     cameraWidgetPage.DeleteMJPEGCamera(testdata);
        //     browser.driver.sleep(5000);
        // });

        it('Threat Monitor Save', async () => {
            tmConfigPage.clickTMSave();
            browser.driver.sleep(2000);
        });
    });
});