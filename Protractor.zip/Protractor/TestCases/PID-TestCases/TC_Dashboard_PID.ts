import { browser, ExpectedConditions as EC } from "protractor";
import { DashboardPage } from "../../PageObjects/DashboardPage";
import { DashboardPage_PID } from "../../PageObjects/PID-PageObjects/DashboardPage_PID";
import { expect } from "chai";
var data = require("../../../testdata-json.json");

describe('Pinkerton Dashboard - PID', () => {
    browser.waitForAngularEnabled(false);
    let dashboard = new DashboardPage
    let dashboardPID = new DashboardPage_PID();

    it('Should Display Management Action Center and assert elements', async () => {
        dashboard.clickPID();
        await browser.get(data.Url.DashboardUrl_PID);
        await browser.wait(EC.urlContains("dashboard"), 60000);
        expect(await browser.getCurrentUrl()).equals(data.Url.DashboardUrl_PID);
        dashboardPID.waitForElementVisibility(dashboardPID.Mac);
        expect((await dashboardPID.Mac.isPresent()).valueOf()).to.be.true;
        dashboardPID.waitForElementVisibility(dashboardPID.ViewUSRButton);
        expect((await dashboardPID.ViewUSRButton.isPresent()).valueOf()).to.be.true;
        dashboardPID.waitForElementVisibility(dashboardPID.CreateUSRButton);
        expect((await dashboardPID.CreateUSRButton.isPresent()).valueOf()).to.be.true;
        dashboardPID.waitForElementVisibility(dashboardPID.ServiceRequest);
        expect((await dashboardPID.ServiceRequest.isPresent()).valueOf()).to.be.true;
        dashboardPID.waitForElementVisibility(dashboardPID.ActiveThreatMonitor);
        expect((await dashboardPID.ActiveThreatMonitor.isPresent()).valueOf()).to.be.true;
        dashboardPID.waitForElementVisibility(dashboardPID.ToDoList);
        expect((await dashboardPID.ToDoList.isPresent()).valueOf()).to.be.true;
        dashboardPID.waitForElementVisibility(dashboardPID.PVNProvisioning);
        expect((await dashboardPID.PVNProvisioning.isPresent()).valueOf()).to.be.true;
    });
});