import { browser } from "protractor";
import { MapWidgetPage } from "../../PageObjects/PID-PageObjects/MapWidgetPage";
import { Map_OverlayPage } from "../../PageObjects/PID-PageObjects/Map_OverlayPage";
import { TMConfigurationPage } from "../../PageObjects/PID-PageObjects/TMConfigurationPage";
import { expect } from "chai";
import { PID } from "../../Utilities/exceltojson";
var DataProvider = require('jasmine-data-provider');

describe('Map Widget - Overlay', () => {
    browser.waitForAngularEnabled(false);
    let mapWidgetPage = new MapWidgetPage();
    let overlayWidget = new Map_OverlayPage();
    let tmConfigPage = new TMConfigurationPage();

    DataProvider(PID['MapWidget_Overlay'], (testdata) => {
        it('Should drag the Map widget', async () => {
            tmConfigPage.clickElement(tmConfigPage.AddGeneralTab)
            tmConfigPage.editGeneralTab("Map-Overlay");
            tmConfigPage.dragAndDrop(mapWidgetPage.MapWidget);
        });

        it('Create Overlay - KML', async () => {
            overlayWidget.create_Overlay_URL(testdata);
            browser.driver.sleep(5000);
        });

        it('Threat Monitor Save', async () => {
            tmConfigPage.clickTMSave();
            browser.driver.sleep(5000);
        });
    });
});