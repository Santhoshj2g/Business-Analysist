import { browser, ExpectedConditions as EC } from "protractor";
import { IframeWidgetPage } from "../../PageObjects/PID-PageObjects/IframeWidgetPage";
import { TMConfigurationPage } from "../../PageObjects/PID-PageObjects/TMConfigurationPage";
import { PID } from "../../Utilities/ExcelToJson"
import { expect } from "chai";
var DataProvider = require('jasmine-data-provider');

describe('Iframe Widget', () => {
    browser.waitForAngularEnabled(false);
    let iframe = new IframeWidgetPage();
    let tmConfigPage = new TMConfigurationPage();

    DataProvider(PID['IFrameWidget'], (testdata) => {
        it('Should drag the Iframe widget', async () => {
            tmConfigPage.addGeneralTab();
            tmConfigPage.editGeneralTab("IFrame");
            tmConfigPage.dragAndDrop(iframe.IFrameWidget);
        });

        it('Should configure Iframe widget', async () => {
            iframe.configureIFrame(testdata);
            browser.driver.sleep(2000);
        });

        it('Threat Monitor Save', async () => {
            tmConfigPage.clickTMSave();
            browser.driver.sleep(2000);
        });
    });
});