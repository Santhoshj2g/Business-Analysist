import { browser, ExpectedConditions as EC } from "protractor";
import { LoginPage_Client } from "../../PageObjects/LoginPage_Client";
import { expect } from "chai";
import { PID } from "../../Utilities/ExcelToJson"
var DataProvider = require('jasmine-data-provider');
var data = require("../../../testdata-json.json");

describe('AD B2C Implementation', () => {
    browser.waitForAngularEnabled(false);
    let clientloginPage = new LoginPage_Client();

    DataProvider(PID['LoginClient'], (testdata) => {
        it('Should perform Client Login in application', async () => {
            await browser.get(data.Url.PinkertonClientUrl);
            expect(await browser.getCurrentUrl()).equals(data.Url.PinkertonClientUrl);
            clientloginPage.loginClient(testdata);
            expect((await clientloginPage.VerificationPageElement.isPresent()).valueOf()).to.be.true;
            clientloginPage.callForVerfication();
            await browser.wait(EC.urlContains("dashboard"), 60000);
            expect(await browser.getCurrentUrl()).equals(data.Url.DashboardUrl);
            expect((await clientloginPage.MAC_Client.isPresent()).valueOf()).to.be.true;
            browser.driver.sleep(15000);
        });
    });
});