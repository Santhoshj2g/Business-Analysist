import { browser } from "protractor";
import { CreateAlertWidgetPage } from "../../PageObjects/PID-PageObjects/CreateAlertWidgetPage";
import { TMConfigurationPage } from "../../PageObjects/PID-PageObjects/TMConfigurationPage";
import { expect } from "chai";
import { PID } from "../../Utilities/ExcelToJson"
var DataProvider = require('jasmine-data-provider');

describe('Create-Alert Widget', () => {
    browser.waitForAngularEnabled(false);
    let createAlertWidgetPage = new CreateAlertWidgetPage();
    let tmConfigPage = new TMConfigurationPage();

    DataProvider(PID['CreateAlertWidget'], (testdata) => {
        it('Should drag the Create-Alert widget', async () => {
            tmConfigPage.addGeneralTab();
            tmConfigPage.editGeneralTab("Create-Alert");
            tmConfigPage.dragAndDrop(createAlertWidgetPage.CreateAlertWidget);
        });

        it('Should create and publish an Alert', async () => {
            browser.driver.sleep(5000);
            createAlertWidgetPage.createAlert(testdata);
            browser.driver.sleep(2000);
        });

        it('Threat Monitor Save', async () => {
            tmConfigPage.clickTMSave();
            browser.driver.sleep(5000);
        });
    });
});