import { browser } from "protractor";
import { TMConfigurationPage } from "../../PageObjects/PID-PageObjects/TMConfigurationPage";
import { AlertsWidgetPage } from "../../PageObjects/PID-PageObjects/AlertsWidgetPage";
import { expect } from "chai";
import { PID } from "../../Utilities/ExcelToJson";
var DataProvider = require('jasmine-data-provider');

describe('Alerts Widget', () => {
    browser.waitForAngularEnabled(false);
    let alertsWidgetPage = new AlertsWidgetPage();
    let tmConfigPage = new TMConfigurationPage();

    DataProvider(PID['AlertsWidget'], (testdata) => {
        it('Should drag the Alerts widget', async () => {
            tmConfigPage.addGeneralTab();
            tmConfigPage.editGeneralTab("Alerts-MapAlerts");
            browser.driver.sleep(3000);
            tmConfigPage.scrollIntoView(tmConfigPage.TargetWindow);
            tmConfigPage.dragAndDrop(alertsWidgetPage.AlertsWidget);
        });

        it('Should configure Alerts widget', async () => {
            browser.driver.sleep(2000);
            alertsWidgetPage.addVigilanceAlert();
            browser.driver.sleep(2000);
            alertsWidgetPage.filterByLocation(testdata);
            browser.driver.sleep(2000);
        });

        it('Threat Monitor Save', async () => {
            tmConfigPage.clickTMSave();
            browser.driver.sleep(2000);
        });
    });
});