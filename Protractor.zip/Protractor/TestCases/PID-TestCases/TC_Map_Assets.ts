import { browser } from "protractor";
import { MapWidgetPage } from "../../PageObjects/PID-PageObjects/MapWidgetPage";
import { Map_AssetsPage } from "../../PageObjects/PID-PageObjects/Map_AssetsPage";
import { TMConfigurationPage } from "../../PageObjects/PID-PageObjects/TMConfigurationPage";
import { expect } from "chai";
import { PID } from "../../Utilities/exceltojson";
var DataProvider = require('jasmine-data-provider');

describe('Map Widget - Assets', () => {
    browser.waitForAngularEnabled(false);
    let mapWidgetPage = new MapWidgetPage();
    let mapAssets = new Map_AssetsPage();
    let tmConfigPage = new TMConfigurationPage();

    DataProvider(PID['MapWidget_Assets'], (testdata) => {
        it('Should drag the Map widget', async () => {
            tmConfigPage.dragAndDrop(mapWidgetPage.MapWidget);
        });

        it('View added GPS Assets in Map', async () => {
            mapAssets.showAssetsInMap(testdata);
            browser.driver.sleep(2000);
        });

        it('Threat Monitor Save', async () => {
            tmConfigPage.clickTMSave();
            browser.driver.sleep(2000);
        });
    });
});