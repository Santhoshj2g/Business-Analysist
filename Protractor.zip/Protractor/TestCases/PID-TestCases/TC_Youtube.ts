import { browser } from "protractor";
import { YouTubeWidgetPage } from "../../PageObjects/PID-PageObjects/YouTubeWidgetPage";
import { TMConfigurationPage } from "../../PageObjects/PID-PageObjects/TMConfigurationPage";
import { expect } from "chai";
import { PID } from "../../Utilities/ExcelToJson"
var DataProvider = require('jasmine-data-provider');

describe('YouTube Widget', () => {
    browser.waitForAngularEnabled(false);
    let youtubeWidgetPage = new YouTubeWidgetPage();
    let tmConfigPage = new TMConfigurationPage();

    DataProvider(PID['YouTubeWidget'], (testdata) => {
        it('Should drag the YouTube widget', async () => {
            tmConfigPage.addGeneralTab();
            tmConfigPage.editGeneralTab("Youtube");
            tmConfigPage.dragAndDrop(youtubeWidgetPage.YouTubeWidget);
        });
        
        it('Should search and play the you tube video', async () => {
            youtubeWidgetPage.playVideosInYoutube(testdata);
            browser.driver.sleep(2000);
        });

        it('Threat Monitor Save', async () => {
            tmConfigPage.clickTMSave();
            browser.driver.sleep(5000);
        });
    });
});