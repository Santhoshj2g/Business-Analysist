import { browser } from "protractor";
import { AssetsWidgetPage } from "../../PageObjects/PID-PageObjects/AssetsWidgetPage";
import { TMConfigurationPage } from "../../PageObjects/PID-PageObjects/TMConfigurationPage";
import { PID } from "../../Utilities/ExcelToJson";
var DataProvider = require('jasmine-data-provider');

describe('Assets Widget', () => {
    browser.waitForAngularEnabled(false);
    let assets = new AssetsWidgetPage();
    let tmConfigPage = new TMConfigurationPage();

    DataProvider(PID['AssetsWidget'], (testdata) => {
        it('Should drag the Assets widget', async () => {
            tmConfigPage.addGeneralTab();
            tmConfigPage.editGeneralTab("Assets-MapAssets");
            tmConfigPage.dragAndDrop(assets.AssetsWidget);
        });

        it('Should configure Assets widget', async () => {
            //assets.assetsDetail(testdata.Asset1)
            browser.driver.sleep(5000);
        });

        it('Threat Monitor Save', async () => {
            tmConfigPage.clickTMSave();
            browser.driver.sleep(2000);
        });
    });
});