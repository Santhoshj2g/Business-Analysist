import { ElementFinder, element, by } from "protractor";
import { BasePage } from "./BasePage";

export class LogoutPage extends BasePage {

    Welcome: ElementFinder;
    Logout: ElementFinder;
    SignOutPageElement: ElementFinder;

    constructor() {
        super();
        this.Welcome = element(by.xpath("//span[text()='Welcome']"));
        this.Logout = element(by.xpath("//a[text()='Logout']"));
        this.SignOutPageElement = element(by.xpath("//div[text()='Which account do you want to sign out of?']"));
    }

    logOut = () => {
        this.clickElement(this.Welcome);
        this.clickElement(this.Logout);
    }

    logoutAccount = (testdata) => {
        var elem = element(by.xpath("//div//small[text()='" + testdata + "']"));
        this.clickElement(elem);
    }
}