import { ElementFinder, element, by } from "protractor";
import { BasePage } from "./BasePage";

export class DashboardPage extends BasePage {

    PID: ElementFinder;
    PES: ElementFinder;
    DD: ElementFinder;
    BV: ElementFinder;

    constructor() {
        super();
        this.PID = element(by.xpath("//a[contains(text(),'PID')]"));
        this.PES = element(by.xpath("//a[contains(text(),'PES')]"));
        this.DD = element(by.xpath("//a[contains(text(),'Due Diligence')]"));
        this.BV = element(by.xpath("//a[contains(text(),'Business Verification (PBV)')]"));
    }

    clickPID = () => {
        this.clickElement(this.PID);
    }

    clickPES = () => {
        this.clickElement(this.PES);
    }

    clickDueDiligence = () => {
        this.clickElement(this.DD);
    }

    clickBV = () => {
        this.clickElement(this.BV);
    }
}