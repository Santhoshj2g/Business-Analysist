import { ElementFinder, element, by } from "protractor";
import { BasePage } from "./BasePage";

export class LoginPage_Client extends BasePage {

    EmailAddress: ElementFinder;
    Password: ElementFinder;
    SignIn: ElementFinder;
    VerificationPageElement: ElementFinder;
    SendCode: ElementFinder;
    CallMe: ElementFinder;
    MAC_Client: ElementFinder;

    constructor() {
        super();
        this.EmailAddress = element(by.id("email"));
        this.Password = element(by.id("password"));
        this.SignIn = element(by.xpath("//button[text()='Sign in']"));
        this.VerificationPageElement = element(by.xpath("//label[text()='Verify your Identity']"));
        this.SendCode = element(by.css("div>button#verifyCode"));
        this.CallMe = element(by.css("div>button#verifyPhone"));
        this.MAC_Client = element(by.xpath("//h5[text()='Management Action Center ']"));
    }

    loginClient = (testdata) => {
        this.sendKeys(this.EmailAddress, testdata.EmailAddress);
        this.sendKeys(this.Password, testdata.Password)
        this.clickElement(this.SignIn);
        this.waitForElementVisibility(this.VerificationPageElement);
    }

    sendCodeForVerfication = () => {
        this.clickElement(this.SendCode);
    }

    callForVerfication = () => {
        this.clickElement(this.CallMe);
    }
}