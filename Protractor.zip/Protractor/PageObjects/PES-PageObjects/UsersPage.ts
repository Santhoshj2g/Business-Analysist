import { ElementFinder, element, by } from "protractor";
import { BasePage } from "../BasePage";

export class UsersPage extends BasePage {

    CreateUser_Btn: ElementFinder;
    SearchUser: ElementFinder;

    AccountType: ElementFinder;
    UserType: ElementFinder;
    EmailID: ElementFinder;
    Role: ElementFinder;
    UserStatus: ElementFinder;
    Manager: ElementFinder;
    Designation: ElementFinder;
    FirstName: ElementFinder;
    MiddleName: ElementFinder;
    LastName: ElementFinder;
    Country: ElementFinder;
    TimeZone: ElementFinder;
    Locale: ElementFinder;
    SearchCustomer: ElementFinder;

    constructor() {
        super();
        this.CreateUser_Btn = element(by.xpath("//button[contains(text(),'Create New User')]"));
        this.SearchUser = element(by.css("app-users-list input.global-filter"));
        
        this.AccountType = element(by.css("[formcontrolname='accountType'] p-dropdown"));
        this.UserType = element(by.css("[formcontrolname='userTypeId'] p-dropdown"));
        this.EmailID = element(by.css("[formcontrolname='loginId'] input"));
        this.Role = element(by.css("[formcontrolname='lAppUserRole'] p-multiselect"));
        this.UserStatus = element(by.css("[formcontrolname='userStatusId'] p-dropdown"));
        this.Manager = element(by.css("[formcontrolname='manager'] input"));
        this.Designation = element(by.css("[formcontrolname='designationId'] p-dropdown"));
        this.FirstName = element(by.css("[formcontrolname='firstName']"));
        this.MiddleName = element(by.css("[formcontrolname='middleName']"));
        this.LastName = element(by.css("[formcontrolname='lastName']"));
        this.Country = element(by.css("[formcontrolname='countryId'] p-dropdown"));
        this.TimeZone = element(by.css("[formcontrolname='timeZoneId'] p-dropdown"));
        this.Locale = element(by.css("[formcontrolname='localeId'] p-dropdown"));
        this.SearchCustomer = element(by.css("app-create-user input.global-filter"));
    }

    clickCreateUser = () => {
        this.clickElement(this.CreateUser_Btn);
    }

    fillUserDetails = (testdata) => {
        this.selectDropdownValue(this.AccountType, testdata.AccountType);
        this.selectDropdownValue(this.UserType, testdata.UserType);
        this.autoCompleteTextBox(this.EmailID, testdata.EmailID);
        this.multiselectDropdown(this.Role);
        this.selectDropdownValue(this.UserStatus, testdata.UserStatus);
        this.autoCompleteTextBox(this.Manager, testdata.Manager);
        this.selectDropdownValue(this.Designation, testdata.Designation)
        this.enterContactNumber('MobileNo', testdata.Country, testdata.MobileNumber);
        this.enterContactNumber('Landline Number', testdata.Country, testdata.LandlineNumber);
        this.enterContactNumber('Fax', testdata.Country, testdata.Fax);
        this.selectDropdownValue(this.Country, testdata.Country);
        this.selectDropdownValue(this.TimeZone, testdata.TimeZone);
        this.selectDropdownValue(this.Locale, testdata.Locale);
        this.selectCheckbox_Table(testdata.Customer1);
        // this.selectFieldName_Checkboxes(testdata.Customer2);
        // this.selectFieldName_Checkboxes(testdata.Customer3);
    }
}