import { ElementFinder, element, by, browser } from "protractor";
import { BasePage } from "../BasePage";

export class DashboardPage_PES extends BasePage {

    Mac: ElementFinder;
    Users: ElementFinder;
    SupplierConfiguration: ElementFinder;
    Services: ElementFinder;
    Packages: ElementFinder;
    Administration: ElementFinder;
    Clients: ElementFinder;
    Profile: ElementFinder;
   
    constructor() {
        super();
        this.Mac = element(by.xpath("//h5[text()='Management Action Center ']")); 
        this.Users = element(by.css("[title='Users'] a")); 
        this.SupplierConfiguration = element(by.css("[title='Supplier Configuration'] a"));
        this.Services = element(by.css("[title='Services'] a"));
        this.Packages = element(by.css("[title='Packages'] a"));
        this.Administration = element(by.css("[title='Administration'] a"));
        this.Clients = element(by.css("[title='Clients'] a")); 
        this.Profile = element(by.xpath("//pnk-portlet[@title='Administration']//p[text()='Profile']"));
    }

    clickUsers = () => {
        this.clickElement(this.Users);
    }

    clickSupplier = () => {
        this.clickElement(this.SupplierConfiguration);
    }

    clickServices = () => {
        this.clickElement(this.Services);
    }

    clickPackages = () => {
        this.clickElement(this.Packages);
    }

    clickAdministration = () => {
        this.clickElement(this.Administration);
    }

    clickClients = () => {
        this.clickElement(this.Clients);
    }

    clickProfile = () => {
        this.clickElement(this.Profile);
    }

    navigateToDashboard = (Url) => {
        browser.get(Url);
    }
}