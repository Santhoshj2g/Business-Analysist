import { ElementFinder, element, by } from "protractor";
import { BasePage } from "../BasePage";

export class ProfilePage extends BasePage {

    CreateNewCase_Btn: ElementFinder;
    CustomerName: ElementFinder;
    Location: ElementFinder;
    Department: ElementFinder;
    Priority: ElementFinder;
    Position: ElementFinder;
    CoreInformation: ElementFinder;
    FirstName: ElementFinder;
    LastName: ElementFinder;
    EmailId: ElementFinder;
    PackagesAndServices: ElementFinder;
    Create_Btn: ElementFinder;
    AdvanceSearch: ElementFinder;
    Search_Btn: ElementFinder;
    Action: ElementFinder;
    Notes: ElementFinder;
    AddNote_Btn: ElementFinder;

    constructor() {
        super();
        this.CreateNewCase_Btn = element(by.xpath("//button[contains(text(),'Create New Case')]"));
        this.CustomerName = element(by.css("[formcontrolname='clientConfigId'] p-dropdown"));
        this.Location = element(by.css("[formcontrolname='clientLocationDetailsId'] p-dropdown"));
        this.Department = element(by.css("[formcontrolname='departmentRefcode'] p-dropdown"));
        this.Priority = element(by.css("[formcontrolname='priorityRefcode'] p-dropdown"));
        this.Position = element(by.css("[formcontrolname='positionRefcode'] p-dropdown"));

        this.CoreInformation = element(by.xpath("//span[contains(text(),'Core Information')]"));
        this.FirstName = element(by.xpath("//label[contains(text(),'First Name')]/..//input"));
        this.LastName = element(by.xpath("//label[contains(text(),'Last Name')]/..//input"));
        this.EmailId = element(by.xpath("//label[contains(text(),'EmailId')]/..//input"));

        this.PackagesAndServices = element(by.xpath("//span[contains(text(),'Packages & Services')]"));
        this.Create_Btn = element(by.xpath("//button[contains(text(),'Create')]"));

        this.AdvanceSearch = element(by.xpath("//a[contains(text(),'Advance Search')]"));
        this.Search_Btn = element(by.xpath("//button[contains(text(),'SEARCH')]"));

        //Profile Menu
        this.Action = element(by.css("[formcontrolname='actionRefcode'] p-dropdown"));
        this.Notes = element(by.css("[formcontrolname='noteText'] "));
        this.AddNote_Btn = element(by.xpath("//button[contains(text(),'ADD NOTE')]"));
    }
}