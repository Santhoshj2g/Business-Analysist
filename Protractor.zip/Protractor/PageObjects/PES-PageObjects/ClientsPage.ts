import { ElementFinder, element, by } from "protractor";
import { BasePage } from "../BasePage";

export class ClientsPage extends BasePage {

    SaveAll_Btn: ElementFinder;
    Save_Btn: ElementFinder;
    Add_Btn: ElementFinder;

    ConfigureNewClient_Btn: ElementFinder;
    RequestingRegion: ElementFinder;
    RequestingOffice: ElementFinder;
    Client: ElementFinder;
    Configure_Btn: ElementFinder;

    ClientDetailsTab: ElementFinder;
    USRNumber: ElementFinder;
    Address1: ElementFinder;
    Address2: ElementFinder;
    Country: ElementFinder;
    StateProvince: ElementFinder;
    City: ElementFinder;
    PostalCode: ElementFinder;
    Website: ElementFinder;
    TimeZone: ElementFinder;
    Locale: ElementFinder;
    AddContact_Btn: ElementFinder;
    FirstName: ElementFinder;
    LastName: ElementFinder;
    EmailID: ElementFinder;
    Extension: ElementFinder;
    ContactTitle: ElementFinder;
    ContactType: ElementFinder;

    LocationDetailsTab: ElementFinder;
    LocationName: ElementFinder;
    Description: ElementFinder;
    CreateNew_Btn: ElementFinder;

    PackagesAndServicesTab: ElementFinder;
    AddExistingPackages_Btn: ElementFinder;
    AddExistingServices_Btn: ElementFinder;

    CaseEntryDetailsTab: ElementFinder;
    SelectCaseEntryFields_Btn: ElementFinder;

    constructor() {
        super();
        this.SaveAll_Btn = element(by.xpath("//button[contains(text(),'SAVE')]"));
        this.Save_Btn = element(by.xpath("//p-dialog//button[contains(text(),'Save')]"));
        this.Add_Btn = element(by.xpath("//p-dialog//button[contains(text(),'ADD')]"));

        //ConfigureClient
        this.ConfigureNewClient_Btn = element(by.xpath("//button[contains(text(),'CONFIGURE NEW CLIENT')]"));
        this.RequestingRegion = element(by.css("[formcontrolname='requestingRegionId'] p-dropdown"));
        this.RequestingOffice = element(by.css("[formcontrolname='requestingOfficeId'] p-dropdown"));
        this.Client = element(by.css("[formcontrolname='clientDetails'] p-dropdown"));
        this.Configure_Btn = element(by.xpath("//button[normalize-space()='CONFIGURE']"));

        //ClientDetails-Tab
        this.ClientDetailsTab = element(by.xpath("//li[@role='tab']//span[text()='Client Details']"));
        this.USRNumber = element(by.css("[formcontrolname='usrDetails'] p-multiselect"));

        this.Address1 = element(by.css("[formcontrolname='address1'] input"));
        this.Address2 = element(by.css("[formcontrolname='address2'] input"));
        this.Country = element(by.css("[formcontrolname='countryId'] p-dropdown"));
        this.StateProvince = element(by.css("[formcontrolname='state'] p-dropdown"));
        this.City = element(by.css("[formcontrolname='city'] input"));
        this.PostalCode = element(by.css("[formcontrolname='postalCode'] input"));
        this.Website = element(by.css("[formcontrolname='webUrl'] input"));
        this.TimeZone = element(by.css("[formcontrolname='timeZoneId'] p-dropdown"));
        this.Locale = element(by.css("[formcontrolname='localeId'] p-dropdown"));

        this.AddContact_Btn = element(by.xpath("//button[contains(text(),'Add Contact')]"));
        this.FirstName = element(by.xpath("//label[contains(text(),'First Name')]/..//input"));
        this.LastName = element(by.xpath("//label[contains(text(),'Last Name')]/..//input"));
        this.EmailID = element(by.xpath("//label[contains(text(),'Email ID')]/..//input"));
        this.Extension = element(by.xpath("//label[contains(text(),'Extension')]/..//input"));
        this.ContactTitle = element(by.xpath("//label[contains(text(),'Contact Title')]/..//input"));
        this.ContactType = element(by.xpath("//label[contains(text(),'Contact Type')]/..//p-multiselect"));

        //LocationDetails-Tab
        this.LocationDetailsTab = element(by.xpath("//li[@role='tab']//span[text()='Location Details']"));
        this.LocationName = element(by.css("[formcontrolname='locationName'] input"));
        this.Description = element(by.css("[formcontrolname='description'] input"));
        this.CreateNew_Btn = element(by.xpath("//button[contains(text(),'CREATE NEW')]"));

        //===> PackagesAndServices-Tab
        this.PackagesAndServicesTab = element(by.xpath("//li[@role='tab']//span[text()='Packages & Services']"));
        this.AddExistingPackages_Btn = element(by.xpath("//button[contains(text(),'Add Existing packages')]"));
        this.AddExistingServices_Btn = element(by.xpath("//button[contains(text(),'Add Existing services')]"));

        //===> CaseEntryDetails-Tab
        this.CaseEntryDetailsTab = element(by.xpath("//li[@role='tab']//span[text()='Case Entry Details']"));
        this.SelectCaseEntryFields_Btn = element(by.xpath("//button[contains(text(),'Select Case Entry fields')]"));
    }

    selectLocationCode = (location) => {
        var elem = element(by.xpath("//span[contains(text(),'" + location + "')]/ancestor::tr//td[contains(@class,'pinkerton-link-text')]//span"));
        this.clickElement(elem);
    }

    saveAll = () => {
        this.clickElement(this.SaveAll_Btn);
    }

    configureNewClient = (testdata) => {
        this.clickElement(this.ConfigureNewClient_Btn);
        this.selectDropdownValue(this.RequestingRegion, testdata.RequestingRegion);
        this.selectDropdownValue(this.RequestingOffice, testdata.RequestingOffice);
        this.selectDropdownValue(this.Client, testdata.Client);
        this.selectCheckbox_Table(testdata.USRNumber);
        this.clickElement(this.Configure_Btn);
        this.getAlertInfo();
        this.clickSpanElement(testdata.Client);
    }

    fillClientDetailsTab = (testdata) => {
        this.clickElement(this.ClientDetailsTab);
        //this.autoCompleteDropdown(this.USRNumber, testdata.USRNumber);
        this.sendKeys(this.Address1, testdata.Address1);
        this.sendKeys(this.Address2, testdata.Address2);
        this.autoCompleteDropdown(this.Country, testdata.Country);
        this.selectDropdownValue(this.StateProvince, testdata.StateProvince);
        this.sendKeys(this.City, testdata.City);
        this.sendKeys(this.PostalCode, testdata.PostalCode);
        this.autoCompleteDropdown(this.TimeZone, testdata.TimeZone);
        this.selectDropdownValue(this.Locale, testdata.Locale);
        this.saveAll();
        this.getAlertInfo();

        this.clickElement(this.AddContact_Btn);
        this.sendKeys(this.FirstName, testdata.FirstName);
        this.sendKeys(this.LastName, testdata.LastName);
        this.sendKeys(this.EmailID, testdata.EmailID);
        this.enterContactNumber('Mobile Number', testdata.Country, testdata.MobileNumber);
        this.enterContactNumber('Landline Number', testdata.Country, testdata.LandlineNumber);
        this.enterContactNumber('Fax Number', testdata.Country, testdata.FaxNumber);
        this.sendKeys(this.Extension, testdata.Extension);
        this.sendKeys(this.ContactTitle, testdata.ContactTitle);
        this.multiselectDropdown(this.ContactType);
        this.clickElement(this.Save_Btn);
        this.getAlertInfo();
    }

    fillLocationDetailsTab = (testdata) => {
        this.clickElement(this.LocationDetailsTab);
        this.sendKeys(this.LocationName, testdata.LocationName);
        this.sendKeys(this.Description, testdata.Description);
        this.clickElement(this.CreateNew_Btn);
        this.getAlertInfo();
        this.selectLocationCode(testdata.LocationName);

        //this.clickElement(this.LocationDetailsTab);
        this.sendKeys(this.Address1, testdata.Address1);
        this.sendKeys(this.Address2, testdata.Address2);
        this.autoCompleteDropdown(this.Country, testdata.Country);
        this.autoCompleteDropdown(this.StateProvince, testdata.StateProvince);
        this.sendKeys(this.City, testdata.City);
        this.sendKeys(this.PostalCode, testdata.PostalCode);
        this.sendKeys(this.Website, testdata.Website);
        this.autoCompleteDropdown(this.TimeZone, testdata.TimeZone);
        this.autoCompleteDropdown(this.Locale, testdata.Locale);
        this.saveAll();
        this.getAlertInfo();
    }

    fillPackagesAndServicesTab = (testdata) => {
        this.clickElement(this.PackagesAndServicesTab);
        this.clickElement(this.AddExistingPackages_Btn);
        this.searchAndSelectCheckbox_Table(testdata.Package1);
        this.clickElement(this.Add_Btn);
        this.getAlertInfo();
        this.clickElement(this.AddExistingServices_Btn);
        this.searchAndSelectCheckbox_Table(testdata.Service1);
        this.clickElement(this.Add_Btn);
        this.getAlertInfo();
    }
}