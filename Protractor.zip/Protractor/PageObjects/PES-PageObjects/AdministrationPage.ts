import { ElementFinder, element, by } from "protractor";
import { BasePage } from "../BasePage";

export class AdministrationPage extends BasePage {

    UniversityTab: ElementFinder;
    AddUniversity_Btn: ElementFinder;
    UniversityName: ElementFinder;
    Type: ElementFinder;
    PhysicalVisitConducted: ElementFinder;
    DateOfLastInvestigationDone_University: ElementFinder;
    CommunicationFrequencyType: ElementFinder;
    Time: ElementFinder;
    TimeZone: ElementFinder;
    MandatoryRequirementList: ElementFinder;
    CompanyList: ElementFinder;

    EmployerTab: ElementFinder;
    AddEmployer_Btn: ElementFinder;
    EmployeeName: ElementFinder;
    EmployerClassification: ElementFinder;
    DateOfLastInvestigationDone_Employer: ElementFinder;
    CommunicationFrequencyValue: ElementFinder;

    Address1_University: ElementFinder;
    Address2_University: ElementFinder;
    Address1_Employer: ElementFinder;
    Address2_Employer: ElementFinder;
    Country: ElementFinder;
    StateProvinceRegion: ElementFinder;
    CityDistrict_University: ElementFinder;
    ZIPPostalcode: ElementFinder;
    Website_University: ElementFinder;
    CityDistrict_Employer: ElementFinder;
    Website_Employer: ElementFinder;
    ContactNumber_University: ElementFinder;
    ContactNumber_Employer: ElementFinder;
    AdditionalContactNumber: ElementFinder;
    Fax: ElementFinder;
    Description: ElementFinder;

    Save_Btn: ElementFinder;
    SaveAll_Btn: ElementFinder;

    constructor() {
        super();
        this.UniversityTab = element(by.xpath("//li[@role='tab']//span[text()='University']"));
        this.AddUniversity_Btn = element(by.xpath("//button[contains(text(),'Add University')]"));
        this.UniversityName = element(by.css("[formcontrolname='universityName'] input"));
        this.Type = element(by.css("[formcontrolname='typeId'] p-dropdown"));
        this.PhysicalVisitConducted = element(by.css("[formcontrolname='isPhysicalVisitConducted'][label='Yes'] div[role='radio']"));
        this.DateOfLastInvestigationDone_University = element(by.css("[formcontrolname='dateOfLastInvestigationDate']"));
        this.CommunicationFrequencyType = element(by.css("[formcontrolname='frequencyId']"));
        this.Time = element(by.css("[formcontrolname='cutOfTimeId'] p-dropdown"));
        this.TimeZone = element(by.css("[formcontrolname='timeZoneId'] p-dropdown"));
        this.MandatoryRequirementList = element(by.css("[formcontrolname='mandatoryRequirementList'] textarea"));
        this.CompanyList = element(by.css("[formcontrolname='companyList'] textarea"));

        this.EmployerTab = element(by.xpath("//li[@role='tab']//span[text()='Employer']"));
        this.AddEmployer_Btn = element(by.xpath("//button[contains(text(),'Add Employer')]"));
        this.EmployeeName = element(by.css("[formcontrolname='employerName']"));
        this.EmployerClassification = element(by.css("[formcontrolname='employerClassificationId'] p-dropdown"));
        this.DateOfLastInvestigationDone_Employer = element(by.css("[formcontrolname='dateOfLastInvestigationDone']"));
        this.CommunicationFrequencyValue = element(by.css("[formcontrolname='communicationFrequencyValue']"));

        this.Address1_University = element(by.css("[formcontrolname='address1'] input"));
        this.Address2_University = element(by.css("[formcontrolname='address2'] input"));
        this.Address1_Employer = element(by.css("[formcontrolname='address1']"));
        this.Address2_Employer = element(by.css("[formcontrolname='address2']"));
        this.Country = element(by.css("[formcontrolname='countryId']"));
        this.StateProvinceRegion = element(by.css("[formcontrolname='stateId'] p-dropdown"));
        this.CityDistrict_University = element(by.css("[formcontrolname='cityName'] input"));
        this.ZIPPostalcode = element(by.css("[formcontrolname='postalCode'] input"));
        this.Website_University = element(by.css("[formcontrolname='webSite'] input"));
        this.CityDistrict_Employer = element(by.css("[formcontrolname='cityName']"));
        this.Website_Employer = element(by.css("[formcontrolname='webSite']"));
        this.Description = element(by.css("[formcontrolname='description']"));
        
        this.Save_Btn = element(by.xpath("//p-dialog//button[contains(text(),'Save')]"));
        this.SaveAll_Btn = element(by.xpath("//button[contains(text(),'SAVE')]"));
    }

    clickAddUniversity = () => {
        this.clickElement(this.UniversityTab);
        this.clickElement(this.AddUniversity_Btn);
    }

    clickAddEmployer = () => {
        this.clickElement(this.EmployerTab);
        this.clickElement(this.AddEmployer_Btn);
    }

    saveAll = () => {
        this.clickElement(this.SaveAll_Btn);
        this.clickElement(this.Confirm);
    }

    fillUniversityDetails = (testdata) => {
        this.sendKeys(this.UniversityName, testdata.UniversityName);
        this.selectDropdownValue(this.Type, testdata.Type);
        this.clickElement(this.PhysicalVisitConducted);
        this.datePicker(this.DateOfLastInvestigationDone_University, testdata.DateOfLastInvestigationDone_University);
        this.selectDropdownValue(this.CommunicationFrequencyType, testdata.CommunicationFrequencyType);
        this.autoCompleteDropdown(this.Time, "10 AM");
        this.autoCompleteDropdown(this.TimeZone, testdata.TimeZone);
        this.sendKeys(this.MandatoryRequirementList, testdata.MandatoryRequirementList);
        this.sendKeys(this.CompanyList, testdata.CompanyList);

        this.sendKeys(this.Address1_University, testdata.Address1);
        this.sendKeys(this.Address2_University, testdata.Address2);
        this.autoCompleteDropdown(this.Country, testdata.Country);
        this.selectDropdownValue(this.StateProvinceRegion, testdata.StateProvinceRegion);
        this.sendKeys(this.CityDistrict_University, testdata.CityDistrict);
        this.sendKeys(this.ZIPPostalcode, testdata.ZIPPostalcode);
        this.sendKeys(this.Website_University, testdata.Website);
        this.enterContactNumber('Contact Number', testdata.Country, testdata.ContactNumber)
        this.enterContactNumber('Additional Contact Number', testdata.Country, testdata.AdditionalContactNumber)
        this.enterContactNumber('Fax', testdata.Country, testdata.Fax)
        this.sendKeys(this.Description, testdata.Description_University);
        this.saveAll();
        this.getAlertInfo();
    }

    fillEmployerDetails = (testdata) => {
        this.sendKeys(this.EmployeeName, testdata.EmployeeName);
        this.selectDropdownValue(this.EmployerClassification, testdata.EmployerClassification);
        this.clickElement(this.PhysicalVisitConducted);
        this.datePicker(this.DateOfLastInvestigationDone_Employer, testdata.DateOfLastInvestigationDone_Employer);
        this.selectDropdownValue(this.CommunicationFrequencyType, testdata.CommunicationFrequencyType);
        this.sendKeys(this.CommunicationFrequencyValue, testdata.CommunicationFrequencyValue);

        this.sendKeys(this.Address1_Employer, testdata.Address1);
        this.sendKeys(this.Address2_Employer, testdata.Address2);
        this.autoCompleteDropdown(this.Country, testdata.Country);
        this.selectDropdownValue(this.StateProvinceRegion, testdata.StateProvinceRegion);
        this.sendKeys(this.CityDistrict_Employer, testdata.CityDistrict);
        this.sendKeys(this.ZIPPostalcode, testdata.ZIPPostalcode);
        this.sendKeys(this.Website_Employer, testdata.Website);
        this.enterContactNumber('Contact Number', testdata.Country, testdata.ContactNumber);
        this.enterContactNumber('Additional Contact Number', testdata.Country, testdata.AdditionalContactNumber);
        this.enterContactNumber('Fax', testdata.Country, testdata.Fax);
        this.sendKeys(this.Description, testdata.Description_University);
        this.saveAll();
        this.getAlertInfo();
    }
}