import { ElementFinder, element, by } from "protractor";
import { BasePage } from "../BasePage";

export class SuppliersPage extends BasePage {

    SaveAll_Btn: ElementFinder;
    Save_Btn: ElementFinder;
    CreateNewSupplier_Btn: ElementFinder;
    SupplierDetailsTab: ElementFinder;
    SupplierName: ElementFinder;
    SupplierType: ElementFinder;
    ServiceType: ElementFinder;
    ParentSupplier: ElementFinder;
    BusinessEntity: ElementFinder;
    Address1: ElementFinder;
    Address2: ElementFinder;
    Country: ElementFinder;
    StateProvince: ElementFinder;
    City: ElementFinder;
    PostalCode: ElementFinder;
    AddContact_Btn: ElementFinder;
    FirstName: ElementFinder;
    LastName: ElementFinder;
    EmailID: ElementFinder;
    Extension: ElementFinder;
    ContactTitle: ElementFinder;
    ContactType: ElementFinder;
    OperationalDetailsTab: ElementFinder;
    SelectServiceLine: ElementFinder;
    AddServiceLine_Btn: ElementFinder;
    LicenseInsuranceCertificatesTab: ElementFinder;
    ManagedSupplierTab: ElementFinder;

    constructor() {
        super();
        this.SaveAll_Btn = element(by.xpath("//button[contains(text(),'SAVE')]"));
        this.Save_Btn = element(by.xpath("//p-dialog//button[contains(text(),'Save')]"));

        this.CreateNewSupplier_Btn = element(by.xpath("//button[contains(text(),'Create New Supplier')]"));
        this.SupplierDetailsTab = element(by.xpath("//li[@role='tab']//span[text()='SupplierDetails']"));
        this.SupplierName = element(by.css("[formcontrolname='supplierName'] input"));
        this.SupplierType = element(by.css("[formcontrolname='supplierType'] p-dropdown"));
        this.ServiceType = element(by.css("[formcontrolname='serviceType'] p-dropdown"));
        this.ParentSupplier = element(by.css("[formcontrolname='parentSupplierRefcode'] p-dropdown"));
        this.BusinessEntity = element(by.css("[formcontrolname='businessEntity'] p-dropdown"));

        this.Address1 = element(by.css("[formcontrolname='address1'] input"));
        this.Address2 = element(by.css("[formcontrolname='address2'] input"));
        this.Country = element(by.css("[formcontrolname='countryId'] p-dropdown"));
        this.StateProvince = element(by.css("[formcontrolname='stateId'] p-dropdown"));
        this.City = element(by.css("[formcontrolname='city'] input"));
        this.PostalCode = element(by.css("[formcontrolname='postalCode'] input"));

        this.AddContact_Btn = element(by.xpath("//button[contains(text(),'Add Contact')]"));
        this.FirstName = element(by.xpath("//label[contains(text(),'First Name')]/..//input"));
        this.LastName = element(by.xpath("//label[contains(text(),'Last Name')]/..//input"));
        this.EmailID = element(by.xpath("//label[contains(text(),'Email ID')]/..//input"));
        this.Extension = element(by.xpath("//label[contains(text(),'Extension')]/..//input"));
        this.ContactTitle = element(by.xpath("//label[contains(text(),'Contact Title')]/..//input"));
        this.ContactType = element(by.xpath("//label[contains(text(),'Contact Type')]/..//p-multiselect"));

        this.OperationalDetailsTab = element(by.xpath("//li[@role='tab']//span[text()='Operational Details']"));
        this.SelectServiceLine = element(by.css("[formcontrolname='serviceCategoryId'] p-dropdown"));
        this.AddServiceLine_Btn = element(by.xpath("//button[contains(text(),'ADD SERVICE LINE')]"));

        this.LicenseInsuranceCertificatesTab = element(by.xpath("//li[@role='tab']//span[text()='License Insurance & Certificates']"));
        this.ManagedSupplierTab = element(by.xpath("//li[@role='tab']//span[text()='Managed Supplier']"));
    }

    saveAll = () => {
        this.clickElement(this.SaveAll_Btn);
    }

    fillSupplierDetailsTab = (testdata) => {
        this.clickElement(this.CreateNewSupplier_Btn);
        this.clickElement(this.SupplierDetailsTab);
        this.sendKeys(this.SupplierName, testdata.SupplierName);
        this.selectDropdownValue(this.SupplierType, testdata.SupplierType);
        this.selectDropdownValue(this.ServiceType, testdata.ServiceType);
        this.selectDropdownValue(this.ParentSupplier, testdata.ParentSupplier);
        this.selectDropdownValue(this.BusinessEntity, testdata.BusinessEntity);

        this.sendKeys(this.Address1, testdata.Address1);
        this.sendKeys(this.Address2, testdata.Address2);
        this.autoCompleteDropdown(this.Country, testdata.Country);
        this.selectDropdownValue(this.StateProvince, testdata.StateProvince);
        this.sendKeys(this.City, testdata.City);
        this.sendKeys(this.PostalCode, testdata.PostalCode);
        this.saveAll();
        this.getAlertInfo();

        this.clickElement(this.AddContact_Btn);
        this.sendKeys(this.FirstName, testdata.FirstName);
        this.sendKeys(this.LastName, testdata.LastName);
        this.sendKeys(this.EmailID, testdata.EmailID);
        this.enterContactNumber('Mobile Number', testdata.Country, testdata.MobileNumber);
        this.enterContactNumber('Landline Number', testdata.Country, testdata.LandlineNumber);
        this.enterContactNumber('Fax Number', testdata.Country, testdata.FaxNumber);
        this.sendKeys(this.Extension, testdata.Extension);
        this.sendKeys(this.ContactTitle, testdata.ContactTitle);
        this.multiselectDropdown(this.ContactType);
        this.clickElement(this.Save_Btn);
        this.getAlertInfo();
    }

    fillOperationalDetailsTab = (testdata) => {
        this.clickElement(this.OperationalDetailsTab);
        this.selectDropdownValue(this.SelectServiceLine, testdata.SelectServiceLine);
        this.clickElement(this.AddServiceLine_Btn);
        this.saveAll();
    }
}