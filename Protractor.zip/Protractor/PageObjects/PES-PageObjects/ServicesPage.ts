import { ElementFinder, element, by, browser } from "protractor";
import { BasePage } from "../BasePage";

export class ServicesPage extends BasePage {

    CreateNewService_Btn: ElementFinder;
    SearchService: ElementFinder;
    Save_Service: ElementFinder;
    Save_Btn: ElementFinder;
    Add_Btn: ElementFinder;

    ServiceDetailsTab: ElementFinder;
    ServiceName: ElementFinder;
    ServiceNameAsSeenByClient: ElementFinder;
    ServiceCategory: ElementFinder;
    ProductType: ElementFinder;
    ServiceDescription: ElementFinder;
    OrderReview: ElementFinder;
    MaximumNoOfOrders: ElementFinder;
    CutOffTime: ElementFinder;
    CustomerTATNumberofDays: ElementFinder;
    OperationTATNumberofDays: ElementFinder;
    VendorTATNumberofDays: ElementFinder;
    Currency: ElementFinder;
    Charge: ElementFinder;
    DefaultTaxRate: ElementFinder;
    NumberofYears: ElementFinder;
    ForDataEntry: ElementFinder;
    ForVerification: ElementFinder;
    ForCandidate: ElementFinder;
    AddDisposition_Btn: ElementFinder;
    Description_Disposition: ElementFinder;
    Severity: ElementFinder;
    ColorCode: ElementFinder;
    AddSource_Btn: ElementFinder;
    Source: ElementFinder;
    Description_Source: ElementFinder;
    AddLawOfLand_Btn: ElementFinder;
    Country: ElementFinder;
    StateProvinceRegion: ElementFinder;
    CityDistrict: ElementFinder;
    OrderStatus: ElementFinder;
    Description_LawofLand: ElementFinder;

    ConfigureDataFieldsTab: ElementFinder;
    AddOrderFields_Btn: ElementFinder;
    SearchOrderFields: ElementFinder;
    AddResultFields_Btn: ElementFinder;
    SearchResultFields: ElementFinder;

    ConfigureQuestionsTab: ElementFinder;
    AddFAQ_Btn: ElementFinder;
    Questions: ElementFinder;
    Answer: ElementFinder;
    Sequence: ElementFinder;

    RoutingTab: ElementFinder;
    AddDefaultSupplier_Btn: ElementFinder;
    PESEntity: ElementFinder;
    DefaultSupplier: ElementFinder;
    OrderReview_DefaultSupplier: ElementFinder;
    Currency_DefaultSupplier: ElementFinder;
    Cost_DefaultSupplier: ElementFinder;
    AddRule_Btn: ElementFinder;
    RuleName: ElementFinder;
    Supplier: ElementFinder;
    Rank: ElementFinder;
    TurnaroundDays: ElementFinder;
    CutOffTime_Rule: ElementFinder;
    Currency_Rule: ElementFinder;
    Cost_Rule: ElementFinder;
    AddCriteria_Btn: ElementFinder;
    PESEntity_AddCriteria: ElementFinder;
    ParameterType: ElementFinder;
    Operator: ElementFinder;
    Value: ElementFinder;

    QCParameterTab: ElementFinder;
    AddQCParameter_Btn: ElementFinder;
    Code: ElementFinder;
    Type: ElementFinder;
    AssignedWeightage: ElementFinder;
    Parameter: ElementFinder;

    constructor() {
        super();
        this.CreateNewService_Btn = element(by.xpath("//button[contains(text(),'CREATE NEW SERVICE')]"));
        this.SearchService = element(by.css("app-es-service-configuration-list input.global-filter"));
        this.Save_Service = element(by.xpath("//button[contains(text(),'SAVE')]"));
        this.Save_Btn = element(by.xpath("//p-dialog//button[contains(text(),'Save')]"));
        this.Add_Btn = element(by.xpath("//p-dialog//button[contains(text(),'ADD')]"));

        this.ServiceDetailsTab = element(by.xpath("//li[@role='tab']//span[text()='Service Details']"));
        this.ServiceName = element(by.css("[formcontrolname='serviceName'] input"));
        this.ServiceNameAsSeenByClient = element(by.css("[formcontrolname='serviceNameAsSeenByClient'] input"));
        this.ServiceCategory = element(by.css("[formcontrolname='serviceCategoryId'] p-dropdown"));
        this.ProductType = element(by.css("[formcontrolname='productTypeId'] p-dropdown"));
        this.ServiceDescription = element(by.css("[formcontrolname='serviceDescription']"));
        this.OrderReview = element(by.xpath("//label[contains(text(),'Order Review')]/..//p-dropdown"));
        this.MaximumNoOfOrders = element(by.xpath("//label[contains(text(),'Maximum No Of Orders')]/..//input"));
        this.CutOffTime = element(by.xpath("//label[contains(text(),'Cut Off Time')]/..//p-dropdown"));
        this.CustomerTATNumberofDays = element(by.xpath("//label[contains(text(),'Customer TAT Number of Days')]/..//input"));
        this.OperationTATNumberofDays = element(by.xpath("//label[contains(text(),'Operation TAT Number of Days')]/..//input"));
        this.VendorTATNumberofDays = element(by.xpath("//label[contains(text(),'Vendor TAT Number of Days')]/..//input"));
        this.Currency = element(by.xpath("//label[contains(text(),'Currency')]/..//p-dropdown"));
        this.Charge = element(by.xpath("//label[normalize-space()='Charge']/..//input"));
        this.DefaultTaxRate = element(by.xpath("//label[contains(text(),'Default Tax Rate')]/..//input"));
        this.NumberofYears = element(by.xpath("//label[contains(text(),'Number of Years')]/..//input"));
        this.ForDataEntry = element(by.css("[formcontrolname='forDataEntry']"));
        this.ForVerification = element(by.css("[formcontrolname='forVerification']"));
        this.ForCandidate = element(by.css("[formcontrolname='forCandidate']"));
        this.AddDisposition_Btn = element(by.xpath("//button[contains(text(),'ADD DISPOSITION')]"));
        this.Description_Disposition = element(by.xpath("//p[contains(text(),'Add  Disposition')]/ancestor::p-dialog//textarea"));
        this.Severity = element(by.xpath("//p-dialog//label[contains(text(),'Severity')]/..//p-dropdown"));
        this.ColorCode = element(by.xpath("//p-dialog//label[contains(text(),'Color Code')]/..//p-dropdown"));
        this.AddSource_Btn = element(by.xpath("//button[contains(text(),'Add Source')]"));
        this.Source = element(by.xpath("//p-dialog//label[contains(text(),'Source')]/..//input"));
        this.Description_Source = element(by.xpath("//p-dialog//label[contains(text(),'Description')]/..//textarea"));
        this.AddLawOfLand_Btn = element(by.xpath("//button[contains(text(),'ADD LAW OF LAND')]"));
        this.Country = element(by.xpath("//p-dialog//label[contains(text(),'Country ')]/..//p-dropdown"));
        this.StateProvinceRegion = element(by.xpath("//p-dialog//label[contains(text(),'State/Province/Region')]/..//p-dropdown"));
        this.CityDistrict = element(by.xpath("//p-dialog//label[contains(text(),'City/District')]/..//input"));
        this.OrderStatus = element(by.xpath("//p-dialog//label[contains(text(),'Order Status')]/..//p-dropdown"));
        this.Description_LawofLand = element(by.xpath("//p[contains(text(),'Add Law Of Land')]/ancestor::p-dialog//textarea"));

        this.ConfigureDataFieldsTab = element(by.xpath("//li[@role='tab']//span[text()='Configure Data Fields']"));
        this.AddOrderFields_Btn = element(by.xpath("//button[contains(text(),'ADD ORDER FIELDS')]"));
        this.SearchOrderFields = element(by.css("p-dialog input.global-filter"));
        this.AddResultFields_Btn = element(by.xpath("//button[contains(text(),'ADD RESULT FIELDS')]"));
        this.SearchResultFields = element(by.css("p-dialog input.global-filter"));

        this.ConfigureQuestionsTab = element(by.xpath("//li[@role='tab']//span[text()='Configure Questions']"));
        this.AddFAQ_Btn = element(by.xpath("//button[contains(text(),'ADD FAQ')]"));
        this.Questions = element(by.xpath("//p-dialog//label[contains(text(),'Question')]/..//textarea"));
        this.Answer = element(by.xpath("//p-dialog//label[contains(text(),'Answer')]/..//textarea"));
        this.Sequence = element(by.xpath("//p-dialog//label[contains(text(),'Sequence')]/..//input"));

        this.RoutingTab = element(by.xpath("//li[@role='tab']//span[text()='Routing']"));
        this.AddDefaultSupplier_Btn = element(by.xpath("//button[normalize-space()='ADD DEFAULT SUPPLIER']"));
        this.PESEntity = element(by.xpath("//p-dialog//label[contains(text(),'PES Entity')]/..//p-dropdown"));
        this.DefaultSupplier = element(by.xpath("//p-dialog//label[contains(text(),'Default Supplier')]/..//p-dropdown"));
        this.OrderReview_DefaultSupplier = element(by.xpath("//p-dialog//label[contains(text(),'Order Review')]/..//p-dropdown"));
        this.Currency_DefaultSupplier = element(by.xpath("//p-dialog//label[contains(text(),'Currency')]/..//p-dropdown"));
        this.Cost_DefaultSupplier = element(by.xpath("//p-dialog//label[contains(text(),'Cost')]/..//input"));
        this.AddRule_Btn = element(by.xpath("//button[normalize-space()='ADD RULE']"));
        this.RuleName = element(by.css("[formcontrolname='ruleName'] input"));
        this.Supplier = element(by.css("[formcontrolname='supplierId'] p-dropdown"));
        this.Rank = element(by.css("[formcontrolname='rank'] input"));
        this.TurnaroundDays = element(by.css("[formcontrolname='turnArondDays'] input"));
        this.CutOffTime_Rule = element(by.css("[formcontrolname='cutOfTimeId'] p-dropdown"));
        this.Currency_Rule = element(by.css("[formcontrolname='currencyId'] p-dropdown"));
        this.Cost_Rule = element(by.css("[formcontrolname='cost'] input"));
        this.AddCriteria_Btn = element(by.xpath("//button[normalize-space()='ADD CRITERIA']"));
        this.PESEntity_AddCriteria = element(by.xpath("//p-dialog//label[contains(text(),'PES Entity')]/..//p-dropdown"));
        this.ParameterType = element(by.xpath("//p-dialog//label[contains(text(),'Parameter Type')]/..//p-dropdown"));
        this.Operator = element(by.xpath("//p-dialog//label[contains(text(),'Operator')]/..//p-dropdown"));
        this.Value = element(by.xpath("//p-dialog//label[contains(text(),'Value')]/..//input"));

        this.QCParameterTab = element(by.xpath("//li[@role='tab']//span[text()='QC  Parameter']"));
        this.AddQCParameter_Btn = element(by.xpath("//button[normalize-space()='ADD QC Parameter']"));
        this.Code = element(by.xpath("//p-dialog//label[contains(text(),'Code')]/..//input"));
        this.Type = element(by.xpath("//p-dialog//label[contains(text(),'Type')]/..//p-dropdown"));
        this.AssignedWeightage = element(by.xpath("//p-dialog//label[contains(text(),'Assigned Weightage')]/..//input"));
        this.Parameter = element(by.xpath("//p-dialog//label[contains(text(),'Parameter')]/..//textarea"));
    }

    clickCreateService = () => {
        this.clickElement(this.CreateNewService_Btn);
    }

    saveService = () => {
        this.clickElement(this.Save_Service);
    }

    fillServiceDetailsTab = (testdata) => {
        this.clickElement(this.ServiceDetailsTab);
        this.sendKeys(this.ServiceName, testdata.ServiceName);
        this.sendKeys(this.ServiceNameAsSeenByClient, testdata.ServiceNameAsSeenByClient);
        this.selectDropdownValue(this.ServiceCategory, testdata.ServiceCategory);
        this.selectDropdownValue(this.ProductType, testdata.ProductType);
        this.sendKeys(this.ServiceDescription, testdata.ServiceDescription);

        this.selectDropdownValue(this.OrderReview, testdata.OrderReview);
        this.sendKeys(this.MaximumNoOfOrders, testdata.MaximumNoOfOrders);
        this.autoCompleteDropdown(this.CutOffTime, '6 PM');
        this.sendKeys(this.CustomerTATNumberofDays, testdata.CustomerTATNumberofDays);
        this.sendKeys(this.OperationTATNumberofDays, testdata.OperationTATNumberofDays);
        this.sendKeys(this.VendorTATNumberofDays, testdata.VendorTATNumberofDays);
        this.autoCompleteDropdown(this.Currency, testdata.Currency);
        this.sendKeys(this.Charge, testdata.Charge);
        this.sendKeys(this.DefaultTaxRate, testdata.DefaultTaxRate);
        this.sendKeys(this.NumberofYears, testdata.NumberofYears);
        this.sendKeys(this.ForDataEntry, testdata.ForDataEntry);
        this.sendKeys(this.ForVerification, testdata.ForVerification);
        this.sendKeys(this.ForCandidate, testdata.ForCandidate);
        this.selectAllTheCheckboxes();
        this.clickElement(this.Save_Service);
        this.getAlertInfo();

        this.clickElement(this.AddDisposition_Btn);
        this.sendKeys(this.Description_Disposition, testdata.Description_Disposition);
        this.selectDropdownValue(this.Severity, testdata.Severity);
        this.selectDropdownValue(this.ColorCode, testdata.ColorCode);
        this.clickElement(this.Save_Btn);
        this.getAlertInfo();

        this.clickElement(this.AddSource_Btn);
        this.sendKeys(this.Source, testdata.Source);
        this.sendKeys(this.Description_Source, testdata.Description_Source);
        this.clickElement(this.Save_Btn);
        this.getAlertInfo();

        this.clickElement(this.AddLawOfLand_Btn);
        this.autoCompleteDropdown(this.Country, testdata.Country)
        this.selectDropdownValue(this.StateProvinceRegion, testdata.StateProvinceRegion)
        this.sendKeys(this.CityDistrict, testdata.CityDistrict);
        this.selectDropdownValue(this.OrderStatus, testdata.OrderStatus);
        this.sendKeys(this.Description_LawofLand, testdata.Description_LawofLand);
        this.clickElement(this.Save_Btn);
        this.getAlertInfo();
        this.clickElement(this.Save_Service);
        this.getAlertInfo();
    }

    fillConfigureDataFieldsTab = () => {
        this.clickElement(this.ConfigureDataFieldsTab);
        this.clickElement(this.AddOrderFields_Btn);
        browser.driver.sleep(3000);
        this.selectAllTheCheckboxes();
        this.clickElement(this.Add_Btn);
        browser.driver.sleep(5000);
        this.clickElement(this.AddResultFields_Btn);
        browser.driver.sleep(3000);
        this.selectAllTheCheckboxes();
        this.clickElement(this.Add_Btn);
        browser.driver.sleep(3000);
        // this.clickElement(this.Save_Service);
        // this.getAlertInfo();
    }

    fillConfigureQuestionsTab = (testdata) => {
        this.clickElement(this.ConfigureQuestionsTab);
        this.clickElement(this.AddFAQ_Btn);
        this.sendKeys(this.Questions, testdata.Questions);
        this.sendKeys(this.Answer, testdata.Answer);
        this.selectAllTheCheckboxes();
        this.sendKeys(this.Sequence, testdata.Sequence);
        this.clickElement(this.Save_Btn);
        this.getAlertInfo();
    }

    fillRoutingTab = (testdata) => {
        this.clickElement(this.RoutingTab);
        this.clickElement(this.AddDefaultSupplier_Btn);
        this.selectDropdownValue(this.PESEntity, testdata.PESEntity);
        this.selectDropdownValue(this.DefaultSupplier, testdata.DefaultSupplier);
        this.selectDropdownValue(this.OrderReview_DefaultSupplier, testdata.OrderReview_DefaultSupplier);
        this.autoCompleteDropdown(this.Currency_DefaultSupplier, testdata.Currency_DefaultSupplier)
        this.sendKeys(this.Cost_DefaultSupplier, testdata.Cost_DefaultSupplier);
        this.clickElement(this.Save_Btn);
        this.getAlertInfo();

        this.clickElement(this.AddRule_Btn);
        this.sendKeys(this.RuleName, testdata.RuleName);
        this.selectDropdownValue(this.Supplier, testdata.Supplier);
        this.sendKeys(this.Rank, testdata.Rank);
        // this.sendKeys(this.TurnaroundDays, testdata.TurnaroundDays);
        // this.autoCompleteDropdown(this.CutOffTime_Rule, '6 PM')
        // this.autoCompleteDropdown(this.Currency_Rule, testdata.Currency_Rule)
        // this.sendKeys(this.Cost_Rule, testdata.Cost_Rule);
        this.clickElement(this.Save_Btn);
        this.getAlertInfo();

        // this.clickElement(this.AddCriteria_Btn);
        // this.selectDropdownValue(this.PESEntity_AddCriteria, testdata.PESEntity_AddCriteria);
        // this.selectDropdownValue(this.ParameterType, testdata.ParameterType);
        // this.selectDropdownValue(this.Operator, testdata.Operator);
        // this.sendKeys(this.Value, testdata.Value);
        // this.clickElement(this.Save_Btn);
        this.clickSpanElement('Routing');
    }

    fillQCParameterTab = (testdata) => {
        this.clickElement(this.QCParameterTab);
        this.clickElement(this.AddQCParameter_Btn);
        this.sendKeys(this.Code, testdata.Code);
        this.autoCompleteDropdown(this.Type, testdata.Type);
        this.sendKeys(this.AssignedWeightage, testdata.AssignedWeightage);
        this.sendKeys(this.Parameter, testdata.Parameter);
        this.selectAllTheCheckboxes();
        this.clickElement(this.Save_Btn);
        this.getAlertInfo();
    }
}