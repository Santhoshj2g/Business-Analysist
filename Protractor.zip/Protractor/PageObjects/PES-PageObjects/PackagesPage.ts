import { ElementFinder, element, by, browser } from "protractor";
import { BasePage } from "../BasePage";

export class PackagesPage extends BasePage {

    CreateNewPackage_Btn: ElementFinder;
    SearchPackage: ElementFinder;
    Save_Package: ElementFinder;
    
    PackageName: ElementFinder;
    PackageNameAsSeenByClient: ElementFinder;
    PackageDescription: ElementFinder;
    Currency: ElementFinder;
    Charge: ElementFinder;
    DefaultTaxRate: ElementFinder;
    CustomerTATNumberOfDays: ElementFinder;
    OperationTATNumberOfDays: ElementFinder;
    VendorTATNumberOfDays: ElementFinder;
    CutOffTime: ElementFinder;
    OrderingInstructions: ElementFinder;
    AddExistingServices_Btn: ElementFinder;
    Add_Btn: ElementFinder;

    constructor() {
        super();
        this.CreateNewPackage_Btn = element(by.xpath("//button[normalize-space()='CREATE NEW PACKAGE']"));
        this.SearchPackage = element(by.css("app-package-configuration-list input.global-filter"));
        this.Save_Package = element(by.xpath("//app-package-details//button[contains(text(),'SAVE')]"));

        this.PackageName = element(by.css("[formcontrolname='packagesName'] input"));
        this.PackageNameAsSeenByClient = element(by.css("[formcontrolname='packageNameSeenByClient'] input"));
        this.PackageDescription = element(by.css("[formcontrolname='packagesDescription']"));

        this.Currency = element(by.css("[formcontrolname='currencyId'] p-dropdown"));
        this.Charge = element(by.css("[formcontrolname='charges'] input"));
        this.DefaultTaxRate = element(by.css("[formcontrolname='defaultTaxRate'] input"));
        this.CustomerTATNumberOfDays = element(by.css("[formcontrolname='customerTatNumberOfDays'] input"));
        this.OperationTATNumberOfDays = element(by.css("[formcontrolname='operationTatNumberOfDays'] input"));
        this.VendorTATNumberOfDays = element(by.css("[formcontrolname='vendorTatNumberOfDays'] input"));
        this.CutOffTime = element(by.css("[formcontrolname='cutOfTimeId'] p-dropdown"));
        this.OrderingInstructions = element(by.css("[formcontrolname='orderingInstructions']"));

        this.AddExistingServices_Btn = element(by.xpath("//button[normalize-space()='ADD EXISTING SERVICES']"));
        this.Add_Btn = element(by.xpath("//p-dialog//button[contains(text(),'ADD')]"));
    }

    clickCreatePackage = () => {
        this.clickElement(this.CreateNewPackage_Btn);
    }

    savePackage = () => {
        this.clickElement(this.Save_Package);
    }

    fillPackageDetails = (testdata) => {
        this.sendKeys(this.PackageName, testdata.PackageName);
        this.sendKeys(this.PackageNameAsSeenByClient, testdata.PackageNameAsSeenByClient);
        this.sendKeys(this.PackageDescription, testdata.PackageDescription);

        this.autoCompleteDropdown(this.Currency, testdata.Currency);
        this.sendKeys(this.Charge, testdata.Charge);
        this.sendKeys(this.DefaultTaxRate, testdata.DefaultTaxRate);
        this.selectAllTheCheckboxes();
        this.sendKeys(this.CustomerTATNumberOfDays, testdata.CustomerTATNumberOfDays);
        this.sendKeys(this.OperationTATNumberOfDays, testdata.OperationTATNumberOfDays);
        this.sendKeys(this.VendorTATNumberOfDays, testdata.VendorTATNumberOfDays);
        this.autoCompleteDropdown(this.CutOffTime, '6 PM');
        this.sendKeys(this.OrderingInstructions, testdata.OrderingInstructions);
        this.savePackage();
    }
    
    addExistingServices = (testdata) => {
        this.clickElement(this.AddExistingServices_Btn);
        browser.driver.sleep(5000);
        //this.selectAllCheckboxes();
        this.searchAndSelectCheckbox_Table(testdata.ServiceName1);
        this.searchAndSelectCheckbox_Table(testdata.ServiceName2);
        this.searchAndSelectCheckbox_Table(testdata.ServiceName3);
        this.clickElement(this.Add_Btn);
        browser.driver.sleep(5000);
        this.savePackage();
    }
}