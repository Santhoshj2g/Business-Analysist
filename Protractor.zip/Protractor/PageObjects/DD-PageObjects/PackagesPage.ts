import { ElementFinder, element, by, browser } from "protractor";
import { BasePage } from "../BasePage";

export class PackagesPage extends BasePage {

    CreateNewPackage_Btn: ElementFinder;
    SearchPackage: ElementFinder;
    Save_Package: ElementFinder;
    PackageName: ElementFinder;
    PackageNameAsSeenByClient: ElementFinder;
    ServiceCategory: ElementFinder;
    PackageDescription: ElementFinder;
    Currency: ElementFinder;
    Charge: ElementFinder;
    DefaultTaxRate: ElementFinder;
    CutOffTime: ElementFinder;
    ThirdPartyFee: ElementFinder;
    OrderingInstructions: ElementFinder;
    AddExistingServices_Btn: ElementFinder;
    Add_Btn: ElementFinder;

    constructor() {
        super();
        this.CreateNewPackage_Btn = element(by.xpath("//button[normalize-space()='Create New Package']"));
        this.SearchPackage = element(by.css("app-package-list input.global-filter"));
        this.Save_Package = element(by.xpath("//app-package-details//button[contains(text(),'SAVE')]"));

        this.PackageName = element(by.css("[formcontrolname='packagesName'] input"));
        this.PackageNameAsSeenByClient = element(by.css("[formcontrolname='packageNameSeenByClient'] input"));
        this.ServiceCategory = element(by.css("[formcontrolname='serviceCategoryId'] p-dropdown"));
        this.PackageDescription = element(by.css("[formcontrolname='packagesDescription']"));

        this.Currency = element(by.css("[formcontrolname='currencyId'] p-dropdown"));
        this.Charge = element(by.css("[formcontrolname='charges'] input"));
        this.DefaultTaxRate = element(by.css("[formcontrolname='defaultTaxRate'] input"));
        this.CutOffTime = element(by.css("[formcontrolname='cutOfTimeId'] p-dropdown"));
        this.ThirdPartyFee = element(by.css("[formcontrolname='thirdPartyFee'] input"));
        this.OrderingInstructions = element(by.css("[formcontrolname='orderingInstructions'] "));

        this.AddExistingServices_Btn = element(by.xpath("//button[contains(text(),'ADD EXISTING SERVICES')]"));
        this.Add_Btn = element(by.xpath("//p-dialog//button[contains(text(),'ADD')]"));
    }

    savePackage = () => {
        this.clickElement(this.Save_Package);
    }

    clickCreateNewPackage = () => {
        this.clickElement(this.CreateNewPackage_Btn);
    }

    fillPackageDetails = (testdata) => {
        this.sendKeys(this.PackageName, testdata.PackageName);
        this.sendKeys(this.PackageNameAsSeenByClient, testdata.PackageNameAsSeenByClient);
        this.autoCompleteDropdown(this.ServiceCategory, testdata.ServiceCategory);
        this.sendKeys(this.PackageDescription, testdata.PackageDescription);

        this.autoCompleteDropdown(this.Currency, testdata.Currency);
        this.sendKeys(this.Charge, testdata.Charge);
        this.sendKeys(this.DefaultTaxRate, testdata.DefaultTaxRate);
        this.autoCompleteDropdown(this.CutOffTime, '6 PM');
        this.sendKeys(this.ThirdPartyFee, testdata.ThirdPartyFee);
        this.sendKeys(this.OrderingInstructions, testdata.OrderingInstructions);
        this.selectAllTheCheckboxes();
        this.savePackage();
        this.getAlertInfo();

        this.clickElement(this.AddExistingServices_Btn);
        browser.driver.sleep(2000);
        this.searchAndSelectCheckbox_Table(testdata.ServiceName1);
        this.searchAndSelectCheckbox_Table(testdata.ServiceName2);
        this.clickElement(this.Add_Btn);
        this.getAlertInfo();
    }
}