import { ElementFinder, element, by } from "protractor";
import { BasePage } from "../BasePage";

export class ServicesPage extends BasePage {

    CreateNewService_Btn: ElementFinder;
    SearchService: ElementFinder;
    Save_Service: ElementFinder;
    ServiceDetailsTab: ElementFinder;
    ServiceName: ElementFinder;
    ServiceNameAsSeenByClient: ElementFinder;
    ServiceCategory: ElementFinder;
    ServiceType: ElementFinder;
    Country: ElementFinder;
    ServiceDescription: ElementFinder;
    OrderReview: ElementFinder;
    MaximumNoOfOrders: ElementFinder;
    CutOffTime: ElementFinder;
    CustomerTATNumberofDays: ElementFinder;
    OperationTATNumberofDays: ElementFinder;
    VendorTATNumberofDays: ElementFinder;
    Currency: ElementFinder;
    Charge: ElementFinder;
    DefaultTaxRate: ElementFinder;
    NumberofYears: ElementFinder;
    PreferredSupplier: ElementFinder;
    OrderingInstructions: ElementFinder;

    constructor() {
        super();
        this.CreateNewService_Btn = element(by.xpath("//button[contains(text(),'Create NEW Service')]"));
        this.SearchService = element(by.css("app-service-list input.global-filter"));
        this.Save_Service = element(by.xpath("//app-service-details//button[contains(text(),'Save')]"));

        this.ServiceDetailsTab = element(by.xpath("//li[@role='tab']//span[text()='Service Details']"));
        this.ServiceName = element(by.css("[formcontrolname='serviceName'] input"));
        this.ServiceNameAsSeenByClient = element(by.css("[formcontrolname='serviceNameAsSeenByClient'] input"));
        this.ServiceCategory = element(by.css("[formcontrolname='serviceCategoryId'] p-dropdown"));
        this.ServiceType = element(by.css("[formcontrolname='serviceTypeId'] p-dropdown"));
        this.Country = element(by.css("[formcontrolname='countryId'] p-dropdown"));
        this.ServiceDescription = element(by.css("[formcontrolname='serviceDescription']"));

        this.OrderReview = element(by.xpath("//label[contains(text(),'Order Review')]/..//p-dropdown"));
        this.MaximumNoOfOrders = element(by.xpath("//label[contains(text(),'MaximumNoOfOrders')]/..//input"));
        this.CutOffTime = element(by.xpath("//label[contains(text(),'Cut Off Time')]/..//p-dropdown"));
        this.CustomerTATNumberofDays = element(by.xpath("//label[contains(text(),'Customer TAT Number of Days')]/..//input"));
        this.OperationTATNumberofDays = element(by.xpath("//label[contains(text(),'Operation TAT Number of Days')]/..//input"));
        this.VendorTATNumberofDays = element(by.xpath("//label[contains(text(),'Vendor TAT Number of Days')]/..//input"));
        this.Currency = element(by.xpath("//label[contains(text(),'Currency')]/..//p-dropdown"));
        this.Charge = element(by.xpath("//label[normalize-space()='Charge']/..//input"));
        this.DefaultTaxRate = element(by.xpath("//label[contains(text(),'Default Tax Rate')]/..//input"));
        this.NumberofYears = element(by.xpath("//label[contains(text(),'Number of Years')]/..//input"));
        this.PreferredSupplier = element(by.xpath("//label[contains(text(),'Preferred Supplier')]/..//p-dropdown"));
        this.OrderingInstructions = element(by.xpath("//label[contains(text(),'Ordering Instructions')]/..//textarea"));
    }

    clickCreateService = () => {
        this.clickElement(this.CreateNewService_Btn);
    }

    saveService = () => {
        this.clickElement(this.Save_Service);
    }

    fillServiceDetailsTab = (testdata) => {
        this.clickElement(this.ServiceDetailsTab);
        this.sendKeys(this.ServiceName, testdata.ServiceName);
        this.sendKeys(this.ServiceNameAsSeenByClient, testdata.ServiceNameAsSeenByClient);
        this.selectDropdownValue(this.ServiceCategory, testdata.ServiceCategory);
        this.selectDropdownValue(this.ServiceType, testdata.ServiceType);
        this.selectDropdownValue(this.Country, testdata.Country);
        this.sendKeys(this.ServiceDescription, testdata.ServiceDescription);

        this.selectDropdownValue(this.OrderReview, testdata.OrderReview);
        this.sendKeys(this.MaximumNoOfOrders, testdata.MaximumNoOfOrders);
        this.autoCompleteDropdown(this.CutOffTime, '6 PM');
        this.autoCompleteDropdown(this.Currency, testdata.Currency);
        this.sendKeys(this.Charge, testdata.Charge);
        this.sendKeys(this.DefaultTaxRate, testdata.DefaultTaxRate);
        this.sendKeys(this.NumberofYears, testdata.NumberofYears);
        this.autoCompleteDropdown(this.PreferredSupplier, testdata.PreferredSupplier);
        this.sendKeys(this.OrderingInstructions, testdata.OrderingInstructions);
        this.selectAllTheCheckboxes();
        this.saveService();
        this.getAlertInfo();
    }
}