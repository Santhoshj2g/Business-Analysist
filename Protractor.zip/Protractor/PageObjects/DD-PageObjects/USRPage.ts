import { ElementFinder, element, by, browser } from "protractor";
import { BasePage } from "../BasePage";

export class USRPage extends BasePage {

    CreateUSR_Btn: ElementFinder;
    Add_Btn: ElementFinder;
    Save_Btn: ElementFinder;
    SaveUSR_Btn: ElementFinder;

    RequestDetailsTab: ElementFinder;
    RequestingRegions: ElementFinder;
    RequestingOffice: ElementFinder;
    Client: ElementFinder;
    RequestingDirector: ElementFinder;
    RequestingDirectorDepartment: ElementFinder;
    OMPOCName: ElementFinder;
    OMPOCEmail: ElementFinder;
    OMPOCNotes: ElementFinder;
    ServiceType: ElementFinder;
    Category: ElementFinder;
    AvailablePackages: ElementFinder;
    AvailableServices: ElementFinder;
    Description: ElementFinder;
    ServiceStartDate: ElementFinder;
    ServiceEndDate: ElementFinder;
    TimeZone: ElementFinder;
    OnGoingRequest_Yes: ElementFinder;
    AddLocationPerson_Btn: ElementFinder;
    AddingPOI_Yes: ElementFinder;
    SubjectName_POI: ElementFinder;
    DOB_POI: ElementFinder;
    Gender_POI: ElementFinder;
    Nationality_POI: ElementFinder;
    StreetAddress_Location: ElementFinder;
    Radius_Location: ElementFinder;
    Unit_Location: ElementFinder;
    Description_Location: ElementFinder;
    OperationalManager: ElementFinder;
    RecipientType: ElementFinder;
    Recipient: ElementFinder;

    EngagementDetailsTab: ElementFinder;
    BulkUpload_Btn: ElementFinder;
    ChooseFile_Btn: ElementFinder;
    Upload_Btn: ElementFinder;
    AddSubject_Btn: ElementFinder;
    Packages: ElementFinder;
    Services: ElementFinder;
    SubjectName: ElementFinder;
    SubjectType: ElementFinder;
    Address1: ElementFinder;
    Address2: ElementFinder;
    Country: ElementFinder;
    State: ElementFinder;
    City: ElementFinder;
    ZipPostalCode: ElementFinder;
    EmailId: ElementFinder;
    Note: ElementFinder;

    DeliveryDetailsTab: ElementFinder;
    SelectSubjectName: ElementFinder;
    CreateRequest_Btn: ElementFinder;

    constructor() {
        super();
        this.CreateUSR_Btn = element(by.xpath("//button[text()='Create USR']"));
        this.Add_Btn = element(by.xpath("//p-dialog//button[contains(text(),'Add')]"));
        this.Save_Btn = element(by.xpath("//p-dialog//button[contains(text(),'Save')]"));
        this.SaveUSR_Btn = element(by.xpath("//app-service-request-wrapper//button[contains(text(),'Save')]"));

        // Request Details Tab        
        this.RequestDetailsTab = element(by.css("#request-details"));
        this.RequestingRegions = element(by.css("[formcontrolname='requestingRegionId'] p-dropdown"));
        this.RequestingOffice = element(by.css("[formcontrolname='requestingOfficeId'] p-dropdown"));
        this.Client = element(by.css("[formcontrolname='clientId'] p-dropdown"));
        this.RequestingDirector = element(by.css("[formcontrolname='requestingDirectorId'] p-dropdown"));
        this.RequestingDirectorDepartment = element(by.css("[formcontrolname='requestingDirectorDepartmentId'] p-dropdown"));
        this.OMPOCName = element(by.css("[formcontrolname='omPocName'] input"));
        this.OMPOCEmail = element(by.css("[formcontrolname='omPocEmailId'] input"));
        this.OMPOCNotes = element(by.css("[formcontrolname='omPocNotes'] textarea"));

        this.ServiceType = element(by.css("[formcontrolname='serviceTypeId'] p-dropdown"));
        this.Category = element(by.css("[formcontrolname='serviceTypeCategoryId'] p-dropdown"));

        this.AvailablePackages = element(by.xpath("//a[contains(text(),'Avaliable Packages')]"));
        this.AvailableServices = element(by.xpath("//a[contains(text(),'Avaliable Services')]"));

        this.Description = element(by.css("[formcontrolname='serviceDescription'] textarea"));
        this.ServiceStartDate = element(by.css("[formcontrolname='usrStartDate'] input"));
        this.ServiceEndDate = element(by.css("[formcontrolname='usrEndDate'] input"));
        this.TimeZone = element(by.css("[formcontrolname='timeZoneId'] p-dropdown"));
        this.OnGoingRequest_Yes = element(by.css("[formcontrolname='isOngoing'][inlinelabel='Yes'] div[role='radio']"));

        this.AddLocationPerson_Btn = element(by.xpath("//button[normalize-space()='Add Location']"));
        this.AddingPOI_Yes = element(by.xpath("//p-dialog//label[text()='Yes']"));
        this.SubjectName_POI = element(by.css("[formcontrolname='subjectName'] input"));
        this.DOB_POI = element(by.css("[formcontrolname='dateOfBirth'] input"));
        this.Gender_POI = element(by.css("[formcontrolname='gender'] p-dropdown"));
        this.Nationality_POI = element(by.css("[formcontrolname='nationality'] input"));
        this.StreetAddress_Location = element(by.css("[formcontrolname='streetAddress']"));
        this.Radius_Location = element(by.css("[formcontrolname='radius'] input"));
        this.Unit_Location = element(by.css("[formcontrolname='unit'] p-dropdown"));
        this.Description_Location = element(by.css("[formcontrolname='locationDescription'] textarea"));

        this.OperationalManager = element(by.css("[formcontrolname='omLoginId'] p-dropdown"));
        this.RecipientType = element(by.css("[formcontrolname='recipregion'] p-dropdown"));
        this.Recipient = element(by.css("p-autocomplete[formcontrolname='usrRecipients']>span>ul>li>input"));

        //Engagement Details Tab
        this.EngagementDetailsTab = element(by.xpath("//span[contains(text(),'Engagement Details')]"));
        this.BulkUpload_Btn = element(by.xpath("//button[contains(text(),'BULK UPLOAD')]"));
        this.ChooseFile_Btn = element(by.xpath("//label[contains(text(),'Choose File')]"));
        this.Upload_Btn = element(by.xpath("//button[contains(text(),'Upload')]"));

        this.AddSubject_Btn = element(by.xpath("//button[contains(text(),'ADD Subjects')]"));
        this.Packages = element(by.xpath("//p-dialog//label[contains(text(),'Packages')]/..//p-dropdown"));
        this.Services = element(by.xpath("//p-dialog//label[contains(text(),'Services')]/..//p-multiselect"));
        this.SubjectName = element(by.xpath("//p-dialog//label[contains(text(),'Subject Name')]/..//input"));
        this.SubjectType = element(by.xpath("//p-dialog//label[contains(text(),'Business')]"));
        this.Address1 = element(by.xpath("//p-dialog//label[contains(text(),'Address 1')]/..//input"));
        this.Address2 = element(by.xpath("//p-dialog//label[contains(text(),'Address 2')]/..//input"));
        this.Country = element(by.xpath("//p-dialog//label[contains(text(),'Country')]/..//p-dropdown"));
        this.State = element(by.xpath("//p-dialog//label[contains(text(),'State/Province/Region')]/..//p-dropdown"));
        this.City = element(by.xpath("//p-dialog//label[contains(text(),'City/District')]/..//input"));
        this.ZipPostalCode = element(by.xpath("//p-dialog//label[contains(text(),'Zip Postal Code')]/..//input"));
        this.EmailId = element(by.xpath("//p-dialog//label[contains(text(),'Email ID')]/..//input"));
        this.Note = element(by.xpath("//p-dialog//label[contains(text(),'Note')]/..//textarea"));

        //Delivery Details Tab
        this.DeliveryDetailsTab = element(by.xpath("//span[contains(text(),'Delivery Details')]"));
        this.SelectSubjectName = element(by.css("[formcontrolname='subjectName'] p-dropdown"));
        this.CreateRequest_Btn = element(by.xpath("//button[contains(text(),'Create Request')]"));
    }

    clickCreateUSR = () => {
        this.clickElement(this.CreateUSR_Btn);
    }

    saveUSR = () => {
        this.clickElement(this.SaveUSR_Btn);
    }

    selectUSR = (USRNumber) => {
        browser.driver.sleep(2000);
        this.sendKeys(this.Search, USRNumber);
        this.clickSpanElement(USRNumber);
    }

    selectRecipient = (testdata) => {
        var elem = element(by.xpath("//p-autocomplete//div[contains(text(),'" + testdata + "')]"));
        this.clickElement(elem);
    };

    selectSubject = (subjectName) => {
        var elem = element(by.xpath("//span[contains(text(),'" + subjectName + "')]/ancestor::tr//span[contains(text(),'DD')]"));
        this.clickElement(elem);
    }

    clickDeliveryDetailsTab = () => {
        this.clickElement(this.DeliveryDetailsTab);
    }

    fillRequestDetailsTab = (testdata) => {
        this.clickElement(this.RequestDetailsTab);
        this.selectDropdownValue(this.RequestingRegions, testdata.RequestingRegions);
        this.selectDropdownValue(this.RequestingOffice, testdata.RequestingOffice);
        browser.driver.sleep(1500);
        this.selectDropdownValue(this.Client, testdata.Client);
        this.autoCompleteDropdown(this.RequestingDirector, testdata.RequestingDirector);
        this.selectDropdownValue(this.RequestingDirectorDepartment, testdata.RequestingDirectorDepartment);

        this.sendKeys(this.OMPOCName, testdata.OMPOCName);
        this.enterContactNumber("Phone Number", testdata.Country, testdata.OMPOCNumber);
        this.sendKeys(this.OMPOCEmail, testdata.OMPOCEmail);
        this.sendKeys(this.OMPOCNotes, testdata.OMPOCNotes);

        this.selectDropdownValue(this.ServiceType, testdata.ServiceType);
        this.selectDropdownValue(this.Category, testdata.Category);

        this.scrollIntoView(this.AvailablePackages);
        this.clickElement(this.AvailablePackages);
        browser.driver.sleep(2000);
        this.searchAndSelectCheckbox_Table(testdata.Packages);
        this.clickElement(this.Add_Btn);
        this.clickElement(this.AvailableServices);
        browser.driver.sleep(2000);
        this.searchAndSelectCheckbox_Table(testdata.Services);
        this.clickElement(this.Add_Btn);

        this.sendKeys(this.Description, testdata.Description);
        this.datePicker(this.ServiceStartDate, testdata.StartDate);
        this.datePicker(this.ServiceEndDate, testdata.EndDate);
        this.selectDropdownValue(this.TimeZone, testdata.TimeZone);
        this.clickElement(this.OnGoingRequest_Yes);

        this.clickElement(this.AddLocationPerson_Btn);
        this.clickElement(this.AddingPOI_Yes);
        this.sendKeys(this.SubjectName_POI, testdata.SubjectName_POI);
        this.datePicker(this.DOB_POI, testdata.DOB_Subject);
        this.selectDropdownValue(this.Gender_POI, testdata.Gender_POI);
        this.sendKeys(this.Nationality_POI, testdata.Nationality_POI);
        this.sendKeys(this.StreetAddress_Location, testdata.StreetAddress_Location);
        this.sendKeys(this.Radius_Location, testdata.Radius_Location);
        this.selectDropdownValue(this.Unit_Location, testdata.Unit_Location);
        this.sendKeys(this.Description_Location, testdata.Description_Location);
        browser.driver.sleep(2000);
        this.clickElement(this.Save_Btn);

        this.selectDropdownValue(this.OperationalManager, testdata.OperationalManager);
        this.selectDropdownValue(this.RecipientType, testdata.RecipientType);
        this.sendKeys(this.Recipient, testdata.Recipient.substring(0, 5));
        this.selectRecipient(testdata.Recipient);
        this.saveUSR();
        this.getAlertInfo();
    }

    fillEngagementDetailsTab = (testdata) => {
        this.clickElement(this.EngagementDetailsTab);
        // this.clickElement(this.BulkUpload_Btn);
        // this.clickElement(this.ChooseFile_Btn);
        // browser.driver.sleep(10000);
        // this.clickElement(this.Upload_Btn);

        this.clickElement(this.AddSubject_Btn);
        this.autoCompleteDropdown(this.Packages, testdata.Packages);
        this.multiselectDropdown(this.Services);
        // this.autoCompleteDropdown(this.Services, testdata.Services);
        this.clickElement(this.SubjectType);
        this.sendKeys(this.SubjectName, testdata.SubjectName);
        this.sendKeys(this.Address1, testdata.Address1);
        this.sendKeys(this.Address2, testdata.Address2);
        this.autoCompleteDropdown(this.Country, testdata.Country);
        this.selectDropdownValue(this.State, testdata.State);
        this.sendKeys(this.City, testdata.City);
        this.sendKeys(this.ZipPostalCode, testdata.ZipPostalCode);
        this.enterContactNumber('Phone Number', testdata.Country, testdata.PhoneNumber);
        this.sendKeys(this.EmailId, testdata.EmailId);
        this.sendKeys(this.Note, testdata.Note);
        this.clickElement(this.Save_Btn);
        this.getAlertInfo();
    }

    fillDeliveryDetailsTab = (testdata) => {
        this.clickElement(this.DeliveryDetailsTab);
        this.selectDropdownValue(this.SelectSubjectName, testdata.SubjectName);
        this.clickElement(this.CreateRequest_Btn);
        this.getAlertInfo();
        this.selectSubject(testdata.SubjectName);
    }
}
