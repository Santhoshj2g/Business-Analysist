import { ElementFinder, element, by, browser } from "protractor";
import { BasePage } from "../BasePage";

export class DashboardPage_DD extends BasePage {

    Services: ElementFinder;
    Packages: ElementFinder;
    DDRequest: ElementFinder;
    ReportTemplate: ElementFinder;
    USR: ElementFinder;

    constructor() {
        super();
        this.Services = element(by.css("[title='Services'] a"));
        this.Packages = element(by.css("[title='Packages'] a"));
        this.DDRequest = element(by.xpath("//span[contains(text(),'DD Request')]/..//a"));
        this.ReportTemplate = element(by.xpath("//span[contains(text(),'Report Template')]/..//a"));
        this.USR = element(by.xpath("//span[contains(text(),'Service Request')]/..//a"));
    }

    clickServices = () => {
        this.clickElement(this.Services);
    }

    clickPackages = () => {
        this.clickElement(this.Packages);
    }

    clickDDRequest = () => {
        this.clickElement(this.DDRequest);
    }

    clickReportTemplate = () => {
        this.clickElement(this.ReportTemplate);
    }

    clickUSR = () => {
        this.clickElement(this.USR);
    }

    navigateToDashboard = (Url) => {
        browser.get(Url);
    }
}