import { ElementFinder, element, by, browser } from "protractor";
import { BasePage } from "../BasePage";

export class SubjectInfoPage extends BasePage {

    Action: ElementFinder;
    Notes_Subject: ElementFinder;
    AddNote_Btn: ElementFinder;
    ExecutiveSummary: ElementFinder;
    SaveSummary: ElementFinder;
    ReportType: ElementFinder;
    ReportName: ElementFinder;
    GenerateReport_Btn: ElementFinder;
    Description: ElementFinder;
    Currency: ElementFinder;
    Charges: ElementFinder;
    TaxRate: ElementFinder;
    AddCharges_Btn: ElementFinder;
    Notes_Workorder: ElementFinder;

    constructor() {
        super();

        //Subject Information
        this.Action = element(by.css("[formcontrolname='actionRefcode'] p-dropdown"));
        this.Notes_Subject = element(by.css("[formcontrolname='noteText']"));
        this.AddNote_Btn = element(by.xpath("//button[contains(text(),'ADD NOTE')]"));

        this.ExecutiveSummary = element(by.xpath("//div[@class='note-placeholder'][text()='Message...']"));
        this.SaveSummary = element(by.xpath("//button[contains(text(),'SAVE')]"));

        this.ReportType = element(by.css("[formcontrolname='reportTypeId'] p-dropdown"));
        this.ReportName = element(by.css("[formcontrolname='reportName'] input"));
        this.GenerateReport_Btn = element(by.xpath("//button[contains(text(),'GENERATE REPORT')]"));

        //Work Order
        this.Description = element(by.css("[formcontrolname='description']"));
        this.Currency = element(by.css("[formcontrolname='currencyId'] p-dropdown"));
        this.Charges = element(by.css("[formcontrolname='charges'] input"));
        this.TaxRate = element(by.css("[formcontrolname='taxRate'] input"));
        this.AddCharges_Btn = element(by.xpath("//button[contains(text(),'ADD CHARGES')]"));
        this.Notes_Workorder = element(by.css("[formcontrolname='notes'] textarea"));
    }

    expandPackage = (packageName) => {
        var elem = element(by.xpath("//span[contains(text(),'" + packageName + "')]/..//span[contains(@class,'detail-row-toggler')]"));
        this.clickElement(elem);
    }

    fillSubjectInfoPage = (testdata) => {
        this.clickSpanElement('Internal Notes');
        this.autoCompleteDropdown(this.Action, testdata.InternalNote_Action);
        this.sendKeys(this.Notes_Subject, testdata.InternalNote);
        this.clickElement(this.AddNote_Btn);
        this.getAlertInfo();

        this.clickSpanElement('External Notes');
        this.autoCompleteDropdown(this.Action, testdata.ExternalNote_Action);
        this.sendKeys(this.Notes_Subject, testdata.ExternalNote);
        this.clickElement(this.AddNote_Btn);
        this.getAlertInfo();

        // this.clickSpanElement('Executive Summary');
        // this.clickElement(this.ExecutiveSummary);
        // browser.driver.sleep(2000);
        // this.sendKeys(this.ExecutiveSummary, testdata.ExecutiveSummary);
        // this.clickElement(this.SaveSummary);
        // this.getAlertInfo();

        this.clickSpanElement('Final Case Reports');
        this.selectDropdownValue(this.ReportType, testdata.ReportType);
        this.sendKeys(this.ReportName, testdata.ReportName_Subject);
        this.clickElement(this.GenerateReport_Btn);
        this.getAlertInfo();
    }

    fillWorkOrderPage = async(testdata) => {
        var url = await browser.getCurrentUrl();
        console.log(url);
        this.clickSpanElement('Services Ordered');
        browser.driver.sleep(1500);
        this.expandPackage(testdata.PackageName)
        browser.driver.sleep(1500);
        this.clickSpanElement(testdata.ServiceName);
        this.clickSpanElement('Additional Charges');
        this.sendKeys(this.Description, testdata.Description);
        this.selectDropdownValue(this.Currency, testdata.Currency);
        this.sendKeys(this.Charges, testdata.Charges);
        this.sendKeys(this.TaxRate, testdata.TaxRate);
        this.selectAllTheCheckboxes();
        this.clickElement(this.AddCharges_Btn);
        this.getAlertInfo();

        this.clickSpanElement('Supplier Notes');
        this.autoCompleteDropdown(this.Action, testdata.SupplierNote_Action);
        this.sendKeys(this.Notes_Workorder, testdata.SupplierNote);
        this.clickElement(this.AddNote_Btn);
        this.getAlertInfo();

        this.clickSpanElement('Customer Notes');
        this.autoCompleteDropdown(this.Action, testdata.CustomerNote_Action);
        this.sendKeys(this.Notes_Workorder, testdata.CustomerNote);
        this.clickElement(this.AddNote_Btn);
        this.getAlertInfo();

        this.clickSpanElement('Work Order Reports');
        this.selectDropdownValue(this.ReportType, testdata.ReportType);
        this.sendKeys(this.ReportName, testdata.ReportName_WorkOrder);
        this.clickElement(this.GenerateReport_Btn);
        this.getAlertInfo();
        await browser.get(url);
    }
}