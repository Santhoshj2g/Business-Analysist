import { ElementFinder, element, by, browser, ExpectedConditions as EC } from "protractor";
import { BasePage } from "../BasePage";

export class TwitterWidgetPage extends BasePage {

    TwitterWidget: ElementFinder;
    ConfigureTwitter: ElementFinder;
    Keywords: ElementFinder;
    FollowUser: ElementFinder;
    Submit: ElementFinder;
    KeywordsResults: ElementFinder;
    FollowResults: ElementFinder;

    constructor() {
        super();
        this.TwitterWidget = element(by.xpath("//div[@draggable='true']/child::span[normalize-space()='twitter']/.."));
        this.ConfigureTwitter = element(by.xpath("//div[contains(text(),'Configure')]"));
        this.Keywords = element(by.xpath("//textarea[@id='keywords']"));
        this.FollowUser = element(by.xpath("//textarea[@id='followUser']"));
        this.Submit = element(by.xpath("//button[normalize-space()='Submit']"));
        // this.KeywordsResults = element(by.partialLinkTexts("https://twitter.com/"));
    }

    searchByKeyword = (testdata) => {
        this.clickElement(this.ConfigureTwitter);
        this.sendKeys(this.Keywords, testdata.Keywords);
        this.clickElement(this.Submit);
        browser.driver.sleep(2000);
        // this.KeywordsResults.getText();
        // var result=this.KeywordsResults.getText();
        // console.log("Keyword Results"+result);
    }

    searchByFollowUser = (testdata) => {
        this.clickElement(this.ConfigureTwitter);
        this.sendKeys(this.FollowUser, testdata.FollowId);
        this.clickElement(this.Submit);
        browser.driver.sleep(2000);
        // this.KeywordsResults.getText();
    }
}