import { browser, by, element, ElementFinder } from "protractor";
import { BasePage } from "../BasePage";

export class LinksWidgetPage extends BasePage {

    LinksWidget: ElementFinder;
    ConfigureURLLinks: ElementFinder;
    EnterTitle: ElementFinder;
    EnterLink: ElementFinder;
    AddNewLink_btn: ElementFinder;
    SearchLink: ElementFinder;
    AddLink: ElementFinder;

    constructor() {
        super();
        this.LinksWidget = element(by.xpath("//div[@draggable='true']/child::span[normalize-space()='links']/.."));
        this.ConfigureURLLinks = element(by.css("app-links .linksBtn"));
        this.EnterTitle = element(by.css("input[placeholder='Enter Title']"));
        this.EnterLink = element(by.css("input[placeholder='Enter Your Link']"));
        this.AddNewLink_btn = element(by.css("app-links-config .add-link-bgPostion"));
        this.SearchLink = element(by.css("input[placeholder='Search...']"));
        this.AddLink = element(by.xpath("//button[text()='ADD']"));
    }

    selectLink(testdata) {
        var elem = element(by.xpath("//span[normalize-space()='" + testdata + "']/ancestor::tr//div[@role='checkbox']"));
        this.clickElement(elem);
    }

    deleteLink(testdata) {
        var elem = element(by.xpath("//span[normalize-space()='" + testdata + "']/ancestor::tr//button[@title='Delete']"));
        this.clickElement(elem);
    }

    addNewLink = (testdata) => {
        this.clickElement(this.ConfigureURLLinks);
        this.sendKeys(this.EnterTitle, testdata.LinkTitle);
        this.sendKeys(this.EnterLink, testdata.LinkURL);
        this.clickElement(this.AddNewLink_btn);
        this.sendKeys(this.SearchLink, testdata.LinkURL);
        browser.driver.sleep(2000);
        this.selectLink(testdata.LinkTitle);
        this.clickElement(this.AddLink);
    }
}