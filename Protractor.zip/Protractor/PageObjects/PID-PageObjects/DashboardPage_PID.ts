import { ElementFinder, element, by } from "protractor";
import { BasePage } from "../BasePage";

export class DashboardPage_PID extends BasePage {

    CreateUSRButton: ElementFinder;
    ViewUSRButton: ElementFinder;
    Mac: ElementFinder;
    ServiceRequest: ElementFinder;
    ActiveThreatMonitor: ElementFinder;
    ToDoList: ElementFinder;
    PVNProvisioning: ElementFinder;

    constructor() {
        super();
        this.CreateUSRButton = element(by.xpath("//button[text()='CREATE USR']"));
        this.ViewUSRButton = element(by.xpath("//button[text()='VIEW USR']"));
        this.Mac = element(by.xpath("//h5[text()='Management Action Center ']"));
        this.ServiceRequest = element(by.xpath("//span[contains(text(),'Service Request')]"));
        this.ActiveThreatMonitor = element(by.xpath("//span[contains(text(),'Active Threat Monitor')]"));
        this.ToDoList = element(by.xpath("//span[contains(text(),'To Do List')]"));
        this.PVNProvisioning = element(by.xpath("//span[contains(text(),'PVN Provisioning')]"));
    }

    clickCreateUSR = () => {
        this.clickElement(this.CreateUSRButton);
    }

    clickViewUSR = () => {
        this.clickElement(this.ViewUSRButton);
    }
}
