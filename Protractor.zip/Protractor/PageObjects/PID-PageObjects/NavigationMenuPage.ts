import { ElementFinder, element, by, browser, ExpectedConditions as EC } from "protractor";
import { BasePage } from "../BasePage";

export class NavigationMenuPage extends BasePage {

    InventoryMenu: ElementFinder;
    PIDAdminMenu: ElementFinder;
    URLWhitelistingMenu: ElementFinder;

    constructor() {
        super();
        this.InventoryMenu = element(by.css("span.tm-icon.hamburger-menu"));
        this.PIDAdminMenu = element(by.css("span.inventory.menu-icon"));
        this.URLWhitelistingMenu = element(by.css("[title='URL WhiteListing']"));
    }
}


