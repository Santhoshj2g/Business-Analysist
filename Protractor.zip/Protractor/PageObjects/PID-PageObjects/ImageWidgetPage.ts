import { by, element, ElementFinder } from "protractor";
import { BasePage } from "../BasePage";

export class ImageWidgetPage extends BasePage {

    ImageWidget: ElementFinder;
    ConfigureImage: ElementFinder;
    SelectFileUpload: ElementFinder;
    SelectURL: ElementFinder;
    Title: ElementFinder;
    URL: ElementFinder;
    Choosefiles: ElementFinder;
    AddImage: ElementFinder;
    AddAllImages: ElementFinder;

    constructor() {
        super();
        this.ImageWidget = element(by.xpath("//div[@draggable='true']/child::span[normalize-space()='image']/.."));
        this.ConfigureImage = element(by.xpath("//div[contains(text(),'Configure Image')]"));
        this.SelectURL = element(by.xpath("//label[contains(text(),'URL')]"));
        this.Choosefiles = element(by.xpath("//label[contains(text(),'Choose File')]"));
        this.Title = element(by.css("input[placeholder='Title']"));
        this.URL = element(by.css("input[placeholder='URL']"));
        this.AddImage = element(by.xpath("//button[contains(text(),'Add Image')]"));
        this.AddAllImages = element(by.xpath("//button[contains(text(),'ADD')]"));
    }

    deleteImage = (URL) => {
        var elem = element(by.xpath("//span[normalize-space()='" + URL + "']//preceding::tr[1]//child::span[@class='icon deleteIcon ng-star-inserted']"));
        this.clickElement(elem);
    };

    addImageViaURL = (testdata) => {
        this.clickElement(this.ConfigureImage);
        this.clickElement(this.SelectURL);
        this.sendKeys(this.Title, testdata.Title);
        this.sendKeys(this.URL, testdata.ImageURL);
        this.clickElement(this.AddImage);
        this.clickElement(this.AddAllImages);
    }

    addImageViaFileUpload = () => {
    }
}