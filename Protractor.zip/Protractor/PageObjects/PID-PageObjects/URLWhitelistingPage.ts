import { by, element, ElementFinder } from "protractor";
import { BasePage } from "../BasePage";
import { DashboardPage_PID } from "./DashboardPage_PID";
import { NavigationMenuPage } from "./NavigationMenuPage";

let dashboardPage = new DashboardPage_PID();
let navigationMenuPage = new NavigationMenuPage();

export class URLWhitelistingPage extends BasePage {

    AddNewDomain: ElementFinder;
    DomainName: ElementFinder;
    SaveDomain: ElementFinder;
    DomainSearch: ElementFinder;

    constructor() {
        super();
        this.AddNewDomain = element(by.xpath("//button[text()='ADD NEW DOMAIN']"));
        this.DomainName = element(by.css("#domainName"));
        this.SaveDomain = element(by.xpath("//button[text()='SAVE']"));
        this.DomainSearch = element(by.css("input.global-filter"));
    }

    deleteDomain = (DomainName) => {
        var elem = element(by.xpath("//span[contains(text(),'" + DomainName + "')]/../../../td[2]/div/button[2]"));
        this.clickElement(elem);
    }

    navigateToURLWhitelistingPage = () => {
        this.clickElement(dashboardPage.ViewUSRButton);
        this.clickElement(navigationMenuPage.PIDAdminMenu);
        this.clickElement(navigationMenuPage.URLWhitelistingMenu);
    }

    addDomainURL = (testdata) => {
        this.clickElement(this.AddNewDomain);
        console.log(testdata.DomainName);
        this.sendKeys(this.DomainName, testdata.DomainName);
        this.clickElement(this.SaveDomain);
        this.clickElement(this.DomainSearch);
        this.sendKeys(this.DomainSearch, testdata.DomainName);
        var result = this.isSpanElementDispayed(testdata.DomainName);
        console.log(result);
    }

    deleteDomainURL = (testdata) => {
        this.clickElement(this.DomainSearch);
        this.DomainSearch.clear();
        this.sendKeys(this.DomainSearch, testdata.DomainName);
        this.deleteDomain(testdata.DomainName);
    }
}