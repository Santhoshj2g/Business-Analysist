import { BasePage } from "../BasePage";
import { ElementFinder, element, by } from "protractor";

export class AlertsWidgetPage extends BasePage {

    AlertsWidget: ElementFinder;
    ConfigureAlerts: ElementFinder;
    FilterAlert: ElementFinder;
    FilterByLocation: ElementFinder;
    ApplyFilter: ElementFinder;
    RefreshAlert: ElementFinder;
    VigilanceAlert: ElementFinder;
    WarneAlert: ElementFinder;
    AddAlert: ElementFinder;
    SelectAlert: ElementFinder;

    constructor() {
        super();
        this.AlertsWidget = element(by.xpath("//div[@draggable='true']/child::span[normalize-space()='alerts']/.."));
        this.ConfigureAlerts = element(by.css("app-alert span.config-icon"));
        this.FilterAlert = element(by.css("app-alert span.filter-icon"));
        this.FilterByLocation = element(by.css("[formcontrolname='USRLocList']"));
        this.ApplyFilter = element(by.xpath("//app-alert-filter//button[text()='APPLY']"));
        this.RefreshAlert = element(by.css("app-alert span.refresh-icon"));
        this.VigilanceAlert = element(by.xpath("//span[normalize-space()='Vigilance Alert']"));
        this.WarneAlert = element(by.xpath("//span[normalize-space()='Warne Alert']"));
        this.AddAlert = element(by.xpath("//button[normalize-space()='ADD']"));
        this.SelectAlert = element(by.xpath("//span[contains(@class,'alert-icon')][1]"));
    }

    selectLocation = (testdata) => {
        var elem = element(by.xpath("//app-alert-filter//span[contains(text(),'" + testdata + "')]"));
        this.clickElement(elem);
    }

    addVigilanceAlert = () => {
        this.clickElement(this.AddAlert);
    }

    addWarneAlert = () => {
        this.clickElement(this.ConfigureAlerts);
        this.clickElement(this.WarneAlert);
        this.clickElement(this.AddAlert);
    }

    filterByLocation = (testdata) => {
        this.clickElement(this.FilterAlert);
        // this.clickElement(this.FilterByLocation);
        // this.selectLocation(testdata.Filter_Location);
        // this.clickElement(this.FilterByLocation);
        this.multiselectDropdown(this.FilterByLocation)
        this.clickElement(this.ApplyFilter);
    }

    showAlert = () => {
        this.clickElement(this.SelectAlert);
    }
}