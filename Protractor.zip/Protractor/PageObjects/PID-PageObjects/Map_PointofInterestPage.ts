import { ElementFinder, element, by, browser } from "protractor";
import { BasePage } from "../BasePage";

export class Map_PointofInterestPage extends BasePage {

    PointOfInterest: ElementFinder;
    CreatePOI: ElementFinder;
    StreetAddress: ElementFinder;
    Title_POI: ElementFinder;
    Category_POI: ElementFinder;
    AddGroup: ElementFinder;
    GroupName: ElementFinder;
    Submit_Btn_AddGroup: ElementFinder;
    Group_POI: ElementFinder;
    Search_POI: ElementFinder;
    Save_POI: ElementFinder;

    constructor() {
        super();
        this.PointOfInterest = element(by.css("span[title='Point of Interest']"));
        this.CreatePOI = element(by.xpath("//app-map-data-selector//button[contains(text(),'Create')]"));
        this.StreetAddress = element(by.css("#streetAddress"));
        this.Title_POI = element(by.css("#title"));
        this.Category_POI = element(by.css("[formcontrolname='poiCategoryId']"));
        this.AddGroup = element(by.css("app-point-of-interest a.addGroup"));
        this.GroupName = element(by.css("input[placeholder='Enter Group Name']"));
        this.Submit_Btn_AddGroup = element(by.xpath("//p-dialog//button[contains(text(),'SUBMIT')]"));
        this.Group_POI = element(by.css("[formcontrolname='poiGroupId']"));
        this.Search_POI = element(by.css("app-map-data-selector input[placeholder='Search...']"));
        this.Save_POI = element(by.xpath("//app-point-of-interest//button[text()='SAVE']"));
    }

    createPOI = (testdata) => {
        this.clickElement(this.PointOfInterest);
        this.clickElement(this.CreatePOI);
        this.sendKeys(this.StreetAddress, testdata.StreetAddress);
        this.sendKeys(this.Title_POI, testdata.Title_POI);
        this.autoCompleteDropdown(this.Category_POI, testdata.Category_POI);
        //Add New Group
        // this.clickElement(this.AddGroup);
        // this.sendKeys(this.GroupName, testdata.GroupName);
        // this.clickElement(this.Submit_Btn_AddGroup);
        browser.driver.sleep(2000);
        this.autoCompleteDropdown(this.Group_POI, testdata.Group_POI)
        this.clickElement(this.Save_POI);
    }
}
