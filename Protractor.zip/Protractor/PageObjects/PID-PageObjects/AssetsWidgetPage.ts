import { ElementFinder, element, by } from "protractor";
import { BasePage } from "../BasePage";

export class AssetsWidgetPage extends BasePage {

    AssetsWidget: ElementFinder;

    constructor() {
        super();
        this.AssetsWidget = element(by.xpath("//div[@draggable='true']/child::span[normalize-space()='assets']/.."));
    }

    assetsDetail = (testdata) => {
        var AssetsDetail = element(by.xpath("//a[contains(text(),'" + testdata + "')]"));
        this.clickElement(AssetsDetail);
    }

    checkAssetsAction = (testdata) => {
        var AssetsAction = element(by.xpath("//a[contains(text(),'" + testdata + "')]/ancestor::tr//span[contains(@class,'tm-icon group-icon')]"));
        this.clickElement(AssetsAction);
    }
}