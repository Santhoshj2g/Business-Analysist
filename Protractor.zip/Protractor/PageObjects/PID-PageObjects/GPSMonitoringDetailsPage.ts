import { ElementFinder, element, by, browser } from "protractor";
import { BasePage } from "../BasePage";

export class GPSMonitoringDetailsPage extends BasePage {

    GPSMonitoringDetailsTab: ElementFinder;
    AddAsset_Btn: ElementFinder;
    AssetType: ElementFinder;

    EmailID: ElementFinder;
    Name: ElementFinder;
    CountryCode: ElementFinder;
    DeviceInfo: ElementFinder;
    UserType: ElementFinder;
    AddGroup: ElementFinder;
    GroupName: ElementFinder;
    SubmitGroupName: ElementFinder;
    Group: ElementFinder;
    TrackingStartDate: ElementFinder;
    TrackingEndDate: ElementFinder;
    RecievePVNalerts: ElementFinder;
    Radius: ElementFinder;

    Add_Btn_AlarmRecipient: ElementFinder;
    Name_AlarmRecipient: ElementFinder;
    Email_AlarmRecipient: ElementFinder;
    CountryCode_AlarmRecipient: ElementFinder;
    SearchCountryCode_AlarmRecipient: ElementFinder;
    MobileNumber_AlarmRecipient: ElementFinder;
    Save_AlarmRecipient: ElementFinder;

    SecurityToken: ElementFinder;
    PositionLogicClient: ElementFinder;
    AssetName: ElementFinder;
    IMEINumber: ElementFinder;

    WarneUserId: ElementFinder;
    SaveAsset: ElementFinder;

    constructor() {
        super();
        this.GPSMonitoringDetailsTab = element(by.xpath("//span[text()='GPS Monitoring Details']"));
        this.AddAsset_Btn = element(by.xpath("//button[text()='Add Asset']"));
        this.AssetType = element(by.css("[formcontrolname='assetType']"));

        this.EmailID = element(by.css("[formcontrolname='assetEmailId']"));
        this.Name = element(by.css("[formcontrolname='nameValue']"));
        this.CountryCode = element(by.xpath("//label[contains(text(),'Mobile Number')]/..//span[contains(@class,'ui-dropdown-trigger-icon')]"));
        this.DeviceInfo = element(by.css("[formcontrolname='deviceInfo']"));
        this.UserType = element(by.css("[formcontrolname='userType']"));
        this.AddGroup = element(by.css("a.add-group"));
        this.GroupName = element(by.css("input[placeholder='Enter Group Name']"));
        this.SubmitGroupName = element(by.xpath("//p-dialog//button[text()='SUBMIT']"));
        this.Group = element(by.css("[formcontrolname='group']"));
        this.TrackingStartDate = element(by.css("[formcontrolname='trackStartDate']"));
        this.TrackingEndDate = element(by.css("[formcontrolname='trackEndDate']"));
        this.RecievePVNalerts = element(by.css("[formcontrolname='currentLocationAlert'] div[role='checkbox'] "));
        this.Radius = element(by.css("[formcontrolname='radius']"));

        this.Add_Btn_AlarmRecipient = element(by.xpath("//app-people-monitor-details//button[text()='ADD']"));
        this.Name_AlarmRecipient = element(by.css("p-table input[placeholder='Enter Name']"));
        this.Email_AlarmRecipient = element(by.css("p-table input[type='email']"));
        this.CountryCode_AlarmRecipient = element(by.css("tbody span.ui-dropdown-trigger-icon"));
        this.SearchCountryCode_AlarmRecipient = element(by.xpath("//body/div/div/input[1]"));
        this.MobileNumber_AlarmRecipient = element(by.css("p-table input.int-tel-input"));
        this.Save_AlarmRecipient = element(by.css("td a.saveIcon"));

        this.SecurityToken = element(by.css("[formcontrolname='securityToken']"));
        this.PositionLogicClient = element(by.css("[formcontrolname='client']"));
        this.AssetName = element(by.css("[formcontrolname='nameValue']"));
        this.IMEINumber = element(by.css("[formcontrolname='imei']"));

        this.WarneUserId = element(by.css("[formcontrolname='warneUserId']"));
        this.SaveAsset = element(by.xpath("//button[@type='submit'][text()='OK']"));
    }

    clickGPSMonitoringTab = () => {
        this.clickElement(this.GPSMonitoringDetailsTab);
    }

    addAsset_MobileUser = (testdata) => {
        this.clickElement(this.AddAsset_Btn);
        this.selectDropdownValue(this.AssetType, testdata.AssetType_MobUser);
        this.autoCompleteDropdown(this.EmailID, testdata.EmailId_MobUser);
        this.enterContactNumber('Mobile Number', testdata.CountryCode, testdata.MobileNumber_MobUser);
        this.sendKeys(this.DeviceInfo, testdata.DeviceInfo);
        this.selectDropdownValue(this.UserType, testdata.UserType);
        // this.clickElement(this.AddGroup);
        // this.sendKeys(this.GroupName, testdata.GroupName);
        // this.clickElement(this.SubmitGroupName);
        // browser.driver.sleep(3000);
        this.autoCompleteDropdown(this.Group, testdata.GroupName_MobUser);
        this.datePicker(this.TrackingStartDate, testdata.StartDate);
        this.datePicker(this.TrackingEndDate, testdata.EndDate);
        this.clickElement(this.RecievePVNalerts);
        this.selectDropdownValue(this.Radius, testdata.Radius);
        this.clickElement(this.Add_Btn_AlarmRecipient);
        this.sendKeys(this.Name_AlarmRecipient, testdata.Name_AlarmRecipient);
        this.sendKeys(this.Email_AlarmRecipient, testdata.Email_AlarmRecipient);
        this.selectCountryCode_table(this.CountryCode_AlarmRecipient, this.SearchCountryCode_AlarmRecipient, testdata.CountryCode);
        this.sendKeys(this.MobileNumber_AlarmRecipient, testdata.MobileNumber_AlarmRecipient);
        this.clickElement(this.Save_AlarmRecipient);
        this.clickElement(this.SaveAsset);
    }

    addAsset_PositionLogicDevice = (testdata) => {
        this.clickElement(this.AddAsset_Btn);
        this.selectDropdownValue(this.AssetType, testdata.AssetType_PLD);
        this.sendKeys(this.SecurityToken, testdata.SecurityToken);
        this.sendKeys(this.PositionLogicClient, testdata.PositionLogicClient);
        this.autoCompleteDropdown(this.AssetName, testdata.AssetName);
        //this.sendKeys(this.IMEINumber, testdata.IMEINumber);
        this.sendKeys(this.EmailID, testdata.EmailId_PLD);
        this.enterContactNumber('Mobile Number', testdata.CountryCode, testdata.MobileNumber_PLD);
        this.sendKeys(this.DeviceInfo, testdata.DeviceInfo);
        this.selectDropdownValue(this.UserType, testdata.UserType);
        // this.clickElement(this.AddGroup);
        // this.sendKeys(this.GroupName, testdata.GroupName);
        // this.clickElement(this.SubmitGroupName);
        this.autoCompleteDropdown(this.Group, testdata.GroupName_PLD);
        this.datePicker(this.TrackingStartDate, testdata.StartDate);
        this.datePicker(this.TrackingEndDate, testdata.EndDate);
        this.clickElement(this.Add_Btn_AlarmRecipient);
        this.sendKeys(this.Name_AlarmRecipient, testdata.Name_AlarmRecipient);
        this.sendKeys(this.Email_AlarmRecipient, testdata.Email_AlarmRecipient);
        this.selectCountryCode_table(this.CountryCode_AlarmRecipient, this.SearchCountryCode_AlarmRecipient, testdata.CountryCode);
        this.sendKeys(this.MobileNumber_AlarmRecipient, testdata.MobileNumber_AlarmRecipient);
        this.clickElement(this.Save_AlarmRecipient);
        this.clickElement(this.SaveAsset);
    }

    addAsset_WarneUser = (testdata) => {
        this.clickElement(this.AddAsset_Btn);
        this.selectDropdownValue(this.AssetType, testdata.AssetType_Warne);
        this.sendKeys(this.WarneUserId, testdata.WarneUserId);
        browser.driver.sleep(5000);
        // this.sendKeys(this.Name, testdata.Name);
        // this.autoCompleteDropdown(this.EmailID, testdata.EmailId);
        // this.autoCompleteDropdown(this.CountryCode, testdata.CountryCode);
        // this.sendKeys(this.MobileNumber, testdata.MobileNumber);
        this.sendKeys(this.DeviceInfo, testdata.DeviceInfo);
        this.selectDropdownValue(this.UserType, testdata.UserType);
        // this.clickElement(this.AddGroup);
        // this.sendKeys(this.GroupName, testdata.GroupName);
        // this.clickElement(this.SubmitGroupName);
        // browser.driver.sleep(3000);
        this.autoCompleteDropdown(this.Group, testdata.GroupName_Warne);
        this.datePicker(this.TrackingStartDate, testdata.StartDate);
        this.datePicker(this.TrackingEndDate, testdata.EndDate);
        this.clickElement(this.Add_Btn_AlarmRecipient);
        this.sendKeys(this.Name_AlarmRecipient, testdata.Name_AlarmRecipient);
        this.sendKeys(this.Email_AlarmRecipient, testdata.Email_AlarmRecipient);
        this.selectCountryCode_table(this.CountryCode_AlarmRecipient, this.SearchCountryCode_AlarmRecipient, testdata.CountryCode);
        this.sendKeys(this.MobileNumber_AlarmRecipient, testdata.MobileNumber_AlarmRecipient);
        this.clickElement(this.Save_AlarmRecipient);
        this.clickElement(this.SaveAsset);
    }
}