import { ElementFinder, element, by, ElementArrayFinder, browser, ExpectedConditions as EC } from "protractor";
import { BasePage } from "../BasePage";

export class TMConfigurationPage extends BasePage {

    EditTM: ElementFinder;
    SaveTM: ElementFinder;
    TMInfo: ElementFinder;
    MapWidget: ElementFinder;
    GeneralTab: ElementFinder;
    AddGeneralTab: ElementFinder;
    Proceed: ElementFinder;
    EditGeneralTab: ElementFinder;
    NameGeneralTab: ElementFinder;
    SaveGeneralTab: ElementFinder;
    CheckList: ElementFinder;
    CheckList_Author: ElementArrayFinder;
    CheckList_AuthorComment: ElementArrayFinder;
    CheckList_QAReviewer: ElementArrayFinder;
    CheckList_QAReviewerComment: ElementArrayFinder;
    SaveCheckList: ElementFinder;
    SubmitToQA_Btn: ElementFinder;
    QAReviewed_Btn: ElementFinder;
    Publish_Btn: ElementFinder;
    InActive_Btn: ElementFinder;

    constructor() {
        super();
        this.EditTM = element(by.xpath("//app-layout//button[contains(text(),'Edit')]"));
        this.SaveTM = element(by.xpath("//app-layout//button[contains(text(),'SAVE')]"));
        this.TMInfo = element(by.css('div.tm-name-col'));
        this.GeneralTab = element(by.css('span.gridNameCls'));
        this.AddGeneralTab = element(by.css("div button.add-link-bgPostion"));
        this.Proceed = element(by.xpath("//button//span[contains(text(),'proceed')]"));
        this.MapWidget = element(by.css('span.mapBgPos'));
        this.EditGeneralTab = element(by.xpath("//span[contains(text(),'General')]/ancestor::p-scrollpanel//button[@title='Edit']"));
        this.NameGeneralTab = element(by.css("[formcontrolname='gridName']"));
        this.SaveGeneralTab = element(by.css("div button[type='submit']"));
        this.CheckList = element(by.css("button.bg-checkList"));
        this.CheckList_Author = element.all(by.xpath("//p-checkbox[@formcontrolname='isAuthor']//div[@role='checkbox']"));
        this.CheckList_AuthorComment = element.all(by.css("[formcontrolname='authorComment']"));
        this.CheckList_QAReviewer = element.all(by.xpath("//p-checkbox[@formcontrolname='isQaReviewer']//div[@role='checkbox']"));
        this.CheckList_QAReviewerComment = element.all(by.css("[formcontrolname='qaReviewerComment']"));
        this.SaveCheckList = element(by.css("app-tm-checklist button[type='submit']"));
        this.SubmitToQA_Btn = element(by.xpath("//button[text()='Submit to QA']"));
        this.QAReviewed_Btn = element(by.xpath("//button[text()='QA REVIEWED']"));
        this.Publish_Btn = element(by.xpath("//button[text()='PUBLISH']"));
        this.InActive_Btn = element(by.xpath("//button[text()='INACTIVE']"));
    }

    addGeneralTab = () => {
        this.clickElement(this.AddGeneralTab);
    }

    editGeneralTab = (name) => {
        this.clickElement(this.EditGeneralTab);
        this.NameGeneralTab.clear();
        this.sendKeys(this.NameGeneralTab, name);
        this.clickElement(this.SaveGeneralTab);
    }

    clickTMEdit = () => {
        this.clickElement(this.EditTM)
    }

    clickTMSave = () => {
        this.clickElement(this.SaveTM);
        console.log("Threat Monitor Saved");
    }

    checklist = (elem1, elem2, comment) => {
        for (var i = 0; i < 14; i++) {
            this.clickElement(elem1.get(i));
            this.sendKeys(elem2.get(i), comment)
        }
    }

    checklistAuthor = () => {
        this.clickElement(this.CheckList);
        this.checklist(this.CheckList_Author, this.CheckList_AuthorComment, 'Author Reviewed');
        this.clickElement(this.SaveCheckList);
    }

    checklistQAReviewer = () => {
        this.clickElement(this.CheckList);
        this.checklist(this.CheckList_QAReviewer, this.CheckList_QAReviewerComment, 'QA Reviewed');
        this.clickElement(this.SaveCheckList);
    }

    clickSubmitToQA = () => {
        this.clickElement(this.SubmitToQA_Btn);
        this.clickElement(this.Confirm);
    }

    clickQAReviewed = () => {
        this.clickElement(this.QAReviewed_Btn);
        this.clickElement(this.Confirm);
    }

    clickPublish = () => {
        this.clickElement(this.Publish_Btn);
        this.clickElement(this.Confirm);
    }

    clickInactive = () => {
        this.clickElement(this.InActive_Btn);
        this.clickElement(this.Confirm);
    }

    waitForTMStatus = (status) => {
        browser.wait(EC.textToBePresentInElement(this.TMInfo, status), 60000);
    }
}
