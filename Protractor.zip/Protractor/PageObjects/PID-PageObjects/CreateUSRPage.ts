import { browser, by, element, ElementFinder, ExpectedConditions as EC } from "protractor";
import { BasePage } from "../BasePage";

export class CreateUSRPage extends BasePage {

    CreateUSR: ElementFinder;
    CreatedUSRNumber: ElementFinder;
    Edit: ElementFinder;
    Save: ElementFinder;
    Submit: ElementFinder;
    Assign: ElementFinder;
    
    constructor() {
        super();
        this.CreateUSR = element(by.xpath("//app-service-request//span[text()='Create USR']"));
        this.CreatedUSRNumber = element(by.xpath("//app-service-request//span[contains(text(),'USR')]"));
        this.Edit = element(by.xpath("//app-service-request//button[text()='edit']"));
        this.Save = element(by.xpath("//app-service-request//button[text()=' save']"));
        this.Submit = element(by.xpath("//app-service-request//span[text()='submit']"));
        this.Assign = element(by.xpath("//app-service-request//span[text()='Assign']"));
    }

    clickEdit = () => {
        this.clickElement(this.Edit);
    }

    saveDetails = () => {
        this.clickElement(this.Save)
        this.clickElement(this.Confirm);
    }

    submitDetails = () => {
        this.clickElement(this.Submit);
        browser.driver.sleep(5000);
        this.clickElement(this.Confirm);
    }

    assignUSR = () => {
        this.clickElement(this.Assign);
        browser.driver.sleep(5000);
        this.clickElement(this.Confirm);
    }

    waitForUSRStatus = (status) => {
        browser.wait(EC.textToBePresentInElement(this.CreatedUSRNumber, status), 60000);
    }
}


