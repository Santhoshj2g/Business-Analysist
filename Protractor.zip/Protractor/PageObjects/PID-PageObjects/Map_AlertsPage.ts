import { by, element, ElementFinder } from "protractor";
import { BasePage } from "../BasePage";

export class Map_AlertsPage extends BasePage {

    Alerts: ElementFinder;
    SaveAlerts: ElementFinder;

    constructor() {
        super();
        this.Alerts = element(by.css("span[title='Alerts']"));
        this.SaveAlerts = element(by.xpath("//app-map-addons//button[text()='SAVE']"));
    }

    selectAlerts = (testdata) => {
        var elem = element(by.xpath("//li[@aria-label='" + testdata + "']//span[contains(text(),'" + testdata + "')]"));
        this.clickElement(elem);
    }

    viewAlerts = (testdata) => {
        this.clickElement(this.Alerts);
        this.selectAlerts(testdata.AlertName);
        this.clickElement(this.SaveAlerts);
    }
}