import { BasePage } from "../BasePage";
import { ElementFinder, element, by, browser } from "protractor";

export class CreateAlertWidgetPage extends BasePage {

    CreateAlertWidget: ElementFinder;
    Title: ElementFinder;
    Language: ElementFinder;
    Description: ElementFinder;
    Source: ElementFinder;
    Channel: ElementFinder;

    AddLocation: ElementFinder;
    StreetAddress: ElementFinder;
    ZipPostalCode: ElementFinder;
    Latitude: ElementFinder;
    Longitude: ElementFinder;
    AddGivenLocation: ElementFinder;

    Category: ElementFinder;
    Certainty: ElementFinder;
    Severity: ElementFinder;
    Urgency: ElementFinder;
    Signature: ElementFinder;
    Publish: ElementFinder;
    ConfirmPublish: ElementFinder;

    constructor() {
        super();
        this.CreateAlertWidget = element(by.xpath("//div[@draggable='true']/child::span[normalize-space()='create alert']/.."));
        this.Title = element(by.css("[formcontrolname='title']"));
        this.Language = element(by.css("[formcontrolname='language']"));
        this.Description = element(by.css("[formcontrolname='description']"));
        this.Source = element(by.css("[formcontrolname='source']"));
        this.Channel = element(by.css("[formcontrolname='channel']"));

        this.AddLocation = element(by.xpath("//app-createalert//button[contains(text(),'ADD LOCATION')]"));
        this.StreetAddress = element(by.css("[formcontrolname='streetAddress']"));
        this.ZipPostalCode = element(by.css("[formcontrolname='zipCode']"));
        this.AddGivenLocation = element(by.xpath("//app-add-location-modal//button[text()='ADD']"));

        this.Category = element(by.css("[formcontrolname='category']"));
        this.Certainty = element(by.css("[formcontrolname='certainity']"));
        this.Severity = element(by.css("[formcontrolname='severity']"));
        this.Urgency = element(by.css("[formcontrolname='urgency']"));
        this.Signature = element(by.css("[formcontrolname='signature']"));
        this.Publish = element(by.xpath("//app-createalert//button[text()='PUBLISH']"));
        this.ConfirmPublish = element(by.xpath("//button//span[contains(text(),'Confirm')]"));
    }

    createAlert = (testdata) => {
        this.selectDropdownValue(this.Language, testdata.Language)
        this.sendKeys(this.Title, testdata.Title);
        this.sendKeys(this.Description, testdata.Description);
        this.sendKeys(this.Source, testdata.Source);
        this.selectDropdownValue(this.Channel, testdata.Channel);

        this.clickElement(this.AddLocation);
        this.sendKeys(this.StreetAddress, testdata.StreetAddress);
        this.clickElement(this.ZipPostalCode);
        browser.driver.sleep(3000);
        this.clickElement(this.AddGivenLocation);

        this.selectDropdownValue(this.Category, testdata.Category);
        this.selectDropdownValue(this.Certainty, testdata.Certainty);
        this.selectDropdownValue(this.Severity, testdata.Severity);
        this.selectDropdownValue(this.Urgency, testdata.Urgency);
        this.sendKeys(this.Signature, testdata.Signature);
        this.clickElement(this.Publish);
        this.clickElement(this.ConfirmPublish);
    }
}