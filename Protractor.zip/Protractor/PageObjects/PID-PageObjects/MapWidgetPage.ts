import { by, element, ElementFinder } from "protractor";
import { BasePage } from "../BasePage";

export class MapWidgetPage extends BasePage {

    MapWidget: ElementFinder;
    MapMenu_Btn: ElementFinder;

    constructor() {
        super();
        this.MapWidget = element(by.xpath("//div[@draggable='true']/child::span[normalize-space()='map']/.."));
        this.MapMenu_Btn = element(by.css(".mapWidget>div>a.hamburgerIcon"));
    }
}
