import { ElementFinder, element, by, browser } from "protractor";
import { BasePage } from "../BasePage";

export class ServiceRequestPage extends BasePage {

    SearchUSR: ElementFinder;

    constructor() {
        super();
        this.SearchUSR = element(by.xpath("//input[@placeholder='Search...']"));
    }

    selectUSR = (testdata) => {
        this.sendKeys(this.SearchUSR, testdata.USRNumber);
        this.clickSpanElement(testdata.USRNumber);
    }
}