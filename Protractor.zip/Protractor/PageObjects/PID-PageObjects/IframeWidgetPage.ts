import { by, element, ElementFinder } from "protractor";
import { BasePage } from "../BasePage";

export class IframeWidgetPage extends BasePage {

    IFrameWidget: ElementFinder;
    ConfigureIFrame: ElementFinder;
    EnterURL: ElementFinder;
    IFrameSubmit: ElementFinder;

    constructor() {
        super();
        this.IFrameWidget = element(by.xpath("//div[@draggable='true']/child::span[normalize-space()='iframe']/.."));
        this.ConfigureIFrame = element(by.xpath("//div[contains(text(),' Configure IFrame')]"));
        this.EnterURL = element(by.xpath("//input[@placeholder='Enter URL']"));
        this.IFrameSubmit = element(by.xpath("//button[contains(text(),'SUBMIT')]"));
    }

    waitForIFrame = (testdata) => {
        var IFrameView = element(by.xpath("//app-iframe//span[@title='" + testdata + "']"));
        this.waitForElementVisibility(IFrameView);
    }

    configureIFrame = (testdata) => {
        this.clickElement(this.ConfigureIFrame);
        this.sendKeys(this.EnterURL, testdata.IframeURL);
        this.clickElement(this.IFrameSubmit);
        this.waitForIFrame(testdata.IframeURL);
    }
}