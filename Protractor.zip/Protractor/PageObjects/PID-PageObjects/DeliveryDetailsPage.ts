import { by, element, ElementFinder } from "protractor";
import { BasePage } from "../BasePage";
import { TMConfigurationPage } from "./TMConfigurationPage";
let tmConfigPage = new TMConfigurationPage();

export class DeliveryDetailsPage extends BasePage {

    DeliveryDetailsTab: ElementFinder;
    ThreatMonitorName: ElementFinder;
    DescriptionTM: ElementFinder;
    CreateTMButton: ElementFinder;
    CopyFromExisting: ElementFinder;

    constructor() {
        super();
        this.DeliveryDetailsTab = element(by.xpath("//span[contains(text(),'Delivery Details')]"));
        this.ThreatMonitorName = element(by.css("[formcontrolname='threatMonitorName']"));
        this.DescriptionTM = element(by.css("[formcontrolname='threatMonitorDescription']"));
        this.CreateTMButton = element(by.xpath("//button[contains(text(),'Create')]"));
        this.CopyFromExisting = element(by.xpath("//button[contains(text(),'Copy From Existing')]"));
    }

    clickDeliveryDetailsTab = () => {
        this.clickElement(this.DeliveryDetailsTab);
    }

    createTM = (testdata) => {
        this.sendKeys(this.ThreatMonitorName, testdata.TMName);
        this.sendKeys(this.DescriptionTM, testdata.TMDescription);
        this.clickElement(this.CreateTMButton);
    }

    selectTM = (testdata) => {
        this.clickSpanElement(testdata.TMName);
        tmConfigPage.clickTMEdit();
    }
}