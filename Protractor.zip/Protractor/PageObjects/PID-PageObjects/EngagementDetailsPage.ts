import { browser, by, element, ElementFinder } from "protractor";
import { BasePage } from "../BasePage";

export class EngagementDetailsPage extends BasePage {

    EngagementDetailsTab: ElementFinder;
    Purpose_TM: ElementFinder;

    AddAuthor: ElementFinder;
    PIDAuthorName: ElementFinder;
    StartDate_Author: ElementFinder;
    EndDate_Author: ElementFinder;
    Description_Author: ElementFinder;
    SaveAuthor: ElementFinder;
    QCReviewer: ElementFinder;
    StartDate_Reviewer: ElementFinder;
    EndDate_Reviewer: ElementFinder;
    Description_Reviewer: ElementFinder;

    constructor() {
        super();
        this.EngagementDetailsTab = element(by.css("#engagementDetailTab-link"));
        this.Purpose_TM = element(by.css("[formcontrolname='threatMonitorPurpose']"));
        
        // this.Category = element(by.css("[formcontrolname='alertingCategory']"));
        // this.Severity = element(by.css("[formcontrolname='alertingSeverity']"));
        // this.Certainty = element(by.css("[formcontrolname='alertingCertainity']"));
        // this.Urgency = element(by.css("[formcontrolname='alertingUrgency']"));
        // this.WarneType = element(by.css("[formcontrolname='usrAlertWarneTypes']"));
        // this.Channel = element(by.css("[formcontrolname='usrAlertChannels']"));
        
        // this.Keywords_Alert = element(by.css("[formcontrolname='keywords']"));
        // this.StartDate_Alert = element(by.css("[formcontrolname='alertStartDate']"));
        // this.EndDate_Alert = element(by.css("[formcontrolname='alertEndDate']"));

        // this.AddRecipinet_Btn = element(by.xpath("//button[contains(text(),'ADD RECIPIENT')]"));
        // this.RecipientName = element(by.css("[formcontrolname='recipientName']"));
        // this.EmailID = element(by.css("[formcontrolname='recipientEmailId']"));
        // this.Yes_Alert = element(by.xpath("//p-radiobutton[@name='isNotify']//label[contains(text(),'Yes')]"));
        // this.SaveRecipient = element(by.xpath("//app-add-recipient//button[text()=' save']"));

        this.AddAuthor = element(by.xpath("//button[contains(text(),' Add Author')]"));
        this.PIDAuthorName = element(by.css("app-dropdown[formcontrolname='authorName']"));
        this.StartDate_Author = element(by.css("input[formcontrolname='startDate']"));
        this.EndDate_Author = element(by.css("input[formcontrolname='endDate']"));
        this.EndDate_Author = element(by.css("input[formcontrolname='endDate']"));
        this.Description_Author = element(by.css("[formcontrolname='description']"));
        this.SaveAuthor = element(by.xpath("//app-add-author//button[@type='submit']"));
        this.QCReviewer = element(by.css("[formcontrolname='reviewerId']"));
        this.StartDate_Reviewer = element(by.css("[formcontrolname='reviewerStartDate']"));
        this.EndDate_Reviewer = element(by.css("[formcontrolname='reviewerEndDate']"));
        this.Description_Reviewer = element(by.css("[formcontrolname='reviewerComment']"));
    }

    fillEngagementDetailsTab = (testdata) => {

        //EngagementDetails
        this.clickElement(this.EngagementDetailsTab);
        browser.driver.sleep(5000);
        this.multiselectDropdown(this.Purpose_TM)
        // this.multiselectDropdown(this.Purpose_TM);
        // this.multiselectDropdown(this.Category);
        // this.multiselectDropdown(this.Severity);
        // this.multiselectDropdown(this.Certainty);
        // this.multiselectDropdown(this.Urgency);
        // this.multiselectDropdown(this.WarneType);
        // this.multiselectDropdown(this.Channel);

        // //keywords
        // this.sendKeys(this.Keywords_Alert, testdata.Keywords_Alert);
        // this.datePicker(this.StartDate_Alert, testdata.StartDate);
        // this.datePicker(this.EndDate_Alert, testdata.EndDate);

        // //recipients
        // this.clickElement(this.AddRecipinet_Btn);
        // this.sendKeys(this.RecipientName, testdata.RecipientName);
        // this.sendKeys(this.EmailID, testdata.EmailID);
        // this.enterContactNumber("Mobile Number", testdata.CountryCode, testdata.MobileNumber);
        // this.clickElement(this.Yes_Alert);
        // this.clickElement(this.SaveRecipient);

        //assign author
        this.clickElement(this.AddAuthor);
        this.selectDropdownValue(this.PIDAuthorName, testdata.PIDAuthorName);
        this.datePicker(this.StartDate_Author, testdata.StartDate);
        this.datePicker(this.EndDate_Author, testdata.EndDate);
        this.sendKeys(this.Description_Author, testdata.Description_Author);
        this.clickElement(this.SaveAuthor);

        //QcReviewer
        this.selectDropdownValue(this.QCReviewer, testdata.QCReviewer);
        this.datePicker(this.StartDate_Reviewer, testdata.StartDate);
        this.datePicker(this.EndDate_Reviewer, testdata.EndDate);
        this.sendKeys(this.Description_Reviewer, testdata.Description_Reviewer);
    }
}
