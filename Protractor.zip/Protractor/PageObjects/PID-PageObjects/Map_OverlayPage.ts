import { by, element, ElementFinder } from "protractor";
import { BasePage } from "../BasePage";

export class Map_OverlayPage extends BasePage {

    Overlay: ElementFinder;
    CreateOverlay: ElementFinder;
    Title: ElementFinder;
    Description: ElementFinder;
    Group: ElementFinder;
    KML_FileType: ElementFinder;
    GeoRSS_FileType: ElementFinder;
    SpecifyURL: ElementFinder;
    URL: ElementFinder;
    ChooseFile: ElementFinder;
    SaveOverlay: ElementFinder;

    constructor() {
        super();
        this.Overlay = element(by.css("span[title='Overlay']"));
        this.CreateOverlay = element(by.xpath("//button[text()='Create']"));
        this.Title = element(by.css("[formcontrolname='name']"));
        this.Description = element(by.css("[formcontrolname='description']"));
        this.Group = element(by.css("[formcontrolname='overlayGroupId']"));
        this.GeoRSS_FileType = element(by.xpath("//p-radiobutton[@value='georss']//span"));
        this.SpecifyURL = element(by.xpath("//p-radiobutton[@value='url']//span"));
        this.URL = element(by.css("[formcontrolname='overlayUrl']"));
        this.ChooseFile = element(by.xpath("//label[normalize-space()='Choose File']"));
        this.SaveOverlay = element(by.xpath("//app-overlay//button[text()='SAVE']"));
    }

    create_Overlay_KML = (testdata) => {
        this.clickElement(this.Overlay);
        this.clickElement(this.CreateOverlay);
        this.sendKeys(this.Title, testdata.Title);
        this.sendKeys(this.Description, testdata.Description);
        this.autoCompleteDropdown(this.Group, testdata.Group);
    }

    create_Overlay_GeoRSS = (testdata) => {
        this.clickElement(this.Overlay);
        this.clickElement(this.CreateOverlay);
        this.sendKeys(this.Title, testdata.Title);
        this.sendKeys(this.Description, testdata.Description);
        this.autoCompleteDropdown(this.Group, testdata.Group);
    }

    create_Overlay_URL = (testdata) => {
        this.clickElement(this.Overlay);
        this.clickElement(this.CreateOverlay);
        this.sendKeys(this.Title, testdata.Title);
        this.sendKeys(this.Description, testdata.Description);
        this.autoCompleteDropdown(this.Group, testdata.Group);
        this.clickElement(this.GeoRSS_FileType);
        this.scrollIntoView(this.SpecifyURL);
        this.clickElement(this.SpecifyURL);
        this.sendKeys(this.URL, testdata.URL);
        this.clickElement(this.SaveOverlay);
    }
}