import { browser, by, ElementFinder, element } from "protractor";
import { BasePage } from "../BasePage";

export class RssWidgetPage extends BasePage {

    RSSWidget: ElementFinder;
    ConfigRSSFeed_Btn: ElementFinder;
    RSSFeedTitle: ElementFinder;
    RSSFeedURL: ElementFinder;
    AddNewRSS_Btn: ElementFinder;
    SearchRssFeed: ElementFinder;
    AddRSS_Btn: ElementFinder;

    constructor() {
        super();
        this.RSSWidget = element(by.xpath("//div[@draggable='true']/child::span[normalize-space()='rss']/.."));
        this.ConfigRSSFeed_Btn = element(by.css("app-rss-feed span.config-icon"));
        this.RSSFeedTitle = element(by.css("[formcontrolname='rssName']"));
        this.RSSFeedURL = element(by.css("[formcontrolname='rssFeedUrl']"));
        this.AddNewRSS_Btn = element(by.css("app-addrssfeed span.add-rss-icon"));
        this.SearchRssFeed = element(by.css("app-addrssfeed [placeholder='Search...']"));
        this.AddRSS_Btn = element(by.xpath("//button[contains(text(),'ADD')]"));
    }

    selectRSSFeed = (testData) => {
        var elem = element(by.xpath("//span[@title='" + testData + "']/ancestor::tr//div[@role='checkbox']"));
        this.clickElement(elem);
    };

    addNewRSSFeed = (testData) => {
        this.clickElement(this.ConfigRSSFeed_Btn);
        this.sendKeys(this.RSSFeedTitle, testData.RSSFeedTitle);
        this.sendKeys(this.RSSFeedURL, testData.RSSFeedURL);
        this.clickElement(this.AddNewRSS_Btn);
        this.sendKeys(this.SearchRssFeed, testData.RSSFeedTitle);
        browser.driver.sleep(2000);
        this.selectRSSFeed(testData.RSSFeedTitle);
        this.clickElement(this.AddRSS_Btn);
    };
};