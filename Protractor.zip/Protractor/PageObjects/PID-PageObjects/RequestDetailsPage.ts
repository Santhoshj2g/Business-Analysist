import { by, element, ElementFinder, browser } from "protractor";
import { BasePage } from "../BasePage";

export class RequestDetailsPage extends BasePage {

    RequestDetailsTab: ElementFinder;
    RequestingRegions: ElementFinder;
    RequestingOffice: ElementFinder;
    Client: ElementFinder;
    RequestingDirector: ElementFinder;
    RequestingDirectorDepartment: ElementFinder;
    OMPOCName: ElementFinder;
    OMPOCEmail: ElementFinder;
    OMPOCNotes: ElementFinder;
    ServiceType: ElementFinder;
    Category: ElementFinder;
    Services_People: ElementFinder;
    Services_Facility: ElementFinder;
    Services_FocusedIncidentAlerts: ElementFinder;
    ServiceDescription: ElementFinder;
    StartDate_USR: ElementFinder;
    EndDate_USR: ElementFinder;
    TimeZone: ElementFinder;
    AddLocationPerson_Btn: ElementFinder;
    StreetAddress: ElementFinder;
    ZipPostalCode: ElementFinder;
    Radius: ElementFinder;
    AdditionalDetails: ElementFinder;
    Add_Btn: ElementFinder;
    OperationalManager: ElementFinder;
    RecipientType: ElementFinder;
    Recipient: ElementFinder;

    constructor() {
        super();
        this.RequestDetailsTab = element(by.css("#requestDetailTab-link"));
        this.RequestingRegions = element(by.css("[formcontrolname='requestingRegionId']"));
        this.RequestingOffice = element(by.css("[formcontrolname='requestingOfficeId']"));
        this.Client = element(by.css("[formcontrolname='clientId']"));
        this.RequestingDirector = element(by.css("[formcontrolname='requestingDirectorId']"));
        this.RequestingDirectorDepartment = element(by.css("[formcontrolname='requestingDirectorDepartmentId']"));
        this.OMPOCName = element(by.css("[formcontrolname='omPocName']"));
        this.OMPOCEmail = element(by.css("[formcontrolname='omPocEmailId']"));
        this.OMPOCNotes = element(by.css("[formcontrolname='omPocNotes']"));
        this.ServiceType = element(by.css("[formcontrolname='serviceTypeId']"));
        this.Category = element(by.css("[formcontrolname='serviceTypeCategoryId']"));
        this.Services_People = element(by.xpath("//span[contains(text(),'People')]"));
        this.Services_Facility = element(by.xpath("//span[contains(text(),'Facility')]"));
        this.Services_FocusedIncidentAlerts = element(by.xpath("//span[contains(text(),'Focused Incident Alerts')]"));
        this.ServiceDescription = element(by.css("[formcontrolname='serviceDescription']"));
        this.StartDate_USR = element(by.css("[formcontrolname='usrStartDate']"));
        this.EndDate_USR = element(by.css("[formcontrolname='usrEndDate']"));
        this.TimeZone = element(by.css("[formcontrolname='timeZoneId']"));
        this.AddLocationPerson_Btn = element(by.xpath("//button[normalize-space()='Add Location/Person']"));
        this.StreetAddress = element(by.css("[formcontrolname='streetAddress']"));
        this.ZipPostalCode = element(by.css("[formcontrolname='zipCode']"));
        this.Radius = element(by.css("[formcontrolname='radius']"));
        this.AdditionalDetails = element(by.css("[formcontrolname='locationDescription']"));
        this.Add_Btn = element(by.xpath("//app-add-location-modal//button[normalize-space()='ADD']"));
        this.OperationalManager = element(by.css("[formcontrolname='omLoginId']"));
        this.RecipientType = element(by.css("[formcontrolname='recipregion']"));
        this.Recipient = element(by.css("p-autocomplete[formcontrolname='usrRecipients']>span>ul>li>input"));
    }

    selectRecipient = (testdata) => {
        var elem = element(by.xpath("//p-autocomplete//div[contains(text(),'" + testdata + "')]"));
        this.clickElement(elem);
    };

    fillRequestDetailsTab = (testdata) => {

        //Request Detail Tab
        this.clickElement(this.RequestDetailsTab)
        this.selectDropdownValue(this.RequestingRegions, testdata.RequestingRegions);
        this.selectDropdownValue(this.RequestingOffice, testdata.RequestingOffice);
        this.selectDropdownValue(this.Client, testdata.Client);
        this.selectDropdownValue(this.RequestingDirector, testdata.RequestingDirector);
        this.selectDropdownValue(this.RequestingDirectorDepartment, testdata.RequestingDirectorDepartment);

        this.sendKeys(this.OMPOCName, testdata.OMPOCName);
        this.enterContactNumber("Phone Number", testdata.CountryCode, testdata.OMPOCNumber);
        this.sendKeys(this.OMPOCEmail, testdata.OMPOCEmail);
        this.sendKeys(this.OMPOCNotes, testdata.OMPOCNotes);

        this.selectDropdownValue(this.ServiceType, testdata.ServiceType);
        this.selectDropdownValue(this.Category, testdata.Category);
        this.clickElement(this.Services_People);
        this.clickElement(this.Services_Facility);
        this.clickElement(this.Services_FocusedIncidentAlerts);
        this.sendKeys(this.ServiceDescription, testdata.ServiceDescription);

        this.datePicker(this.StartDate_USR, testdata.StartDate);
        this.datePicker(this.EndDate_USR, testdata.EndDate);
        this.selectDropdownValue(this.TimeZone, testdata.TimeZone);


        this.clickElement(this.AddLocationPerson_Btn);
        this.sendKeys(this.StreetAddress, testdata.StreetAddress);
        this.sendKeys(this.ZipPostalCode, testdata.ZipPostalCode);
        this.Radius.clear();
        this.sendKeys(this.Radius, testdata.Radius);
        this.sendKeys(this.AdditionalDetails, testdata.AdditionalDetails);
        browser.driver.sleep(2000);
        this.clickElement(this.Add_Btn);

        this.selectDropdownValue(this.OperationalManager, testdata.OperationalManager);
        this.selectDropdownValue(this.RecipientType, testdata.RecipientType);
        this.sendKeys(this.Recipient, testdata.Recipient.substring(0, 4));
        this.selectRecipient(testdata.Recipient);
    }
}