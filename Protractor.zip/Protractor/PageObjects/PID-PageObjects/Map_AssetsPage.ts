import { by, element, ElementFinder } from "protractor";
import { BasePage } from "../BasePage";

export class Map_AssetsPage extends BasePage {

    Assets: ElementFinder;
    AssetsLocation: ElementFinder;
    AddAsset: ElementFinder;

    constructor() {
        super();
        this.Assets = element(by.css("span[title='Assets']"));
        this.AssetsLocation = element(by.css("app-dropdown.filterType"));
        this.AddAsset = element(by.xpath("//app-map//button[contains(text(),'ADD')]"));
    }

    selectAssetGroup = (testdata) => {
        var assetsGroup = element(by.css("p-treenode [aria-label='" + testdata + "']"));
        this.clickElement(assetsGroup);
    }

    showAssetsInMap = (testdata) => {
        this.clickElement(this.Assets);
        this.selectDropdownValue(this.AssetsLocation, testdata.AssetsLocation);
        this.selectAssetGroup(testdata.Group1);
        this.selectAssetGroup(testdata.Group2);
        this.selectAssetGroup(testdata.Group3);
        this.clickElement(this.AddAsset);
    }
}