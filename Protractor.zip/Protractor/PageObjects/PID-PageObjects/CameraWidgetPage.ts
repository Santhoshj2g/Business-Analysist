import { ElementFinder, element, by, browser, ExpectedConditions as EC } from "protractor";
import { BasePage } from "../BasePage";

export class CameraWidgetPage extends BasePage {

    CameraWidget: ElementFinder;
    ConfigureCamera: ElementFinder;
    IPCamera: ElementFinder;
    MJPEGCamera: ElementFinder;
    JPEGCamera: ElementFinder;
    EnterTitle: ElementFinder;
    EnterLink: ElementFinder;
    Addbutton: ElementFinder;
    SearchCamera: ElementFinder;
    PlayCamera: ElementFinder;

    VideoCameraView: ElementFinder;
    ImageCameraView: ElementFinder;

    constructor() {
        super();
        this.CameraWidget = element(by.xpath("//div[@draggable='true']/child::span[normalize-space()='camera']/.."));
        this.ConfigureCamera = element(by.xpath("//div[contains(text(),' Configure Camera')]"));
        this.IPCamera = element(by.xpath("//label[contains(text(),'IP Camera')]"));
        this.MJPEGCamera = element(by.xpath("//label[contains(text(),'MJPEG')]"));
        this.JPEGCamera = element(by.xpath("//label[contains(text(),'JPEG Image')]"));

        this.EnterTitle = element(by.css("input[placeholder='Enter Title']"));
        this.EnterLink = element(by.css("input[placeholder='Enter Your Link']"));
        this.Addbutton = element(by.xpath("//input[@placeholder='Enter Your Link']//following::button[2]"));
        this.SearchCamera = element(by.css("input[placeholder='Search...']"));
        this.PlayCamera = element(by.xpath("//button[contains(text(),'ADD')]"));

        this.VideoCameraView = element(by.css("div.video-js"));
        this.ImageCameraView = element(by.css(".img-responsive.img-rounded.detailimage"));
    }

    deleteCameraLink = (testdata) => {
        var elem = element(by.xpath("//span[normalize-space()='" + testdata + "']/ancestor::tr//button[@title='Delete']"));
        this.clickElement(elem);
    };

    selectCameraLink(testdata) {
        var elem = element(by.xpath("//span[normalize-space()='" + testdata + "']/ancestor::tr//span[contains(@class,'ui-radiobutton-icon')]"));
        this.clickElement(elem);
    }

    addIPCameraRTSP = (testdata) => {
        this.clickElement(this.ConfigureCamera);
        this.clickElement(this.IPCamera);
        this.sendKeys(this.EnterTitle, testdata.IP_RTSP_Title);
        this.sendKeys(this.EnterLink, testdata.IP_RTSP_URL);
        this.clickElement(this.Addbutton);
        this.sendKeys(this.SearchCamera, testdata.IP_RTSP_Title);
        browser.driver.sleep(2000);
        this.selectCameraLink(testdata.IP_RTSP_Title);
        this.clickElement(this.PlayCamera);
        this.waitForElementVisibility(this.VideoCameraView);
    }

    deleteIPCameraRTSP = (testdata) => {
        this.clickElement(this.ConfigureCamera);
        this.sendKeys(this.SearchCamera, testdata.IP_RTSP_URL);
        this.deleteCameraLink(testdata.IP_RTSP_URL);
    }

    addIPCameraM3U8 = (testdata) => {
        this.clickElement(this.ConfigureCamera);
        this.clickElement(this.IPCamera);
        this.sendKeys(this.EnterTitle, testdata.IP_M3U8_Title);
        this.sendKeys(this.EnterLink, testdata.IP_M3U8_URL);
        this.clickElement(this.Addbutton);
        this.sendKeys(this.SearchCamera, testdata.IP_M3U8_Title);
        browser.driver.sleep(2000);
        this.selectCameraLink(testdata.IP_M3U8_Title);
        this.clickElement(this.PlayCamera);
        this.waitForElementVisibility(this.VideoCameraView);
    }

    deleteIPCameraM3U8 = (testdata) => {
        this.clickElement(this.ConfigureCamera);
        this.sendKeys(this.SearchCamera, testdata.IP_M3U8_URL);
        this.deleteCameraLink(testdata.IP_M3U8_URL);
    }

    addMJPEGCamera = (testdata) => {
        this.clickElement(this.ConfigureCamera);
        this.clickElement(this.MJPEGCamera);
        this.sendKeys(this.EnterTitle, testdata.MJPEG_Title);
        this.sendKeys(this.EnterLink, testdata.MJPEG_URL);
        this.clickElement(this.Addbutton);
        this.sendKeys(this.SearchCamera, testdata.MJPEG_Title);
        browser.driver.sleep(2000);
        this.selectCameraLink(testdata.MJPEG_Title);
        this.clickElement(this.PlayCamera);
        this.waitForElementVisibility(this.ImageCameraView);
    }

    deleteMJPEGCamera = (testdata) => {
        this.clickElement(this.ConfigureCamera);
        this.sendKeys(this.SearchCamera, testdata.MJPEG_URL);
        this.deleteCameraLink(testdata.MJPEG_URL);
    }

    addJPEGCamera = (testdata) => {
        this.clickElement(this.ConfigureCamera);
        this.clickElement(this.JPEGCamera);
        this.sendKeys(this.EnterTitle, testdata.JPEG_Title);
        this.sendKeys(this.EnterLink, testdata.JPEG_URL);
        this.clickElement(this.Addbutton);
        this.sendKeys(this.SearchCamera, testdata.JPEG_Title);
        browser.driver.sleep(2000);
        this.selectCameraLink(testdata.JPEG_Title);
        this.clickElement(this.PlayCamera);
        this.waitForElementVisibility(this.ImageCameraView);
    }

    deleteJPEGCamera = (testdata) => {
        this.clickElement(this.ConfigureCamera);
        this.sendKeys(this.SearchCamera, testdata.JPEG_URL);
        this.deleteCameraLink(testdata.JPEG_URL);
    }
}