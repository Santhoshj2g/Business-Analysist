import { ElementFinder, element, by, browser, ExpectedConditions as EC } from "protractor";
import { BasePage } from "../BasePage";

export class YouTubeWidgetPage extends BasePage {

    YouTubeWidget: ElementFinder;
    EnterYTURL: ElementFinder;
    SearchYT: ElementFinder;
    SelectVideo: ElementFinder;
    PlayVideo: ElementFinder;
    CloseVideo: ElementFinder;

    constructor() {
        super();
        this.YouTubeWidget = element(by.xpath("//div[@draggable='true']/child::span[normalize-space()='youtube']/.."));
        this.EnterYTURL = element(by.css("input[placeholder='Search videos...']"));
        this.SearchYT = element(by.xpath("//button[normalize-space()='Search']"));
        this.SelectVideo = element(by.xpath("//div[contains(@class,'result-card')][1]"));
        this.PlayVideo = element(by.css("button.ytp-large-play-button"));
        this.CloseVideo = element(by.xpath("//span[contains(text(),'Close')]"));
    }

    playVideosInYoutube = (testdata) => {
        this.sendKeys(this.EnterYTURL, testdata.YTURL);
        this.clickElement(this.SearchYT);
        this.waitForElementVisibility(this.SelectVideo);
        //this.clickElement(this.SelectVideo);
        //browser.driver.sleep(10000);
        // this.clickElement(this.PlayVideo);
        // browser.driver.sleep(5000);
        // this.clickElement(this.CloseVideo);
    }
}