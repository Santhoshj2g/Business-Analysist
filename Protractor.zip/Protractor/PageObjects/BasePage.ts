import { ElementFinder, browser, element, by, ExpectedConditions as EC, ElementArrayFinder } from "protractor";
import { JS_HTML5_DND } from "../Utilities/DragAndDrop"
import { expect } from "chai";

export class BasePage {

    PageLoad: ElementFinder;
    PageBlur: ElementFinder;
    ParentLoad: ElementFinder;
    WidgetLoad: ElementFinder;
    TableLoad: ElementFinder;
    TableContentLoad: ElementFinder;
    GridLoad: ElementFinder;
    PinkertonDashboard: ElementFinder;
    TargetWindow: ElementFinder;
    Confirm: ElementFinder;
    MultiSelectCheckbox: ElementFinder;
    Checkboxes: ElementArrayFinder;
    SelectAllCheckbox: ElementFinder;
    StatusAlert: ElementFinder;
    SuccessAlert: ElementFinder;
    Search: ElementFinder;
    BackButton: ElementFinder;

    constructor() {
        this.PageLoad = element(by.css("div.loading-screen-wrapper"));
        this.PageBlur = element(by.css("div.blurBg"));
        this.ParentLoad = element(by.css("div.parentLoader"));
        this.WidgetLoad = element(by.css("div.widgetLoader"));
        this.TableLoad = element(by.css("div.ui-table-loading"));
        this.TableContentLoad = element(by.css("div.ui-table-loading-content"));
        this.GridLoad = element(by.css("div.pinkerton-grid-loader-content"));
        this.PinkertonDashboard = element(by.css("a[href='/account/dashboard']"));
        this.TargetWindow = element(by.xpath("//div[text()='Drag and drop widget here'][1]"));
        this.Confirm = element(by.xpath("//span[text()='Confirm']"));//app-confirm-dialog-popup//span[text()='Confirm']
        this.MultiSelectCheckbox = element(by.css(".ui-chkbox.ui-widget.ng-star-inserted"));
        this.Checkboxes = element.all(by.css("div[role='checkbox'][aria-checked='false']"));
        this.SelectAllCheckbox = element(by.css("div.grid-select-all-checkbox div[role='checkbox']"));
        this.StatusAlert = element(by.css("div[role='alert'].ui-messages"));//alert>div.alert.alert-success  //for PID
        this.SuccessAlert = element(by.css("div[role='alert'].ui-messages.ui-messages-success"));
        this.Search = element(by.css("p-table input.global-filter"));
        this.BackButton = element(by.css("span.backbutton"));
    }

    waitTillPageLoads = () => {
        browser.wait(EC.invisibilityOf(this.PageLoad), 120000);
        browser.wait(EC.invisibilityOf(this.PageBlur), 120000);
        browser.wait(EC.invisibilityOf(this.ParentLoad), 120000);
        browser.wait(EC.invisibilityOf(this.WidgetLoad), 120000);
        browser.wait(EC.invisibilityOf(this.TableLoad), 120000);
        browser.wait(EC.invisibilityOf(this.TableContentLoad), 120000);
        browser.wait(EC.invisibilityOf(this.GridLoad), 120000);
    }

    clickElement = (elem) => {
        browser.wait(EC.presenceOf(elem), 120000);
        browser.wait(EC.visibilityOf(elem), 120000);
        browser.wait(EC.elementToBeClickable(elem), 120000);
        //this.scrollIntoView(elem);
        this.waitTillPageLoads();
        elem.click();
        this.waitTillPageLoads();
    }

    sendKeys = (elem, value) => {
        browser.wait(EC.elementToBeClickable(elem), 120000);
        this.waitTillPageLoads();
        elem.clear();
        elem.sendKeys(value);
        this.waitTillPageLoads();
    }

    dragAndDrop = (elem) => {
        this.waitTillPageLoads();
        browser.executeScript(JS_HTML5_DND, elem.getWebElement(), this.TargetWindow.getWebElement());
        this.waitTillPageLoads();
    }

    scrollIntoView = (elem) => {
        browser.executeScript('arguments[0].scrollIntoView(true)', elem);
    }

    datePicker = (elem, date) => {
        var givenDate = +date.substring(0, 2);
        var givenMonth = date.substring(3, 6);
        var givenYear = +date.substring(7, 11);

        var previous = element(by.css("button.previous"));
        var next = element(by.css("button.next"));
        var Year = element(by.xpath("//bs-calendar-layout//button[@class='current']"));
        var SelectMonth = element(by.xpath("//bs-calendar-layout//span[contains(text(),'" + givenMonth + "')]"));
        var SelectDate = element(by.xpath("//bs-calendar-layout//td/span[not (@class='is-other-month' or @class='disabled is-other-month') and normalize-space()='" + givenDate + "']"));

        //Select Date
        this.clickElement(elem);
        this.clickElement(Year);
        this.clickSpanElement('2021');
        browser.driver.sleep(1000).then(async () => {
            console.log(await Year.getText());
            var year = +(await Year.getText());
            console.log(year);
            if (year > givenYear) {
                while (year > givenYear) {
                    this.clickElement(previous);
                    year = +(await Year.getText());
                    console.log(year);
                }
            }
            else if (year < givenYear) {
                while (year < givenYear) {
                    this.clickElement(next);
                    year = +(await Year.getText());
                    console.log(year);
                }
            }
        });
        browser.driver.sleep(500)
        this.clickElement(SelectMonth);
        browser.driver.sleep(500)
        this.clickElement(SelectDate);
    }

    enterContactNumber = (labelName, country, number) => {
        var dropdown = element(by.xpath("//label[contains(text(),'" + labelName + "')]/..//span[contains(@class,'ui-dropdown-trigger-icon')]"));
        var searchCountry = element(by.css("div>input[autocomplete='off']"));
        var selectCountry = element(by.css("li[aria-label='" + country + "']"));
        this.clickElement(dropdown);
        this.sendKeys(searchCountry, country);
        this.clickElement(selectCountry);

        var numberfield = element(by.xpath("//label[contains(text(),'" + labelName + "')]/..//input[@placeholder]"));
        this.sendKeys(numberfield, number);
    }

    selectCountryCode_table = (elem1, elem2, country) => {
        var selectCountry = element(by.css("li[aria-label='" + country + "']"));
        this.clickElement(elem1);
        this.sendKeys(elem2, country);
        this.clickElement(selectCountry);
    }

    autoCompleteDropdown = (elem, value) => {
        var search = element(by.css("input[autocomplete='off']"));
        var dropdownValue = element(by.css("li[aria-label='" + value + "'i]"));
        this.clickElement(elem);
        this.sendKeys(search, value);
        this.clickElement(dropdownValue);
    };

    autoCompleteTextBox = (elem, value) => {
        this.sendKeys(elem, value.substring(0, 4));
        var result = element(by.xpath("//span[contains(text(),'" + value + "')]"));
        this.clickElement(result);
    }

    selectDropdownValue = (elem, value) => {
        this.clickElement(elem);
        var dropdownValue = element(by.css("li[aria-label='" + value + "'i]"));
        this.clickElement(dropdownValue);
    };

    multiselectDropdown = (elem) => {
        this.clickElement(elem);
        this.clickElement(this.MultiSelectCheckbox);
        this.clickElement(elem);
    }

    selectCheckbox_Table = (fieldName) => {
        var elem = element(by.xpath("//span[normalize-space()='" + fieldName + "']/ancestor::tr//div[@role='checkbox']"));
        this.clickElement(elem);
    }

    selectCheckbox_Label = (labelName) => {
        var elem = element(by.xpath("//label[text()='" + labelName + "']/ancestor::pnk-checkbox//child::div[@role='checkbox']"));
        this.clickElement(elem);
    }

    searchAndSelectCheckbox_Table = (fieldName) => {
        var search = element(by.css("p-dialog input.global-filter"));
        this.sendKeys(search, fieldName);
        browser.driver.sleep(3000);
        this.selectCheckbox_Table(fieldName);
    }

    searchAndSelectAll_Table = (searchValue) => {
        var search = element(by.css("p-dialog input.global-filter"));
        this.sendKeys(search, searchValue);
        browser.driver.sleep(3000);
        this.clickElement(this.SelectAllCheckbox);
    }

    selectAllTheCheckboxes = () => {
        this.Checkboxes.each(async (element, index) => {
            console.log(index);
            element.click();
        });
    }

    clickSpanElement = (text_elem) => {
        var elem = element(by.xpath("//span[normalize-space()='" + text_elem + "']"));
        browser.wait(EC.elementToBeClickable(elem), 120000);
        this.clickElement(elem);
    }

    isSpanElementDispayed = (text_elem) => {
        var elem = element(by.xpath("//span[contains(text(),'" + text_elem + "')]"));
        browser.wait(EC.visibilityOf(elem), 120000);
        return elem.isDisplayed();
    }

    getAlertInfo = () => {
        browser.wait(EC.presenceOf(this.StatusAlert), 60000).then(async () => {
            expect(await this.SuccessAlert.isDisplayed()).to.be.true;
            console.log(await this.StatusAlert.getText());
        });
        browser.wait(EC.invisibilityOf(this.StatusAlert), 30000);
    }

    waitForElementVisibility = (elem) => {
        this.waitTillPageLoads();
        browser.wait(EC.visibilityOf(elem), 120000);
    }

    // expectToBeTrue = async (element, text) => {
    //     this.waitForElementVisibility(element);
    //     expect((await element.isDisplayed()).valueOf()).to.be.true;
    //     expect(await element.getText()).contains(text);
    // }
}

