import { ElementFinder, element, by, browser } from "protractor";
import { BasePage } from "../BasePage";

export class PackagesPage extends BasePage {

    CreateNewPackage_Btn: ElementFinder;
    SearchPackage: ElementFinder;
    Save_Package: ElementFinder;

    PackageName: ElementFinder;
    PackageNameAsSeenByClient: ElementFinder;
    PackageDescription: ElementFinder;
    Currency: ElementFinder;
    Charge: ElementFinder;
    EffectsFromDate: ElementFinder;
    DefaultTaxRate: ElementFinder;
    OrderingInstructions: ElementFinder;
    AddExistingServices_Btn: ElementFinder;
    Add_Btn: ElementFinder;

    AddSource_Btn: ElementFinder;
    Source: ElementFinder;
    Description_Source: ElementFinder;
    Save_Btn: ElementFinder;

    constructor() {
        super();
        this.CreateNewPackage_Btn = element(by.xpath("//button[normalize-space()='CREATE NEW PACKAGE']"));
        this.SearchPackage = element(by.css("app-package-configuration-list input.global-filter"));
        this.Save_Package = element(by.xpath("//app-package-details//button[contains(text(),'SAVE')]"));

        this.PackageName = element(by.css("[formcontrolname='packagesName'] input"));
        this.PackageNameAsSeenByClient = element(by.css("[formcontrolname='packageNameSeenByClient'] input"));
        this.PackageDescription = element(by.css("[formcontrolname='packagesDescription'] textarea"));

        this.Currency = element(by.css("[formcontrolname='currencyId'] p-dropdown"));
        this.Charge = element(by.css("[formcontrolname='charges'] input"));
        this.EffectsFromDate = element(by.xpath("//label[contains(text(),'Effect From')]/..//input"));
        this.DefaultTaxRate = element(by.css("[formcontrolname='defaultTaxRate'] input"));
        this.OrderingInstructions = element(by.css("[formcontrolname='orderingInstructions'] textarea"));

        this.AddExistingServices_Btn = element(by.xpath("//button[normalize-space()='ADD EXISTING SERVICES']"));
        this.Add_Btn = element(by.xpath("//p-dialog//button[contains(text(),'ADD')]"));

        this.AddSource_Btn = element(by.xpath("//button[contains(text(),'Add Source')]"));
        this.Source = element(by.xpath("//p-dialog//label[contains(text(),'Source')]/..//input"));
        this.Description_Source = element(by.xpath("//p-dialog//label[contains(text(),'Description')]/..//textarea"));
        this.Save_Btn = element(by.xpath("//p-dialog//button[contains(text(),'Save')]"));
    }

    clickCreatePackage = () => {
        this.clickElement(this.CreateNewPackage_Btn);
    }

    savePackage = () => {
        this.clickElement(this.Save_Package);
    }

    fillPackageDetails = (testdata) => {
        this.sendKeys(this.PackageName, testdata.PackageName);
        this.sendKeys(this.PackageNameAsSeenByClient, testdata.PackageNameAsSeenByClient);
        this.sendKeys(this.PackageDescription, testdata.PackageDescription);

        this.autoCompleteDropdown(this.Currency, testdata.Currency);
        this.sendKeys(this.Charge, testdata.Charge);
        this.datePicker(this.EffectsFromDate, testdata.EffectsFromDate);
        this.selectAllTheCheckboxes();
        this.sendKeys(this.DefaultTaxRate, testdata.DefaultTaxRate);
        this.sendKeys(this.OrderingInstructions, testdata.OrderingInstructions);
        // browser.driver.sleep(5000);
        //var entity = testdata.IsBusinessEntity;
        if(testdata.IsBusinessEntity==='NO'){
            this.selectCheckbox_Label('Is Business Entity');
        }
        this.savePackage();
    }

    addExistingServices = (testdata) => {
        this.clickElement(this.AddExistingServices_Btn);
        // browser.driver.sleep(5000);
        this.searchAndSelectCheckbox_Table(testdata.ServiceName);
        if(testdata.PackageName.includes('Field')){
            this.searchAndSelectCheckbox_Table(testdata.ServiceName2);
        }
        this.clickElement(this.Add_Btn);
        this.getAlertInfo();
    }

    addVerificationSource = (testdata) => {
        this.clickElement(this.AddSource_Btn);
        this.sendKeys(this.Source, testdata.Source);
        this.sendKeys(this.Description_Source, testdata.Description_Source);
        this.clickElement(this.Save_Btn);
        this.getAlertInfo();
    }
}