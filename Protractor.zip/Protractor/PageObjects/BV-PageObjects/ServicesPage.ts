import { browser, by, element, ElementFinder } from "protractor";
import { BasePage } from "../BasePage";

export class ServicesPage extends BasePage {

    CreateNewService_Btn: ElementFinder;
    SearchService: ElementFinder;
    Save_Service: ElementFinder;
    Save_Btn1: ElementFinder;
    Add_Btn: ElementFinder;

    ServiceDetailsTab: ElementFinder;
    ServiceName: ElementFinder;
    ServiceNameAsSeenByClient: ElementFinder;
    ServiceType: ElementFinder;
    ServiceDescription: ElementFinder;
    OrderReview: ElementFinder;
    Currency: ElementFinder;
    Charge: ElementFinder;
    EffectsFromDate: ElementFinder;
    DefaultTaxRate: ElementFinder;
    AddSource_Btn: ElementFinder;
    Source: ElementFinder;
    Description_Source: ElementFinder;

    ConfigureDataFieldsTab: ElementFinder;
    AddOrderFields_Btn: ElementFinder;
    SearchOrderFields: ElementFinder;
    AddResultFields_Btn: ElementFinder;
    SearchResultFields: ElementFinder;

    ConfigureApiTab: ElementFinder;
    AddAPI_Btn: ElementFinder;
    ServiceAPI: ElementFinder;

    RoutingTab: ElementFinder;
    AddDefaultSupplier_Btn: ElementFinder;
    Region: ElementFinder;
    DefaultSupplier: ElementFinder;
    OrderReview_DefaultSupplier: ElementFinder;
    Currency_DefaultSupplier: ElementFinder;
    Cost_DefaultSupplier: ElementFinder;
    AddRule_Btn: ElementFinder;
    RuleName: ElementFinder;
    Supplier: ElementFinder;
    Rank: ElementFinder;
    TurnaroundDays: ElementFinder;
    CutOffTime_Rule: ElementFinder;
    Currency_Rule: ElementFinder;
    Cost_Rule: ElementFinder;
    Save_Btn2: ElementFinder;
    AddCriteria_Btn: ElementFinder;
    Region_Criteria: ElementFinder;
    ParameterType: ElementFinder;
    Parameter: ElementFinder;
    Operator: ElementFinder;
    Customer: ElementFinder;
    Value: ElementFinder;
    Country: ElementFinder;

    constructor() {
        super();
        this.CreateNewService_Btn = element(by.xpath("//button[contains(text(),'CREATE NEW SERVICE')]"));
        this.SearchService = element(by.css("app-es-service-configuration-list input.global-filter"));
        this.Save_Service = element(by.xpath("//button[contains(text(),'SAVE')]"));
        this.Save_Btn1 = element(by.xpath("//p-dialog//button[contains(text(),'Save')]"));
        this.Save_Btn2 = element(by.xpath("//p-dialog//button[contains(text(),'SAVE')]"));
        this.Add_Btn = element(by.xpath("//p-dialog//button[contains(text(),'ADD')]"));

        this.ServiceDetailsTab = element(by.xpath("//li[@role='tab']//span[text()='Service Details']"));
        this.ServiceName = element(by.css("[formcontrolname='serviceName'] input"));
        this.ServiceNameAsSeenByClient = element(by.css("[formcontrolname='serviceNameAsSeenByClient'] input"));
        this.ServiceType = element(by.css("[formcontrolname='productTypeId'] p-dropdown"));
        this.ServiceDescription = element(by.css("[formcontrolname='serviceDescription'] textarea"));
        this.OrderReview = element(by.xpath("//label[contains(text(),'Order Review')]/..//p-dropdown"));
        this.Currency = element(by.xpath("//label[contains(text(),'Currency')]/..//p-dropdown"));
        this.Charge = element(by.xpath("//label[text()=' Charge ']/..//input"));
        this.EffectsFromDate = element(by.xpath("//label[contains(text(),'Effects From')]/..//input"));
        this.DefaultTaxRate = element(by.xpath("//label[contains(text(),'Default Tax Rate')]/..//input"));

        this.AddSource_Btn = element(by.xpath("//button[contains(text(),'Add Source')]"));
        this.Source = element(by.xpath("//p-dialog//label[contains(text(),'Source')]/..//input"));
        this.Description_Source = element(by.xpath("//p-dialog//label[contains(text(),'Description')]/..//textarea"));

        this.ConfigureDataFieldsTab = element(by.xpath("//li[@role='tab']//span[text()='Configure Data Fields']"));
        this.AddOrderFields_Btn = element(by.xpath("//button[contains(text(),'ADD ORDER FIELDS')]"));
        this.SearchOrderFields = element(by.css("p-dialog input.global-filter"));
        this.AddResultFields_Btn = element(by.xpath("//button[contains(text(),'ADD RESULT FIELDS')]"));
        this.SearchResultFields = element(by.css("p-dialog input.global-filter"));

        this.ConfigureApiTab = element(by.xpath("//li[@role='tab']//span[text()='Configure Api']"));
        this.AddAPI_Btn = element(by.xpath("//button[contains(text(),'Add API')]"));
        this.ServiceAPI = element(by.xpath("//label[contains(text(),'Service API')]/..//p-dropdown"));

        this.RoutingTab = element(by.xpath("//li[@role='tab']//span[text()='Routing']"));
        this.AddDefaultSupplier_Btn = element(by.xpath("//button[normalize-space()='ADD DEFAULT SUPPLIER']"));
        this.Region = element(by.xpath("//p-dialog//label[contains(text(),'Region')]/..//p-dropdown"));
        this.DefaultSupplier = element(by.xpath("//p-dialog//label[contains(text(),'Default Supplier')]/..//p-dropdown"));
        this.OrderReview_DefaultSupplier = element(by.xpath("//p-dialog//label[contains(text(),'Order Review')]/..//p-dropdown"));
        this.Currency_DefaultSupplier = element(by.xpath("//p-dialog//label[contains(text(),'Currency')]/..//p-dropdown"));
        this.Cost_DefaultSupplier = element(by.xpath("//p-dialog//label[contains(text(),'Cost')]/..//input"));
        this.AddRule_Btn = element(by.xpath("//button[normalize-space()='ADD RULE']"));
        this.RuleName = element(by.css("[formcontrolname='ruleName'] input"));
        this.Supplier = element(by.css("[formcontrolname='supplierId'] p-dropdown"));
        this.Rank = element(by.css("[formcontrolname='rank'] input"));
        this.TurnaroundDays = element(by.css("[formcontrolname='turnArondDays'] input"));
        this.CutOffTime_Rule = element(by.css("[formcontrolname='cutOfTimeId'] p-dropdown"));
        this.Currency_Rule = element(by.css("[formcontrolname='currencyId'] p-dropdown"));
        this.Cost_Rule = element(by.css("[formcontrolname='cost'] input"));
        this.AddCriteria_Btn = element(by.xpath("//button[normalize-space()='ADD CRITERIA']"));
        this.Region_Criteria = element(by.xpath("//p-dialog//label[contains(text(),'Region')]/..//p-dropdown"));
        this.ParameterType = element(by.xpath("//p-dialog//label[contains(text(),'Parameter Type')]/..//p-dropdown"));
        this.Parameter = element(by.xpath("//p-dialog//label[text()='Parameter']/..//p-dropdown"));
        this.Operator = element(by.xpath("//p-dialog//label[contains(text(),'Operator')]/..//p-dropdown"));
        this.Customer = element(by.xpath("//p-dialog//label[contains(text(),'Customer')]/..//p-dropdown"));
        this.Value = element(by.xpath("//p-dialog//label[contains(text(),'Value')]/..//p-dropdown"));
        this.Country = element(by.xpath("//p-dialog//label[contains(text(),'Country')]/..//p-dropdown"));
    }

    clickCreateService = () => {
        this.clickElement(this.CreateNewService_Btn);
    }

    saveService = () => {
        this.clickElement(this.Save_Service);
    }

    selectService = (testdata) => {
        var elem = element(by.xpath("//span[@title='" + testdata.ServiceName + "']/ancestor::tr//span[contains(text(),'S-')]"));
        // browser.driver.sleep(5000);
        this.sendKeys(this.SearchService, testdata.ServiceName);
        // browser.driver.sleep(3000);
        this.clickElement(elem);
    }

    selectCurrency = (elem, value) => {
        var search = element(by.css("input[autocomplete='off']"));
        var dropdownValue = element(by.css("li[aria-label='" + value + "'i]"));
        this.clickElement(elem);
        this.sendKeys(search, value);
        this.clickElement(dropdownValue);
    };

    fillServiceDetailsTab = (testdata) => {
        this.clickElement(this.ServiceDetailsTab);
        this.sendKeys(this.ServiceName, testdata.ServiceName);
        this.sendKeys(this.ServiceNameAsSeenByClient, testdata.ServiceNameAsSeenByClient);
        this.selectDropdownValue(this.ServiceType, testdata.ServiceType);
        this.sendKeys(this.ServiceDescription, testdata.ServiceDescription);

        this.autoCompleteDropdown(this.Currency, testdata.Currency);
        this.sendKeys(this.Charge, testdata.Charge);
        this.datePicker(this.EffectsFromDate, testdata.EffectsFromDate);
        this.selectAllTheCheckboxes();
        this.sendKeys(this.DefaultTaxRate, testdata.DefaultTaxRate);
        this.clickElement(this.Save_Service);

        //this.selectDropdownValue(this.OrderReview, testdata.OrderReview);
        this.clickElement(this.AddSource_Btn);
        this.sendKeys(this.Source, testdata.Source);
        this.sendKeys(this.Description_Source, testdata.Description_Source);
        this.clickElement(this.Save_Btn1);
        // browser.wait(EC.alertIsPresent(), 5000);
        // this.getAlertInfo();
    }

    fillConfigureDataFieldsTab = () => {
        this.clickElement(this.ConfigureDataFieldsTab);
        this.clickElement(this.AddOrderFields_Btn);
        // browser.driver.sleep(5000);
        this.searchAndSelectAll_Table('[25 Apr]');
        this.clickElement(this.Add_Btn);
        // browser.driver.sleep(3000);
        this.clickElement(this.AddResultFields_Btn);
        // browser.driver.sleep(5000);
        this.searchAndSelectAll_Table('[25 Apr]');
        this.clickElement(this.Add_Btn);

    }

    fillConfigureAPITab = () => {
        this.clickElement(this.ConfigureApiTab);
        this.clickElement(this.AddAPI_Btn);
        this.selectDropdownValue(this.ServiceAPI, 'Securitec');
        this.clickElement(this.Save_Btn2);
        this.getAlertInfo();
        this.clickElement(this.AddAPI_Btn);
        this.selectDropdownValue(this.ServiceAPI, 'ISB');
        this.clickElement(this.Save_Btn2);
        this.getAlertInfo();
    }

    fillRoutingTab = (testdata) => {
        this.clickElement(this.RoutingTab);
        this.clickElement(this.AddDefaultSupplier_Btn);
        this.selectDropdownValue(this.Region, testdata.Region);
        this.selectDropdownValue(this.DefaultSupplier, testdata.DefaultSupplier);
        this.selectDropdownValue(this.OrderReview_DefaultSupplier, testdata.OrderReview_DefaultSupplier);
        this.selectCurrency(this.Currency_DefaultSupplier, testdata.Currency_DefaultSupplier);
        this.sendKeys(this.Cost_DefaultSupplier, testdata.Cost_DefaultSupplier);
        this.clickElement(this.Save_Btn1);
        this.getAlertInfo();
    }

    addRule = (testdata) => {
        this.clickElement(this.AddRule_Btn);
        this.sendKeys(this.RuleName, testdata.RuleName);
        this.selectDropdownValue(this.Supplier, testdata.Supplier);
        this.sendKeys(this.Rank, testdata.Rank);
        this.saveService();
        browser.driver.sleep(3000);

        this.clickElement(this.AddCriteria_Btn);
        this.selectDropdownValue(this.Region_Criteria, testdata.Region_Criteria);
        this.selectDropdownValue(this.ParameterType, testdata.ParameterType);
        // browser.driver.sleep(2000);
        // this.selectDropdownValue(this.Parameter, testdata.Parameter);
        this.selectDropdownValue(this.Operator, testdata.Operator);
        this.autoCompleteDropdown(this.Country, testdata.Country);
        this.clickElement(this.Save_Btn2);
        // browser.driver.sleep(2000);
        this.saveService();
        this.getAlertInfo();
        this.clickSpanElement('Routing');
    }
}