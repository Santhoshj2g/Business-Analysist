import { ElementFinder, element, by, browser, ExpectedConditions as EC } from "protractor";
import { BasePage } from "../BasePage";

export class DashboardPage_BV_Admin extends BasePage {

    Users: ElementFinder;
    Supplier: ElementFinder;
    Services: ElementFinder;
    Packages: ElementFinder;
    Clients: ElementFinder;

    UpdateStatus_Btn: ElementFinder;
    ChangeStatus: ElementFinder;
    StatusComments: ElementFinder;
    SaveStatus: ElementFinder;
    Status: ElementFinder;

    constructor() {
        super();
        this.Users = element(by.css("[viewallurl='user'] a"));
        this.Supplier = element(by.css("[viewallurl='supplier'] a"));
        this.Services = element(by.css("[viewallurl='service'] a"));
        this.Packages = element(by.css("[viewallurl='package'] a"));
        this.Clients = element(by.css("[viewallurl='client'] a"));

        this.UpdateStatus_Btn = element(by.xpath("//button[contains(text(),'UPDATE STATUS')]"));
        this.ChangeStatus = element(by.xpath("//label[contains(text(),'Change Status To')]/..//p-dropdown"));
        this.StatusComments = element(by.css("p-dialog [formcontrolname='comments'] textarea"));
        this.SaveStatus = element(by.xpath("//p-dialog//button[contains(text(),'SAVE')]"));
        this.Status = element(by.css("pnk-breadcrumb>span>.statusLabel"));
    }

    clickUsers = () => {
        this.clickElement(this.Users);
    }

    clickSupplier = () => {
        this.clickElement(this.Supplier);
    }

    clickServices = () => {
        this.clickElement(this.Services);
    }

    clickPackages = () => {
        this.clickElement(this.Packages);
    }

    clickClients = () => {
        this.clickElement(this.Clients);
    }

    navigateToDashboard = (Url) => {
        browser.get(Url);
    }

    updateStatus = () => {
        this.clickElement(this.UpdateStatus_Btn);
        this.selectDropdownValue(this.ChangeStatus, 'ACTIVE');
        this.sendKeys(this.StatusComments, 'NA');
        this.clickElement(this.SaveStatus);
    }
}