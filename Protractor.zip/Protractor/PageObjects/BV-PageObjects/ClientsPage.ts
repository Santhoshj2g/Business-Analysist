import { browser, by, element, ElementArrayFinder, ElementFinder } from "protractor";
import { BasePage } from "../BasePage";

export class ClientsPage extends BasePage {

    SaveAll_Btn: ElementFinder;
    Save_Btn: ElementFinder;
    Add_Btn: ElementFinder;

    ConfigureNewClient_Btn: ElementFinder;
    RequestingRegion: ElementFinder;
    RequestingOffice: ElementFinder;
    Client: ElementFinder;
    Configure_Btn: ElementFinder;

    ClientDetailsTab: ElementFinder;
    USRNumber: ElementFinder;
    Address1: ElementFinder;
    Address2: ElementFinder;
    Country: ElementFinder;
    StateProvince: ElementFinder;
    City: ElementFinder;
    PostalCode: ElementFinder;
    TimeZone: ElementFinder;
    Locale: ElementFinder;
    AddContact_Btn: ElementFinder;
    FirstName: ElementFinder;
    LastName: ElementFinder;
    EmailID: ElementFinder;
    Extension: ElementFinder;
    ContactTitle: ElementFinder;
    ContactType: ElementFinder;

    LocationDetailsTab: ElementFinder;
    LocationName: ElementFinder;
    Description: ElementFinder;
    CreateNew_Btn: ElementFinder;
    AddDept_Btn: ElementFinder;
    DeptName: ElementFinder;
    DeptDesc: ElementFinder;
    AddPosition_Btn: ElementFinder;
    PositionName: ElementFinder;
    PositionDesc: ElementFinder;

    PackagesTab: ElementFinder;
    AddExistingPackages_Btn: ElementFinder;

    ConfigureBusinessTypeTab: ElementFinder;
    AddBusinessType_Btn: ElementFinder;
    BusinessType: ElementFinder;
    BusinessEntityPackages: ElementFinder;
    BusinessOwnerPackages: ElementFinder;
    WelcomeForm: ElementFinder;
    Title: ElementFinder;
    Body: ElementFinder;
    AddSection_Btn: ElementFinder;
    SectionName: ElementFinder;
    SaveSectionName: ElementFinder;
    SelectIntakeFields_Btn: ElementFinder;
    EditIntakeField: ElementArrayFinder;

    SaveSection: ElementFinder;
    DocumentType: ElementFinder;
    DocumentInstruction: ElementFinder;
    MaxFileSize: ElementFinder;
    ExtensionsAllowed: ElementFinder;
    InviteProfileForm: ElementFinder;
    OrderDetailsForm_Business: ElementFinder;
    Disclosure_Business: ElementFinder;
    Forms: ElementFinder;
    Header: ElementFinder;
    Footer: ElementFinder;
    BasicDetails_BO: ElementFinder;
    OrderDetails_BO: ElementFinder;
    Disclosure_BO: ElementFinder;
    AddPIIForm_Btn: ElementFinder;
    ProfilePackages: ElementFinder;
    BasicDetails_FW: ElementFinder;
    OrderDetails_FW: ElementFinder;
    Disclosure_FW: ElementFinder;

    Radio_Btn: ElementArrayFinder;
    Rule: ElementFinder;
    AddVerificationSource_Btn: ElementFinder;
    Source: ElementFinder;
    SourceDescription: ElementFinder;

    constructor() {
        super();
        this.SaveAll_Btn = element(by.xpath("//button[contains(text(),'SAVE')]"));
        this.Save_Btn = element(by.xpath("//p-dialog//button[contains(text(),'Save')]"));
        this.Add_Btn = element(by.xpath("//p-dialog//button[contains(text(),'ADD')]"));

        //ConfigureClient
        this.ConfigureNewClient_Btn = element(by.xpath("//button[contains(text(),'CONFIGURE NEW CLIENT')]"));
        this.RequestingRegion = element(by.css("[formcontrolname='requestingRegionId'] p-dropdown"));
        this.RequestingOffice = element(by.css("[formcontrolname='requestingOfficeId'] p-dropdown"));
        this.Client = element(by.css("[formcontrolname='clientDetails'] p-dropdown"));
        this.Configure_Btn = element(by.xpath("//button[normalize-space()='CONFIGURE']"));

        //ClientDetails-Tab
        this.ClientDetailsTab = element(by.xpath("//li[@role='tab']//span[text()='Client Details']"));
        this.USRNumber = element(by.css("[formcontrolname='usrDetails'] p-multiselect"));

        this.Address1 = element(by.css("[formcontrolname='streetAddress1'] input"));
        this.Address2 = element(by.css("[formcontrolname='streetAddress2'] input"));
        this.Country = element(by.css("[formcontrolname='country'] p-dropdown"));
        this.StateProvince = element(by.css("[formcontrolname='state'] p-dropdown"));
        this.City = element(by.css("[formcontrolname='city'] input"));
        this.PostalCode = element(by.css("[formcontrolname='postalCode'] input"));
        this.TimeZone = element(by.css("[formcontrolname='timeZoneId'] p-dropdown"));
        this.Locale = element(by.css("[formcontrolname='localeId'] p-dropdown"));

        this.AddContact_Btn = element(by.xpath("//button[contains(text(),'Add Contact')]"));
        this.FirstName = element(by.xpath("//label[contains(text(),'First Name')]/..//input"));
        this.LastName = element(by.xpath("//label[contains(text(),'Last Name')]/..//input"));
        this.EmailID = element(by.xpath("//label[contains(text(),'Email ID')]/..//input"));
        this.Extension = element(by.xpath("//label[contains(text(),'Extension')]/..//input"));
        this.ContactTitle = element(by.xpath("//label[contains(text(),'Contact Title')]/..//input"));
        this.ContactType = element(by.xpath("//label[contains(text(),'Contact Type')]/..//p-multiselect"));

        //LocationDetails-Tab
        this.LocationDetailsTab = element(by.xpath("//li[@role='tab']//span[text()='Location Details']"));
        this.LocationName = element(by.css("[formcontrolname='locationName'] input"));
        this.Description = element(by.css("[formcontrolname='description'] input"));
        this.CreateNew_Btn = element(by.xpath("//button[contains(text(),'CREATE NEW')]"));
        this.AddDept_Btn = element(by.xpath("//button[contains(text(),'Add Department')]"));
        this.DeptName = element(by.xpath("//label[contains(text(),'Department Name')]/..//input"));
        this.DeptDesc = element(by.xpath("//label[contains(text(),'Description')]/..//textarea"));
        this.AddPosition_Btn = element(by.xpath("//button[contains(text(),'Add Position')]"));
        this.PositionName = element(by.xpath("//label[contains(text(),'Position Name')]/..//input"));
        this.PositionDesc = element(by.xpath("//label[contains(text(),'Description')]/..//textarea"));

        //===> PackagesAndServices-Tab
        this.PackagesTab = element(by.xpath("//li[@role='tab']//span[text()='Packages']"));
        this.AddExistingPackages_Btn = element(by.xpath("//button[contains(text(),'Add Existing packages')]"));

        //===> ConfigureBusinessType-Tab
        this.ConfigureBusinessTypeTab = element(by.xpath("//li[@role='tab']//span[text()='Configure Business Type']"));
        this.AddBusinessType_Btn = element(by.xpath("//button[contains(text(),'Add Business Type')]"));
        this.BusinessType = element(by.xpath("//label[contains(text(),'Business Type')]/..//input"));
        this.BusinessEntityPackages = element(by.xpath("//label[contains(text(),'Business Entity Packages')]/..//p-dropdown"));
        this.BusinessOwnerPackages = element(by.xpath("//label[contains(text(),'Business Owner Packages')]/..//p-dropdown"));
        this.WelcomeForm = element(by.xpath("//app-business-type//span[normalize-space()='Welcome']"));
        this.Title = element(by.css("[formcontrolname='title'] input"));
        this.Body = element(by.css("html body[contenteditable='true']"));

        this.AddSection_Btn = element(by.xpath("//button[contains(text(),'ADD SECTION')]"));
        this.SectionName = element(by.css("[formcontrolname='newSectionName'] input"));
        this.SaveSectionName = element(by.xpath("//p-dialog//button[contains(text(),'SAVE')]"));
        this.SelectIntakeFields_Btn = element(by.xpath("//button[contains(text(),'SELECT INTAKE FIELDS')]"));
        this.EditIntakeField = element.all(by.xpath("//tr//td//button[@title='Edit']"));
        this.SaveSection = element(by.css("Span.save-icon"));

        this.DocumentType = element(by.css("[formcontrolname='documentType'] input"));
        this.DocumentInstruction = element(by.css("[formcontrolname='documentInstruction'] input"));
        this.MaxFileSize = element(by.css("[formcontrolname='maxFileSize'] input"));
        this.ExtensionsAllowed = element(by.css("[formcontrolname='documentExtensions'] p-multiselect"));

        this.InviteProfileForm = element(by.xpath("//span[normalize-space()='Invite profiles']"));

        this.OrderDetailsForm_Business = element(by.xpath("//pnk-grid[@formcontrolname='bvBusinessTypeRegistrationFormsRequest']//span[normalize-space()='Order Details']"));

        this.Disclosure_Business = element(by.xpath("//pnk-grid[@formcontrolname='bvBusinessTypeRegistrationFormsRequest']//span[normalize-space()='Disclosure']"));
        this.Forms = element(by.css("[formcontrolname='clientOtherTemplateId'] p-dropdown"));
        // this.Header = element(by.xpath("//div[@class='note-placeholder'][1]"));
        // this.Footer = element(by.xpath("//div[@class='note-placeholder'][2]"));

        this.BasicDetails_BO = element(by.xpath("/html/body/app-root/div/pnk-content/div/app-business-type/div[2]/form/div[3]/div[2]/pnk-grid/div/p-table/div/div[2]/div/div[2]/table/tbody/tr[1]/td[2]/p-celleditor/span/span"));
        this.OrderDetails_BO = element(by.xpath("/html/body/app-root/div/pnk-content/div/app-business-type/div[2]/form/div[3]/div[2]/pnk-grid/div/p-table/div/div[2]/div/div[2]/table/tbody/tr[4]/td[2]/p-celleditor/span/span"));
        this.Disclosure_BO = element(by.xpath("/html/body/app-root/div/pnk-content/div/app-business-type/div[2]/form/div[3]/div[2]/pnk-grid/div/p-table/div/div[2]/div/div[2]/table/tbody/tr[5]/td[2]/p-celleditor/span/span"));

        this.AddPIIForm_Btn = element(by.xpath("//button[contains(text(),'Add PII Form')]"));
        this.ProfilePackages = element(by.xpath("//label[text()='Profile Packages']/../p-dropdown"));
        this.BasicDetails_FW = element(by.xpath("//*[contains(@id,'ui-accordiontab')]//span[contains(text(),'Basic Details')]"));
        this.OrderDetails_FW = element(by.xpath("//*[contains(@id,'ui-accordiontab')]//span[contains(text(),'Order Details')]"));
        this.Disclosure_FW = element(by.xpath("//*[contains(@id,'ui-accordiontab')]//span[contains(text(),'Disclosure')]"));

        this.Rule = element(by.css("[formcontrolname='rules'] textarea"));
        this.AddVerificationSource_Btn = element(by.xpath("//button[contains(text(),'Add Source')]"));
        this.Source = element(by.xpath("//label[contains(text(),'Source')]/..//input"));
        this.SourceDescription = element(by.xpath("//label[contains(text(),'Description')]/..//textarea"));
    }

    selectClient = (testdata) => {
        // browser.driver.sleep(5000);
        this.sendKeys(this.Search, testdata.ClientName);
        // browser.driver.sleep(2000);
        this.clickSpanElement(testdata.ClientName);
    }

    selectLocationCode = (location) => {
        var elem = element(by.xpath("//span[contains(text(),'" + location + "')]/ancestor::tr//td[contains(@class,'pinkerton-link-text')]//span"));
        this.clickElement(elem);
    }

    selectBusinessType = (testdata) => {
        var elem = element(by.xpath("//span[text()='" + testdata + "']/ancestor::tr//button[@title='Edit']"));
        this.clickElement(elem);
    }

    editSection = (testdata) => {
        var elem = element(by.xpath("//span[normalize-space()='" + testdata + "']/../span[contains(@class,'edit-icon')]"));
        this.clickElement(elem);
    }

    saveAll = () => {
        this.clickElement(this.SaveAll_Btn);
    }

    // selectAdjudicationService = (testdata) => {
    //     this.EditIntakeField.each(function (element1, index1) {
    //         console.log(index1);
    //         element1.click();
    //         var RadioBtn_IntakeField: ElementArrayFinder;
    //         RadioBtn_IntakeField = element.all(by.xpath("//p-radiobutton//label[text()='Yes']"));
    //             console.log(index2);
    //             element2.click();
    //         });
    //         var dropdownValue = element(by.css("li[aria-label='" + testdata + "'i]"));
    //         dropdownValue.click();
    //     });
    // }

    selectAllTheRadioButtons = (fieldName) => {
        this.Radio_Btn = element.all(by.xpath("//span[text()='" + fieldName + "']/ancestor::tr//p-radiobutton//label[text()='Yes']"));
        this.Radio_Btn.each(async (element, index) => {
            console.log(index);
            element.click();
        });
    }

    selectAdjudicationService = (fieldName, ServiceName) => {
        this.clickElement(this.SelectIntakeFields_Btn);
        this.searchAndSelectCheckbox_Table(fieldName);
        this.clickElement(this.Save_Btn);
        // this.getAlertInfo();
        var Edit_Btn = element(by.xpath("//span[text()='" + fieldName + "']/ancestor::tr//button[@title='Edit']"));
        this.clickElement(Edit_Btn);
        this.selectAllTheRadioButtons(fieldName);
        var RelatedService = element(by.xpath("//span[text()='" + fieldName + "']/ancestor::tr//span[text()='Select']"));
        browser.driver.sleep(1000);
        this.selectDropdownValue(RelatedService, ServiceName);
        var SaveIntake = element(by.xpath("//span[text()='" + fieldName + "']/ancestor::tr//button[@title='Save']"));
        this.clickElement(SaveIntake);
        // this.getAlertInfo();
    }

    configureNewClient = (testdata) => {
        this.clickElement(this.ConfigureNewClient_Btn);
        this.selectDropdownValue(this.RequestingRegion, testdata.RequestingRegion);
        this.selectDropdownValue(this.RequestingOffice, testdata.RequestingOffice);
        this.selectDropdownValue(this.Client, testdata.Client);
        this.selectCheckbox_Table(testdata.USRNumber);
        this.clickElement(this.Configure_Btn);
        this.getAlertInfo();
        this.clickSpanElement(testdata.Client);
    }

    fillClientDetailsTab = (testdata) => {
        this.clickElement(this.ClientDetailsTab);
        //this.autoCompleteDropdown(this.USRNumber, testdata.USRNumber);
        this.sendKeys(this.Address1, testdata.Address1);
        this.sendKeys(this.Address2, testdata.Address2);
        this.autoCompleteDropdown(this.Country, testdata.Country);
        this.selectDropdownValue(this.StateProvince, testdata.StateProvince);
        this.sendKeys(this.City, testdata.City);
        this.sendKeys(this.PostalCode, testdata.PostalCode);
        this.autoCompleteDropdown(this.TimeZone, testdata.TimeZone);
        this.selectDropdownValue(this.Locale, testdata.Locale);
        this.saveAll();
        this.getAlertInfo();

        this.clickElement(this.AddContact_Btn);
        this.sendKeys(this.FirstName, testdata.FirstName);
        this.sendKeys(this.LastName, testdata.LastName);
        this.sendKeys(this.EmailID, testdata.EmailID);
        this.enterContactNumber('Mobile Number', testdata.Country, testdata.MobileNumber);
        this.enterContactNumber('Landline Number', testdata.Country, testdata.LandlineNumber);
        this.enterContactNumber('Fax Number', testdata.Country, testdata.FaxNumber);
        this.sendKeys(this.Extension, testdata.Extension);
        this.sendKeys(this.ContactTitle, testdata.ContactTitle);
        this.multiselectDropdown(this.ContactType);
        this.clickElement(this.Save_Btn);
        this.getAlertInfo();
    }

    fillLocationDetailsTab = (testdata) => {
        this.clickElement(this.LocationDetailsTab);
        this.sendKeys(this.LocationName, testdata.LocationName);
        this.sendKeys(this.Description, testdata.Description);
        this.clickElement(this.CreateNew_Btn);
        this.getAlertInfo();
        this.sendKeys(this.Search, testdata.LocationName);
        this.selectLocationCode(testdata.LocationName);

        //this.clickElement(this.LocationDetailsTab);
        this.sendKeys(this.Address1, testdata.Address1);
        this.sendKeys(this.Address2, testdata.Address2);
        this.sendKeys(this.PostalCode, testdata.PostalCode);
        // this.sendKeys(this.City, testdata.City);
        // this.autoCompleteDropdown(this.Country, testdata.Country);
        // this.autoCompleteDropdown(this.StateProvince, testdata.StateProvince);
        this.autoCompleteDropdown(this.TimeZone, testdata.TimeZone);
        this.selectDropdownValue(this.Locale, testdata.Locale);

        this.clickElement(this.AddContact_Btn);
        this.sendKeys(this.FirstName, testdata.FirstName);
        this.sendKeys(this.LastName, testdata.LastName);
        this.sendKeys(this.EmailID, testdata.EmailID);
        this.enterContactNumber('Mobile Number', testdata.Country, testdata.MobileNumber);
        this.enterContactNumber('Addition Number', testdata.Country, testdata.AdditionalNumber);
        this.enterContactNumber('Fax Number', testdata.Country, testdata.FaxNumber);
        this.sendKeys(this.Extension, testdata.Extension);
        this.sendKeys(this.ContactTitle, testdata.ContactTitle);
        this.multiselectDropdown(this.ContactType);
        this.clickElement(this.Save_Btn);
        this.getAlertInfo();

        this.clickElement(this.AddDept_Btn);
        this.sendKeys(this.DeptName, testdata.DeptName);
        this.sendKeys(this.DeptDesc, testdata.DeptDesc);
        this.clickElement(this.Save_Btn);
        this.getAlertInfo();

        this.clickElement(this.AddPosition_Btn);
        this.sendKeys(this.PositionName, testdata.PositionName);
        this.sendKeys(this.PositionDesc, testdata.PositionDesc);
        this.clickElement(this.Save_Btn);
        this.getAlertInfo();

        this.saveAll();
        this.getAlertInfo();
    }

    fillPackagesTab = (testdata) => {
        this.clickElement(this.PackagesTab);
        this.clickElement(this.AddExistingPackages_Btn);
        browser.driver.sleep(5000);
        this.searchAndSelectAll_Table(testdata.Package);
        this.clickElement(this.Add_Btn);
        this.getAlertInfo();
    }

    fillBusinessTypeConfig = (testdata) => {
        this.clickElement(this.ConfigureBusinessTypeTab);
        this.clickElement(this.AddBusinessType_Btn);
        this.sendKeys(this.BusinessType, testdata.BusinessType);
        this.selectDropdownValue(this.BusinessEntityPackages, testdata.BusinessEntityPackages);
        this.selectDropdownValue(this.BusinessOwnerPackages, testdata.BusinessOwnerPackages);
        this.clickElement(this.SaveAll_Btn);
        this.getAlertInfo();

        browser.driver.sleep(3000);
        this.clickElement(this.WelcomeForm);
        this.sendKeys(this.Title, 'Welcome');
        // this.sendKeys(this.Body, 'Welcome');
        this.clickElement(this.SaveAll_Btn);
        this.getAlertInfo();
        this.clickElement(this.BackButton);

        this.clickSpanElement('Basic Business Entity');
        browser.driver.sleep(5000);
        this.clickSpanElement('Basic Business Information');
        this.editSection('Basic Business Information');
        // this.sendKeys(this.Body, 'Basic Business Information');
        this.selectAdjudicationService('First Name [25 Apr]', testdata.BE);
        this.selectAdjudicationService('Last Name [25 Apr]', testdata.BE);
        this.selectAdjudicationService('Business Region [25 Apr]', testdata.BE);
        this.selectAdjudicationService('Business Level [25 Apr]', testdata.BE);
        this.clickElement(this.SaveSection);
        this.getAlertInfo();
        this.clickSpanElement('Authorized Representative Information');
        this.editSection('Authorized Representative Information');
        this.selectAdjudicationService('SSN [25 Apr]', testdata.BE);
        this.clickElement(this.SaveSection);
        this.getAlertInfo();
        this.sendKeys(this.DocumentType, 'BE Docs');
        this.sendKeys(this.DocumentInstruction, 'BE Docs');
        this.sendKeys(this.MaxFileSize, '1000');
        this.multiselectDropdown(this.ExtensionsAllowed);
        this.selectCheckbox_Label('Include document details');
        this.clickElement(this.SaveAll_Btn);
        this.getAlertInfo();
        this.clickElement(this.BackButton);
        
        this.clickSpanElement('Invite profiles');
        browser.driver.sleep(500);
        this.sendKeys(this.Title, 'Invite Profiles');
        // this.sendKeys(this.Body, 'Invite Profiles');
        this.selectAllTheCheckboxes();
        this.clickElement(this.SaveAll_Btn);
        this.getAlertInfo();
        this.clickElement(this.BackButton);

        this.clickElement(this.OrderDetailsForm_Business);
        browser.driver.sleep(500);
        this.clickElement(this.AddSection_Btn);
        this.sendKeys(this.SectionName, 'Comprehensive Business Search');
        this.clickElement(this.SaveSectionName);
        this.getAlertInfo();
        this.clickSpanElement('Comprehensive Business Search');
        this.editSection('Comprehensive Business Search');
        this.selectAdjudicationService('Business Name [25 Apr]', testdata.BE);
        this.selectAdjudicationService('Business Start Date [25 Apr]', testdata.BE);
        this.selectAdjudicationService('Business Type [25 Apr]', testdata.BE);
        this.clickElement(this.SaveSection);
        this.getAlertInfo();
        this.sendKeys(this.DocumentType, 'Comprehensive Business Search Docs');
        this.sendKeys(this.DocumentInstruction, 'Comprehensive Business Search Docs');
        this.sendKeys(this.MaxFileSize, '1000');
        this.multiselectDropdown(this.ExtensionsAllowed);
        this.selectCheckbox_Label('Include document details');
        this.clickElement(this.SaveAll_Btn);
        this.getAlertInfo();
        this.clickElement(this.BackButton);

        this.clickElement(this.Disclosure_Business);
        browser.driver.sleep(500);
        this.sendKeys(this.Title, 'Federal Disclosure');
        this.selectDropdownValue(this.Forms, 'Federal Disclosure - India');
        this.clickElement(this.SaveAll_Btn);
        this.getAlertInfo();
        this.clickElement(this.BackButton);

        this.clickElement(this.BasicDetails_BO);
        // this.sendKeys(this.Body, 'Basic Details - Business Owner');
        this.selectAdjudicationService('First Name_Profile [25 Apr]', testdata.BO);
        this.selectAdjudicationService('Last Name_Profile [25 Apr]', testdata.BO);
        this.selectAdjudicationService('Age_Profile [25 Apr]', testdata.BO);
        this.sendKeys(this.DocumentType, 'BO Docs');
        this.sendKeys(this.DocumentInstruction, 'BO Docs');
        this.sendKeys(this.MaxFileSize, '1000');
        this.multiselectDropdown(this.ExtensionsAllowed);
        this.selectCheckbox_Label('Include document details');
        this.clickElement(this.SaveAll_Btn);
        this.getAlertInfo();
        this.clickElement(this.BackButton);

        this.clickElement(this.OrderDetails_BO);
        this.clickElement(this.AddSection_Btn);
        this.sendKeys(this.SectionName, 'Criminal Verification');
        this.clickElement(this.SaveSectionName);
        this.getAlertInfo();
        this.clickSpanElement('Criminal Verification');
        this.editSection('Criminal Verification');
        this.selectAdjudicationService('First Name_Profile [25 Apr]', testdata.BO);
        this.selectAdjudicationService('Last Name_Profile [25 Apr]', testdata.BO);
        this.selectAdjudicationService('DOB_Profile [25 Apr]', testdata.BO);
        this.selectAdjudicationService('SSN_Profile [25 Apr]', testdata.BO);
        this.clickElement(this.SaveSection);
        this.getAlertInfo();
        this.sendKeys(this.DocumentType, 'Criminal Verification Docs');
        this.sendKeys(this.DocumentInstruction, 'Criminal Verification Docs');
        this.sendKeys(this.MaxFileSize, '1000');
        this.multiselectDropdown(this.ExtensionsAllowed);
        this.selectCheckbox_Label('Include document details');
        this.clickElement(this.SaveAll_Btn);
        this.getAlertInfo();
        this.clickElement(this.BackButton);

        this.clickElement(this.Disclosure_BO);
        browser.driver.sleep(500);
        this.sendKeys(this.Title, 'State Disclosure - TN, AP');
        this.selectDropdownValue(this.Forms, 'State Disclosure - TN, AP');
        this.clickElement(this.SaveAll_Btn);
        this.getAlertInfo();
        this.clickElement(this.BackButton);

        this.clickElement(this.AddPIIForm_Btn);
        browser.driver.sleep(500);
        this.clickSpanElement('Individual Form 1');
        this.editSection('Individual Form 1');
        this.selectDropdownValue(this.ProfilePackages, testdata.FieldWorkerPackages);
        this.clickElement(this.SaveSection);
        this.getAlertInfo();
        this.clickSpanElement('Individual Form 1');
        this.editSection('Individual Form 1');
        
        this.clickElement(this.BasicDetails_FW);
        // this.sendKeys(this.Body, 'Basic Details - Field Worker');
        this.selectAdjudicationService('First Name_Profile [25 Apr]', testdata.FW);
        this.selectAdjudicationService('Last Name_Profile [25 Apr]', testdata.FW);
        this.selectAdjudicationService('Age_Profile [25 Apr]', testdata.FW);
        this.sendKeys(this.DocumentType, 'FW Docs');
        this.sendKeys(this.DocumentInstruction, 'FW Docs');
        this.sendKeys(this.MaxFileSize, '1000');
        this.multiselectDropdown(this.ExtensionsAllowed);
        this.selectCheckbox_Label('Include document details');
        this.clickElement(this.SaveAll_Btn);
        this.getAlertInfo();
        this.clickElement(this.BackButton);

        this.clickSpanElement('Individual Form 1');
        this.clickElement(this.OrderDetails_FW);
        this.clickElement(this.AddSection_Btn);
        this.sendKeys(this.SectionName, 'Employee Verification');
        this.clickElement(this.SaveSectionName);
        this.getAlertInfo();
        this.clickSpanElement('Employee Verification');
        this.editSection('Employee Verification');
        this.selectAdjudicationService('First Name_Profile [25 Apr]', testdata.FW);
        this.selectAdjudicationService('Last Name_Profile [25 Apr]', testdata.FW);
        this.selectAdjudicationService('Gender_Profile [25 Apr]', testdata.FW);
        this.selectAdjudicationService('LastCompanyName_Profile [25 Apr]', testdata.FW);
        this.selectAdjudicationService('SSN_Profile [25 Apr]', testdata.FW);
        this.clickElement(this.SaveSection);
        this.getAlertInfo();

        this.clickElement(this.AddSection_Btn);
        this.sendKeys(this.SectionName, 'Current Employer Information');
        this.clickElement(this.SaveSectionName);
        this.getAlertInfo();
        this.clickSpanElement('Current Employer Information');
        this.editSection('Current Employer Information');
        this.selectAdjudicationService('First Name_Profile [25 Apr]', testdata.FW1);
        this.selectAdjudicationService('Last Name_Profile [25 Apr]', testdata.FW1);
        this.selectAdjudicationService('Employer Name_Profile [25 Apr]', testdata.FW1);
        this.selectAdjudicationService('Company Location_Profile [25 Apr]', testdata.FW1);
        this.clickElement(this.SaveSection);
        this.getAlertInfo();

        this.sendKeys(this.DocumentType, 'Employee Verification Docs');
        this.sendKeys(this.DocumentInstruction, 'Employee Verification Docs');
        this.sendKeys(this.MaxFileSize, '1000');
        this.multiselectDropdown(this.ExtensionsAllowed);
        this.selectCheckbox_Label('Include document details');
        this.clickElement(this.SaveAll_Btn);
        this.getAlertInfo();
        this.clickElement(this.BackButton);

        this.clickSpanElement('Individual Form 1');
        this.clickElement(this.Disclosure_FW);
        browser.driver.sleep(500);
        this.sendKeys(this.Title, 'State Disclosure - TN, AP');
        this.selectDropdownValue(this.Forms, 'State Disclosure - TN, AP');
        this.clickElement(this.SaveAll_Btn);
        this.getAlertInfo();
        this.clickElement(this.BackButton);

        this.sendKeys(this.Rule, 'No Rule');
        this.clickElement(this.AddVerificationSource_Btn);
        this.sendKeys(this.Source, 'Pinkerton');
        this.sendKeys(this.SourceDescription, 'https://pinkerton.com/');
        this.clickElement(this.Save_Btn);
        this.getAlertInfo();
        this.clickElement(this.SaveAll_Btn);
        this.getAlertInfo();
    }
}