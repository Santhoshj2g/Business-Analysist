import { ElementFinder, element, by } from "protractor";
import { BasePage } from "./BasePage";

export class LoginPage extends BasePage {

    Username: ElementFinder;
    SignInUsername: ElementFinder;
    Password: ElementFinder;
    SignInPassword: ElementFinder;

    constructor() {
        super();
        this.Username = element(by.css("input[formcontrolname='username']"));
        this.SignInUsername = element(by.css("button[class='btn btn-primary']"));
        this.Password = element(by.css("#i0118"));
        this.SignInPassword = element(by.css("#idSIButton9"));
    }

    loginUser = (data) => {
        this.sendKeys(this.Username, data.LoginCredentials.Username);
        this.clickElement(this.SignInUsername);
        this.sendKeys(this.Password, data.LoginCredentials.Password)
        this.clickElement(this.SignInPassword);
        this.clickElement(this.SignInPassword);
    }
}