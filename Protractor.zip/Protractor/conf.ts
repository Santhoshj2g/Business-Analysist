import { browser, Config } from "protractor";
var HtmlReporter = require('protractor-beautiful-reporter');

export let config: Config = {

  capabilities: {
    directConnect: true,
    browserName: 'chrome',
    chromeOptions: {
      args: ["--incognito"]
    }
  },

  // SELENIUM_PROMISE_MANAGER: false,
  // beforeLaunch: function () {
  //   require('ts-node').register({
  //     project: '.'
  //   });
  // },

  specs: [
                                                                  // BV  //

    './TestCases/TC_Login.js',
    './TestCases/TC_Dashboard.js',
    './TestCases/BV-TestCases/TC_Dashboard_BV_Admin.js',
    './TestCases/BV-TestCases/TC_CreateNewService.js', 
    './TestCases/BV-TestCases/TC_CreateNewPackage.js',
    './TestCases/BV-TestCases/TC_CreateNewSupplier.js',
    './TestCases/BV-TestCases/TC_ServiceRouting.js',
    './TestCases/BV-TestCases/TC_ClientConfiguration.js',               

                                                                  // DD  //

    // './TestCases/TC_Login.js',
    // './TestCases/TC_Dashboard.js',
    // './TestCases/DD-TestCases/TC_Dashboard_DD.js',
    // './TestCases/DD-TestCases/TC_CreateNewService.js',
    // './TestCases/DD-TestCases/TC_CreateNewPackage.js',
    // './TestCases/DD-TestCases/TC_CreateUSR.js',
    // './TestCases/DD-TestCases/TC_ViewRequest.js',
    // './TestCases/DD-TestCases/TC_EditRequest.js',

                                                                  // PES //  

    // './TestCases/TC_Login.js',
    //  './TestCases/TC_Dashboard.js',
    // './TestCases/PES-TestCases/TC_Dashboard_PES.js',
    // './TestCases/PES-TestCases/TC_CreateNewUser.js',
    // './TestCases/PES-TestCases/TC_CreateNewSupplier.js',
    // './TestCases/PES-TestCases/TC_CreateNewService.js',
    // './TestCases/PES-TestCases/TC_CreateNewPackage.js',
    // './TestCases/PES-TestCases/TC_AddUniversity.js',
    // './TestCases/PES-TestCases/TC_AddEmployer.js',
    // './TestCases/PES-TestCases/TC_ConfigureNewClient.js',

                                                                   // PID //

    //CREATE USR
    // './TestCases/TC_Login.js',
    // './TestCases/TC_Dashboard.js',
    // './TestCases/PID-TestCases/TC_Dashboard_PID.js',
    // './TestCases/PID-TestCases/TC_CreateUSR.js',
    // './TestCases/PID-TestCases/TC_AddAssets.js',
    // './TestCases/PID-TestCases/TC_CreateThreatMonitor.js',
    // './TestCases/PID-TestCases/TC_Map_PointofInterest.js',
    // './TestCases/PID-TestCases/TC_Map_Overlay.js',
    // './TestCases/PID-TestCases/TC_Rss.js',
    // './TestCases/PID-TestCases/TC_Camera.js',
    // './TestCases/PID-TestCases/TC_Links.js',
    // './TestCases/PID-TestCases/TC_Twitter.js',
    // './TestCases/PID-TestCases/TC_Iframe.js',
    // './TestCases/PID-TestCases/TC_Image.js',
    // './TestCases/PID-TestCases/TC_CreateAlert.js',
    // './TestCases/PID-TestCases/TC_Alerts.js',
    // './TestCases/PID-TestCases/TC_Map_Alerts.js',
    // './TestCases/PID-TestCases/TC_Assets.js',
    // './TestCases/PID-TestCases/TC_Map_Assets.js',
    // './TestCases/PID-TestCases/TC_Youtube.js',
    // './TestCases/PID-TestCases/TC_ThreatMonitorFlow.js',
    // './TestCases/TC_Logout.js',
    // './TestCases/PID-TestCases/TC_ADB2C.js',
    
    //All Widgets Configuration
    // './TestCases/TC_Login.js',
    //  './TestCases/TC_Dashboard.js',
    // './TestCases/TC_Dashboard_PID.js',
    // './TestCases/TC_ViewUSR.js',
    // './TestCases/TC_Map_PointofInterest.js',
    // './TestCases/TC_Map_Overlay.js',
    // './TestCases/TC_Rss.js',
    // './TestCases/TC_Camera.js',
    // './TestCases/TC_Links.js',
    // './TestCases/TC_Twitter.js',
    // './TestCases/TC_Iframe.js',
    // './TestCases/TC_Image.js',
    // './TestCases/TC_CreateAlert.js',
    // './TestCases/TC_Alerts.js',
    // './TestCases/TC_Map_Alerts.js',
    // './TestCases/TC_Assets.js',
    // './TestCases/TC_Map_Assets.js',
    // './TestCases/TC_Youtube.js',
    // './TestCases/TC_ThreatMonitorFlow.js', 
    // './TestCases/TC_Logout.js',

    //Map Point of Interest
    // './TestCases/TC_Login.js',
    // './TestCases/TC_Dashboard_PID.js',
    // './TestCases/TC_ViewUSR.js',    
    // './TestCases/TC_Map_PointofInterest.js', 
    
    //Map Overlay
    // './TestCases/TC_Login.js',
    // './TestCases/TC_Dashboard_PID.js',
    // './TestCases/TC_ViewUSR.js',    
    // './TestCases/TC_Map_Overlay.js', 

    //RSS Widget
    // './TestCases/TC_Login.js',
    // './TestCases/TC_Dashboard_PID.js',
    // './TestCases/TC_ViewUSR.js',
    // './TestCases/TC_Rss.js',

    //Camera Widget
    // './TestCases/TC_Login.js',
    // './TestCases/TC_Dashboard_PID.js',
    // './TestCases/TC_ViewUSR.js',
    // './TestCases/TC_Camera.js',

     //Links Widget
    // './TestCases/TC_Login.js',
    // './TestCases/TC_Dashboard_PID.js',
    // './TestCases/TC_ViewUSR.js',   
    // './TestCases/TC_Links.js',

    //Twitter Widget
    // './TestCases/TC_Login.js',
    // './TestCases/TC_Dashboard_PID.js',
    // './TestCases/TC_ViewUSR.js',
    // './TestCases/TC_Twitter.js',

     //IFrame Widget
    // './TestCases/TC_Login.js',
    // './TestCases/TC_Dashboard_PID.js',
    // './TestCases/TC_ViewUSR.js',
    // './TestCases/TC_Iframe.js', 

    //Image Widget
    // './TestCases/TC_Login.js',
    // './TestCases/TC_Dashboard_PID.js',
    // './TestCases/TC_ViewUSR.js',
    // './TestCases/TC_Image.js',

    //Create-Alert Widget
    // './TestCases/TC_Login.js',
    // './TestCases/TC_Dashboard_PID.js',
    // './TestCases/TC_ViewUSR.js',
    // './TestCases/TC_CreateAlert.js',

    //Alerts Widget
    // './TestCases/TC_Login.js',
    // './TestCases/TC_Dashboard_PID.js',
    // './TestCases/TC_ViewUSR.js',
    // './TestCases/TC_Alerts.js',

    //Assets Widget
    // './TestCases/TC_Login.js',
    // './TestCases/TC_Dashboard_PID.js',
    // './TestCases/TC_ViewUSR.js',
    // './TestCases/TC_Assets.js',

    //YouTube Widget
    // './TestCases/TC_Login.js',
    // './TestCases/TC_Dashboard_PID.js',
    // './TestCases/TC_ViewUSR.js',
    // './TestCases/TC_Youtube.js',
  ],

  allScriptsTimeout: 180000,

  jasmineNodeOpts: {
    showColors: true,
    includeStackTrace: true,
    defaultTimeoutInterval: 180000
  },

  onPrepare: function () {
    var originalJasmine2MetaDataBuilder = new HtmlReporter({ 'baseDirectory': './' })["jasmine2MetaDataBuilder"];
    jasmine.getEnv().addReporter(new HtmlReporter({
      baseDirectory: 'Reports/screenshots',
      takeScreenShotsOnlyForFailedSpecs: true,
      docTitle: 'Pinkerton Automation Test',
      docName: 'TestReport.html',
      gatherBrowserLogs: false,
      clientDefaults: {
        displayTime: true,
        displayBrowser: true,
        displaySessionId: true,
        displayOS: true,
        inlineScreenshots: false,
        showTotalDurationIn: "header",
        totalDurationFormat: "hms"
      },
      jasmine2MetaDataBuilder: function (spec, descriptions, results, capabilities) {
        //filter for pendings with pending() function and "unfail" them
        if (results && results.failedExpectations && results.failedExpectations.length > 0 && "Failed: => marked Pending" === results.failedExpectations[0].message) {
          results.pendingReason = "Marked Pending with pending()";
          results.status = "pending";
          results.failedExpectations = [];
        }
        //call the original method after my own mods
        return originalJasmine2MetaDataBuilder(spec, descriptions, results, capabilities);
      },
      preserveDirectory: false
    }).getJasmine2Reporter());
  },

  onComplete: function () {
    browser.driver.quit();
  }
};
