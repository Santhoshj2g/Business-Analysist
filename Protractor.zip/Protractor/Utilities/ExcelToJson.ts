import * as fs from 'fs-extra';
var exceltojson = require('convert-excel-to-json');

export const PID = exceltojson({
  source: fs.readFileSync('./PID-testdata-excel.xlsx'),
  header: { rows: 1 },
  columnToKey: { '*': '{{columnHeader}}' },
  sheets: [
    'Login',
    'LoginClient',
    'CreateUSR',
    'CreateThreatMonitor',
    'GPSMonitoring',
    'ViewUSR',
    'MapWidget_POI',
    'MapWidget_Overlay',
    'RssWidget',
    'CameraWidget',
    'LinksWidget',
    'TwitterWidget',
    'IFrameWidget',
    'ImageWidget',
    'CreateAlertWidget',
    'AlertsWidget',
    'MapWidget_Alerts',
    'AssetsWidget',
    'MapWidget_Assets',
    'YouTubeWidget',
  ]
});

export const PES = exceltojson({
  source: fs.readFileSync('./PES-testdata-excel.xlsx'),
  header: { rows: 1 },
  columnToKey: { '*': '{{columnHeader}}' },
  sheets: [
    'CreateUser',
    'CreateSupplier',
    'CreateService',
    'CreatePackage',
    'Administration',
    'ConfigureClient',
  ]
});

export const DD = exceltojson({
  source: fs.readFileSync('./DD-testdata-excel.xlsx'),
  header: { rows: 1 },
  columnToKey: { '*': '{{columnHeader}}' },
  sheets: [
    'CreateService',
    'CreatePackage',
    'CreateUSR',
    'ViewRequest',
    'EditRequest',
    'EditWorkOrder',
  ]
});

export const BV = exceltojson({
  source: fs.readFileSync('./BV-testdata-excel.xlsx'),
  header: { rows: 1 },
  columnToKey: { '*': '{{columnHeader}}' },
  sheets: [
    'CreateService',
    'CreatePackage',
    'CreateSupplier',
    'AddService_Supplier',
    'Routing',
    'Rule',
    'ClientConfig',
    'BusinessTypeConfig'
  ]
});




















//----End Import Test data
//console.log('Result',result['Sheet1'][0]);

/*
var Sheet1 = result['Sheet1'];

for (const row in Sheet1) {
  // console.log('Row',Sheet1[row]);

   console.log('UserName',Sheet1[row]['UserName']);
   console.log('Password',Sheet1[row]['Password']);
};
*/